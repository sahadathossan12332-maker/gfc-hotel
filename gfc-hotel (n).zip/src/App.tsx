import React, { useState, useEffect } from 'react';
import { CategoryId, MenuItem, CartItem, CustomerInfo, OrderHistoryRecord, Review, ToastMessage } from './types';
import { MENU_ITEMS, INITIAL_REVIEWS } from './data/menuData';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { QuickStats } from './components/QuickStats';
import { MenuSection } from './components/MenuSection';
import { PartyCenterSection } from './components/PartyCenterSection';
import { ReviewsSection } from './components/ReviewsSection';
import { GallerySection } from './components/GallerySection';
import { ContactMapSection } from './components/ContactMapSection';
import { Footer } from './components/Footer';
import { FoodDetailModal } from './components/FoodDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderReceiptModal } from './components/OrderReceiptModal';
import { OrderHistoryModal } from './components/OrderHistoryModal';
import { Toast } from './components/Toast';
import { ShoppingBag } from 'lucide-react';
import { playAddToCartSound } from './utils/sound';

export default function App() {
  // Local state initialized with localStorage persistence where helpful
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('gfc_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      localStorage.removeItem('gfc_reviews');
      const saved = localStorage.getItem('gfc_reviews_v2');
      return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  });

  // Previous Order History State saved locally
  const [orderHistory, setOrderHistory] = useState<OrderHistoryRecord[]>(() => {
    try {
      const saved = localStorage.getItem('gfc_order_history');
      if (saved) return JSON.parse(saved);
      
      // Default initial sample past order for immediate user discovery & re-ordering
      const sampleItem1 = MENU_ITEMS.find((m) => m.id === 'grill1') || MENU_ITEMS[0];
      const sampleItem2 = MENU_ITEMS.find((m) => m.id === 'nan1') || MENU_ITEMS[1];
      const sampleOrder: OrderHistoryRecord = {
        id: 'ord_sample_gfc_1',
        orderNumber: 'GFC-782415',
        date: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
        formattedDate: '১৮ অক্টোবর ২০২৬, ০৮:৩০ PM',
        items: [
          {
            id: `ci_${sampleItem1.id}_init`,
            item: sampleItem1,
            quantity: 1,
            selectedSize: 'ফুল (পুরোটা)',
            unitPrice: 480,
          },
          {
            id: `ci_${sampleItem2.id}_init`,
            item: sampleItem2,
            quantity: 2,
            unitPrice: 35,
          },
        ],
        customerInfo: {
          name: 'তানভীর আহমেদ',
          phone: '01833060181',
          address: 'এইচ.আর. সিটি কমপ্লেক্স, বঙ্গবন্ধু স্কয়ার, বসুরহাট',
          notes: 'গরম গরম সার্ভ করবেন প্লিজ।',
          orderType: 'delivery',
          paymentMethod: 'cash',
        },
        subtotal: 550,
        deliveryCharge: 50,
        grandTotal: 600,
        status: 'delivered',
      };
      return [sampleOrder];
    } catch {
      return [];
    }
  });

  const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
  const [receiptOrderRecord, setReceiptOrderRecord] = useState<OrderHistoryRecord | null>(null);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<CategoryId>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [detailModalItem, setDetailModalItem] = useState<MenuItem | null>(null);

  // Digital Invoice / Receipt State
  const [receiptCustomerInfo, setReceiptCustomerInfo] = useState<CustomerInfo | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);

  // Toast Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Persist cart
  useEffect(() => {
    try {
      localStorage.setItem('gfc_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  // Persist order history
  useEffect(() => {
    try {
      localStorage.setItem('gfc_order_history', JSON.stringify(orderHistory));
    } catch (e) {
      console.error('Failed to save order history to localStorage', e);
    }
  }, [orderHistory]);

  // Persist reviews
  useEffect(() => {
    try {
      localStorage.setItem('gfc_reviews_v2', JSON.stringify(reviews));
    } catch (e) {
      console.error('Failed to save reviews to localStorage', e);
    }
  }, [reviews]);

  const addToast = (type: 'success' | 'info' | 'warning' | 'error', message: string) => {
    const id = `t_${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add standard item from food card
  const handleAddToCart = (item: MenuItem) => {
    playAddToCartSound();
    setCart((prev) => {
      const existing = prev.find((c) => c.item.id === item.id && !c.selectedSize && (!c.selectedAddons || c.selectedAddons.length === 0));
      if (existing) {
        return prev.map((c) =>
          c.id === existing.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      const newCartItem: CartItem = {
        id: `ci_${item.id}_${Date.now()}`,
        item,
        quantity: 1,
        unitPrice: item.price,
      };
      return [...prev, newCartItem];
    });

    addToast('success', `${item.name} ট্রেইতে যোগ করা হয়েছে!`);
  };

  // Add customized item from detail modal
  const handleAddToCartCustom = (
    item: MenuItem,
    quantity: number,
    selectedSize?: string,
    unitPrice?: number,
    selectedAddons?: { name: string; price: number }[],
    notes?: string
  ) => {
    playAddToCartSound();
    const finalPrice = unitPrice || item.price;
    const newCartItem: CartItem = {
      id: `ci_${item.id}_${Date.now()}_${Math.random()}`,
      item,
      quantity,
      selectedSize,
      unitPrice: finalPrice,
      selectedAddons,
      specialInstructions: notes,
    };

    setCart((prev) => [...prev, newCartItem]);
    addToast('success', `${item.name} (${quantity}টি) কাস্টমাইজেশনসহ ট্রেইতে যোগ হয়েছে!`);
    setIsCartOpen(true);
  };

  // Update quantity on cart or food card
  const handleUpdateQuantity = (itemIdOrCartId: string, delta: number) => {
    setCart((prev) => {
      // Find either by cart item id or by food item id
      const target = prev.find((c) => c.id === itemIdOrCartId || c.item.id === itemIdOrCartId);
      if (!target) return prev;

      const newQty = target.quantity + delta;
      if (newQty <= 0) {
        return prev.filter((c) => c.id !== target.id);
      }
      return prev.map((c) =>
        c.id === target.id ? { ...c, quantity: newQty } : c
      );
    });
  };

  const handleRemoveFromCart = (cartId: string) => {
    setCart((prev) => prev.filter((c) => c.id !== cartId));
    addToast('info', 'আইটেমটি ট্রেই থেকে সরানো হয়েছে।');
  };

  const handleClearCart = () => {
    setCart([]);
    addToast('info', 'অর্ডারের ট্রেই খালি করা হয়েছে।');
  };

  // Reset all application state
  const handleResetAll = () => {
    setCart([]);
    setSearchQuery('');
    setActiveCategory('all');
    addToast('info', 'কার্ট ও সার্চ ফিল্টার রিসেট করা হয়েছে।');
  };

  const handleAddReview = (newReview: Review) => {
    setReviews((prev) => [newReview, ...prev]);
  };

  // Save new orders to persistent history
  const handleSaveOrderToHistory = (orderRecord: OrderHistoryRecord) => {
    setOrderHistory((prev) => [orderRecord, ...prev.filter((o) => o.id !== orderRecord.id)]);
  };

  // Re-order previous order items instantly
  const handleReorder = (items: CartItem[]) => {
    const freshItems: CartItem[] = items.map((c) => ({
      ...c,
      id: `ci_${c.item.id}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    }));

    setCart((prev) => [...prev, ...freshItems]);
    setIsOrderHistoryOpen(false);
    setIsCartOpen(true);
    addToast('success', `${freshItems.length}টি খাবার ট্রেইতে যুক্ত হয়েছে! এখনই কনফার্ম করুন।`);
  };

  // View past order invoice/receipt
  const handleViewReceiptFromHistory = (order: OrderHistoryRecord) => {
    setReceiptOrderRecord(order);
    setReceiptCustomerInfo(order.customerInfo);
    setIsReceiptOpen(true);
  };

  // Delete single order from history
  const handleDeleteOrder = (orderId: string) => {
    setOrderHistory((prev) => prev.filter((o) => o.id !== orderId));
    addToast('info', 'অর্ডারটি হিস্ট্রি থেকে মুছে ফেলা হয়েছে।');
  };

  // Clear all history
  const handleClearHistory = () => {
    setOrderHistory([]);
    addToast('info', 'সমস্ত পূর্ববর্তী অর্ডার হিস্ট্রি মুছে ফেলা হয়েছে।');
  };

  // Load sample order for immediate testing
  const handleAddSampleOrder = () => {
    const sampleItem1 = MENU_ITEMS.find((m) => m.id === 'grill1') || MENU_ITEMS[0];
    const sampleItem2 = MENU_ITEMS.find((m) => m.id === 'nan1') || MENU_ITEMS[1];
    const newSample: OrderHistoryRecord = {
      id: `ord_${Date.now()}`,
      orderNumber: `GFC-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString(),
      formattedDate: new Date().toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      items: [
        {
          id: `ci_${sampleItem1.id}_sample`,
          item: sampleItem1,
          quantity: 1,
          selectedSize: 'ফুল (পুরোটা)',
          unitPrice: 480,
        },
        {
          id: `ci_${sampleItem2.id}_sample`,
          item: sampleItem2,
          quantity: 2,
          unitPrice: 35,
        },
      ],
      customerInfo: {
        name: 'তানভীর আহমেদ',
        phone: '01833060181',
        address: 'বঙ্গবন্ধু স্কয়ার, বসুরহাট',
        notes: 'ঝাল একটু কম দিবেন।',
        orderType: 'delivery',
        paymentMethod: 'cash',
      },
      subtotal: 550,
      deliveryCharge: 50,
      grandTotal: 600,
      status: 'confirmed',
    };
    setOrderHistory((prev) => [newSample, ...prev]);
    addToast('success', 'নমুনা অর্ডার যোগ হয়েছে! এটি রি-অর্ডার করে দেখতে পারেন।');
  };

  const handleShowReceipt = (info: CustomerInfo) => {
    setReceiptOrderRecord(null);
    setReceiptCustomerInfo(info);
    setIsReceiptOpen(true);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Compute quantity per item for FoodCard counts
  const cartItemCounts = cart.reduce((acc, cItem) => {
    acc[cItem.item.id] = (acc[cItem.item.id] || 0) + cItem.quantity;
    return acc;
  }, {} as Record<string, number>);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#0d020e] text-gray-100 flex flex-col relative selection:bg-[#E60067] selection:text-white">
      {/* Toast Notification Layer */}
      <Toast toasts={toasts} onDismiss={removeToast} />

      {/* Header Navigation */}
      <Header
        cartCount={totalCartCount}
        orderHistoryCount={orderHistory.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenOrderHistory={() => setIsOrderHistoryOpen(true)}
        onReset={handleResetAll}
      />

      {/* Hero Section */}
      <main className="flex-1">
        <Hero
          onExploreMenu={() => scrollToSection('menu')}
          onOpenPartyBooking={() => scrollToSection('party-center')}
        />

        {/* Quick Highlights and Stats */}
        <QuickStats />

        {/* Complete Menu Section with Live Search & Category Filters */}
        <MenuSection
          items={MENU_ITEMS}
          cartItemCounts={cartItemCounts}
          onAddToCart={handleAddToCart}
          onUpdateQuantity={handleUpdateQuantity}
          onOpenDetails={(item) => setDetailModalItem(item)}
          activeCategory={activeCategory}
          onSelectCategory={(catId) => setActiveCategory(catId)}
          searchQuery={searchQuery}
          onSearchChange={(q) => setSearchQuery(q)}
        />

        {/* Party Center Banquet Hall Showcase & Interactive Calculator */}
        <PartyCenterSection onNotify={addToast} />

        {/* Customer Testimonials & Reviews */}
        <ReviewsSection
          reviews={reviews}
          onAddReview={handleAddReview}
          onNotify={addToast}
        />


        {/* Location, Google Maps Embed & FAQs */}
        <ContactMapSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals & Slide-overs */}
      <FoodDetailModal
        item={detailModalItem}
        onClose={() => setDetailModalItem(null)}
        onAddToCartCustom={handleAddToCartCustom}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onShowReceipt={handleShowReceipt}
        onNotify={addToast}
        onSaveOrderToHistory={handleSaveOrderToHistory}
      />

      <OrderHistoryModal
        isOpen={isOrderHistoryOpen}
        onClose={() => setIsOrderHistoryOpen(false)}
        orderHistory={orderHistory}
        onReorder={handleReorder}
        onViewReceipt={handleViewReceiptFromHistory}
        onDeleteOrder={handleDeleteOrder}
        onClearHistory={handleClearHistory}
        onAddSampleOrder={handleAddSampleOrder}
      />

      <OrderReceiptModal
        isOpen={isReceiptOpen}
        onClose={() => {
          setIsReceiptOpen(false);
          setReceiptOrderRecord(null);
        }}
        cart={receiptOrderRecord ? receiptOrderRecord.items : cart}
        customerInfo={receiptCustomerInfo}
        onNotify={addToast}
        savedOrderNumber={receiptOrderRecord?.orderNumber}
        savedDate={receiptOrderRecord?.formattedDate}
      />

      {/* Floating Action Buttons */}
      {/* 1. Quick WhatsApp Hotline Float (Bottom Right) */}
      <div className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-40">
        <a
          href="https://wa.me/8801833060181?text=%E0%A6%86%E0%A6%B8%E0%A6%B8%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%AE%E0%A7%81%20%E0%A6%86%E0%A6%B2%E0%A6%BE%E0%A6%87%E0%A6%95%E0%A7%81%E0%A6%AE%2C%20GFC%20Hotel%20%26%20Party%20Center%20%E0%A6%A5%E0%A7%87%E0%A6%95%E0%A7%87%20%E0%A6%96%E0%A6%BE%E0%A6%AC%E0%A6%BE%E0%A6%B0%20%E0%A6%85%E0%A6%B0%E0%A7%8D%E0%A6%A1%E0%A6%BE%E0%A6%B0%20%E0%A6%95%E0%A6%B0%E0%A6%A4%E0%A7%87%20%E0%A6%9A%E0%A6%BE%E0%A6%87%E0%A5%A4"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white p-3 sm:px-4 sm:py-2.5 rounded-full shadow-[0_4px_25px_rgba(37,211,102,0.6)] border border-white/25 transition-all duration-300 hover:scale-105 active:scale-95 group"
          title="হোয়াটসঅ্যাপে সরাসরি চ্যাট করুন"
          aria-label="Chat on WhatsApp"
        >
          {/* Official WhatsApp Icon */}
          <svg
            className="w-6 h-6 fill-current text-white shrink-0 group-hover:scale-110 transition-transform"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2ZM12.05 20.15C10.56 20.15 9.11 19.76 7.85 19.01L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.8 13.47 3.8 11.91C3.8 7.37 7.5 3.67 12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.05 20.15ZM16.57 14.36C16.32 14.23 15.1 13.64 14.88 13.56C14.65 13.47 14.49 13.43 14.32 13.68C14.16 13.93 13.69 14.48 13.54 14.65C13.4 14.81 13.25 14.84 13 14.71C12.75 14.59 11.95 14.33 11 13.49C10.26 12.83 9.76 12.02 9.61 11.77C9.47 11.52 9.6 11.39 9.72 11.27C9.83 11.16 9.97 10.98 10.1 10.83C10.22 10.68 10.26 10.57 10.35 10.4C10.43 10.24 10.39 10.1 10.33 9.97C10.27 9.85 9.77 8.63 9.57 8.13C9.37 7.65 9.17 7.71 9.02 7.71C8.88 7.7 8.71 7.7 8.55 7.7C8.38 7.7 8.12 7.76 7.89 8.01C7.67 8.26 7.03 8.85 7.03 10.07C7.03 11.29 7.92 12.46 8.04 12.63C8.17 12.79 9.78 15.28 12.26 16.35C12.85 16.6 13.31 16.76 13.67 16.87C14.26 17.06 14.8 17.03 15.23 16.97C15.71 16.9 16.7 16.37 16.91 15.79C17.11 15.2 17.11 14.71 17.05 14.6C16.99 14.49 16.82 14.43 16.57 14.36Z" />
          </svg>
          <span className="hidden sm:inline text-xs font-black tracking-wide">
            হোয়াটসঅ্যাপ সাপোর্ট
          </span>
        </a>
      </div>

      {/* 2. Floating Cart Button for Mobile (Bottom Left if cart has items) */}
      {totalCartCount > 0 && (
        <div className="fixed bottom-5 left-5 z-40 lg:hidden">
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-[#E60067] to-[#4A0E4E] text-white px-4 py-2.5 rounded-full shadow-[0_4px_20px_rgba(230,0,103,0.5)] border border-[#FFD700]/50 transition-all active:scale-95 animate-bounce"
            aria-label="View Cart"
          >
            <ShoppingBag className="w-5 h-5 text-[#FFD700]" />
            <span className="text-xs font-black">
              ট্রেই ({totalCartCount})
            </span>
          </button>
        </div>
      )}

    </div>
  );
}
