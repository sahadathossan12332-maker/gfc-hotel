export type CategoryId = 
  | 'all' 
  | 'combo'
  | 'burger' 
  | 'pizza' 
  | 'appetizer'
  | 'fry_bbq'
  | 'sandwich'
  | 'soup_pasta'
  | 'set_combo'
  | 'platter_rice'
  | 'masala_curry'
  | 'naan_salad'
  | 'dessert'
  | 'drinks'
  | 'party_pkg';

export interface MenuItem {
  id: string;
  name: string;
  nameEn: string;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  descriptionEn: string;
  isSpicy?: boolean;
  isPopular?: boolean;
  isChefSpecial?: boolean;
  isVegetarian?: boolean;
  prepTime?: string;
  rating?: number;
  availableSizes?: { size: string; price: number }[];
  addons?: { name: string; price: number }[];
}

export interface CartItem {
  id: string;
  item: MenuItem;
  quantity: number;
  selectedSize?: string;
  unitPrice: number;
  selectedAddons?: { name: string; price: number }[];
  specialInstructions?: string;
}

export type OrderType = 'delivery' | 'dinein' | 'takeaway';

export interface CustomerInfo {
  name: string;
  phone: string;
  address: string;
  notes: string;
  orderType: OrderType;
  tableNo?: string;
  paymentMethod: 'cash' | 'bkash' | 'nagad';
}

export interface OrderHistoryRecord {
  id: string;
  orderNumber: string;
  date: string;
  formattedDate: string;
  items: CartItem[];
  customerInfo: CustomerInfo;
  subtotal: number;
  deliveryCharge: number;
  grandTotal: number;
  status?: 'confirmed' | 'delivered' | 'completed';
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  date: string;
  comment: string;
  dishRecommended?: string;
  location?: string;
  avatar?: string;
  isGoogleReview?: boolean;
  localGuideLevel?: number;
  reviewCount?: number;
}

export interface PartyBookingInquiry {
  name: string;
  phone: string;
  eventType: 'birthday' | 'anniversary' | 'engagement' | 'corporate' | 'family';
  guestCount: number;
  date: string;
  timeSlot: 'lunch' | 'evening' | 'night';
  packageChoice: 'standard' | 'premium' | 'vip';
  extraNotes: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}
