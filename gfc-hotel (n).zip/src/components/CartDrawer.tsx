import React, { useState } from 'react';
import { CartItem, CustomerInfo, OrderHistoryRecord, OrderType } from '../types';
import { X, Trash2, Plus, Minus, ShoppingBag, Send, FileText, Bike, Store, Utensils, AlertCircle, MessageCircle, Check, Users } from 'lucide-react';
import { GFC_WHATSAPP_CONTACTS, sendToBothWhatsApp, sendToSingleWhatsApp, formatWhatsAppUrl } from '../utils/whatsapp';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onShowReceipt: (info: CustomerInfo) => void;
  onNotify: (type: 'success' | 'info' | 'warning' | 'error', message: string) => void;
  onSaveOrderToHistory?: (record: OrderHistoryRecord) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onShowReceipt,
  onNotify,
  onSaveOrderToHistory,
}) => {
  const [orderType, setOrderType] = useState<OrderType>('delivery');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'bkash' | 'nagad'>('cash');
  const [errorMsg, setErrorMsg] = useState('');
  const [lastSentMessage, setLastSentMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const deliveryCharge = orderType === 'delivery' ? 50 : 0;
  const grandTotal = subtotal + deliveryCharge;

  const validateAndGetCustomerInfo = (): CustomerInfo | null => {
    setErrorMsg('');
    if (cart.length === 0) {
      setErrorMsg('আপনার অর্ডারের ট্রেই খালি রয়েছে!');
      onNotify('warning', 'অনুগ্রহ করে মেনু থেকে খাবার যোগ করুন।');
      return null;
    }

    if (!name.trim()) {
      setErrorMsg('অনুগ্রহ করে আপনার নাম লিখুন।');
      onNotify('warning', 'অনুগ্রহ করে আপনার নাম লিখুন।');
      return null;
    }

    if (!phone.trim() || phone.trim().length < 10) {
      setErrorMsg('সঠিক মোবাইল নম্বর লিখুন');
      onNotify('warning', 'সঠিক মোবাইল নম্বর প্রদান করুন।');
      return null;
    }

    if (orderType === 'delivery' && !address.trim()) {
      setErrorMsg('হোম ডেলিভারির জন্য সম্পূর্ণ ঠিকানা লিখুন।');
      onNotify('warning', 'হোম ডেলিভারির জন্য সম্পূর্ণ ঠিকানা লিখুন।');
      return null;
    }

    return {
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim() || (orderType === 'dinein' ? 'ডাইন-ইন টেবিল' : 'কাউন্টার পিকআপ'),
      notes: notes.trim(),
      orderType,
      paymentMethod,
    };
  };

  const handleSendWhatsApp = () => {
    const custInfo = validateAndGetCustomerInfo();
    if (!custInfo) return;

    let msg = `*🍔 GFC Hotel & Party Center - নতুন খাবার অর্ডার*\n\n`;
    msg += `👤 *গ্রাহকের নাম:* ${custInfo.name}\n`;
    msg += `📞 *মোবাইল:* ${custInfo.phone}\n`;
    
    if (orderType === 'delivery') {
      msg += `🚚 *অর্ডার টাইপ:* হোম ডেলিভারি (বসুরহাট)\n`;
      msg += `📍 *ঠিকানা:* ${custInfo.address}\n`;
    } else if (orderType === 'dinein') {
      msg += `🍽️ *অর্ডার টাইপ:* রেস্টুরেন্টে ডাইন-ইন\n`;
      msg += `🪑 *টেবিল / নোট:* ${custInfo.address}\n`;
    } else {
      msg += `🛍️ *অর্ডার টাইপ:* টেকঅ্যাওয়ে / পার্সেল পিকআপ\n`;
    }

    msg += `💳 *পেমেন্ট পদ্ধতি:* ${
      custInfo.paymentMethod === 'cash' ? 'ক্যাশ অন ডেলিভারি' : custInfo.paymentMethod === 'bkash' ? 'বিকাশ (bKash)' : 'নগদ (Nagad)'
    }\n`;

    if (custInfo.notes) {
      msg += `📝 *বিশেষ নির্দেশ:* ${custInfo.notes}\n`;
    }

    msg += `\n📋 *অর্ডারকৃত খাবারের তালিকা:*\n`;
    cart.forEach((cItem, index) => {
      const itemTotal = cItem.unitPrice * cItem.quantity;
      let line = `${index + 1}. ${cItem.item.name}`;
      if (cItem.selectedSize) {
        line += ` [${cItem.selectedSize}]`;
      }
      if (cItem.selectedAddons && cItem.selectedAddons.length > 0) {
        line += ` (+${cItem.selectedAddons.map(a => a.name).join(', ')})`;
      }
      line += ` - ${cItem.quantity}টি × ৳${cItem.unitPrice} = ৳${itemTotal}`;
      if (cItem.specialInstructions) {
        line += ` (নোট: ${cItem.specialInstructions})`;
      }
      msg += `${line}\n`;
    });

    msg += `\n💵 *সাবটোটাল:* ৳${subtotal}\n`;
    if (orderType === 'delivery') {
      msg += `🚚 *ডেলিভারি চার্জ:* ৳৫০\n`;
    }
    msg += `💰 *সর্বমোট প্রদেয় বিল:* ৳${grandTotal}\n\n`;
    msg += `অনুগ্রহ করে অর্ডারটি নিশ্চিত করুন। ধন্যবাদ!`;

    const orderRecord: OrderHistoryRecord = {
      id: `ord_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      orderNumber: `GFC-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString(),
      formattedDate: new Date().toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      items: [...cart],
      customerInfo: custInfo,
      subtotal,
      deliveryCharge,
      grandTotal,
      status: 'confirmed',
    };
    onSaveOrderToHistory?.(orderRecord);
    setLastSentMessage(msg);

    sendToSingleWhatsApp(GFC_WHATSAPP_CONTACTS[0].waNumber, msg);
    onNotify('success', `হোয়াটসঅ্যাপে (${GFC_WHATSAPP_CONTACTS[0].phone}) অর্ডারের মেসেজ পাঠানো হয়েছে!`);
  };

  const handleOpenReceipt = () => {
    const custInfo = validateAndGetCustomerInfo();
    if (!custInfo) return;

    const orderRecord: OrderHistoryRecord = {
      id: `ord_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      orderNumber: `GFC-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString(),
      formattedDate: new Date().toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      items: [...cart],
      customerInfo: custInfo,
      subtotal,
      deliveryCharge,
      grandTotal,
      status: 'confirmed',
    };
    onSaveOrderToHistory?.(orderRecord);

    onShowReceipt(custInfo);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm transition-opacity flex justify-end">
      {/* Background click to close */}
      <div className="fixed inset-0 cursor-pointer" onClick={onClose}></div>

      {/* Slide-over panel */}
      <div className="relative z-10 w-full max-w-lg glass-panel border-l border-[#E60067]/40 text-white flex flex-col justify-between shadow-2xl h-full overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#1F0520]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#E60067] to-[#FFD700] p-0.5">
              <div className="w-full h-full bg-[#1F0520] rounded-[10px] flex items-center justify-center">
                <ShoppingBag className="w-4 h-4 text-[#FFD700]" />
              </div>
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">আপনার অর্ডারের তালিকা</h3>
              <p className="text-[11px] text-[#FFD700]">মোট {totalQuantity}টি আইটেম যোগ করা হয়েছে</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {cart.length > 0 && (
              <button
                onClick={onClearCart}
                className="text-xs text-red-300 hover:text-red-100 bg-red-900/40 hover:bg-red-900/70 px-2.5 py-1.5 rounded-lg border border-red-500/30 transition flex items-center gap-1"
                title="কার্ট খালি করুন"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">খালি করুন</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-20 text-gray-400 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#1F0520] border border-[#E60067]/30 flex items-center justify-center mx-auto text-[#E60067]">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <div>
                <p className="text-base font-bold text-white">আপনার ট্রেই বর্তমানে খালি!</p>
                <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                  মেনু থেকে সুস্বাদু বার্গার, পিজ্জা বা প্ল্যাটার বেছে নিয়ে ট্রেইতে যোগ করুন।
                </p>
              </div>
              <button
                onClick={onClose}
                className="bg-gradient-to-r from-[#E60067] to-[#4A0E4E] text-white text-xs font-bold px-6 py-2.5 rounded-xl border border-[#FFD700]/30 transition hover:opacity-95"
              >
                মেনু ব্রাউজ করুন
              </button>
            </div>
          ) : (
            cart.map((cartItem) => {
              const itemTotal = cartItem.unitPrice * cartItem.quantity;
              return (
                <div
                  key={cartItem.id}
                  className="bg-black/50 p-3.5 rounded-2xl border border-white/10 hover:border-[#FFD700]/30 transition flex gap-3 items-center"
                >
                  {/* Thumbnail */}
                  <img
                    src={cartItem.item.image}
                    alt={cartItem.item.name}
                    className="w-16 h-16 rounded-xl object-cover border border-white/15 shrink-0"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <p className="font-extrabold text-sm text-white truncate">
                        {cartItem.item.name}
                      </p>
                      <button
                        onClick={() => onRemoveItem(cartItem.id)}
                        className="text-gray-400 hover:text-red-400 p-1 transition shrink-0"
                        title="আইটেমটি মুছুন"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {cartItem.selectedSize && (
                      <span className="inline-block text-[10px] bg-[#E60067]/30 text-[#FFD700] px-2 py-0.5 rounded border border-[#E60067]/40 font-semibold mt-0.5">
                        {cartItem.selectedSize}
                      </span>
                    )}

                    {cartItem.selectedAddons && cartItem.selectedAddons.length > 0 && (
                      <p className="text-[11px] text-gray-400 mt-0.5">
                        +{cartItem.selectedAddons.map((a) => a.name).join(', ')}
                      </p>
                    )}

                    {cartItem.specialInstructions && (
                      <p className="text-[10px] text-amber-300 italic">
                        নোট: {cartItem.specialInstructions}
                      </p>
                    )}

                    <div className="flex items-center justify-between mt-2 pt-1 border-t border-white/5">
                      <span className="text-xs font-bold text-[#FFD700]">
                        ৳ {itemTotal}
                      </span>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1.5 bg-[#1F0520] rounded-lg p-1 border border-white/10">
                        <button
                          onClick={() => onUpdateQuantity(cartItem.id, -1)}
                          className="w-5 h-5 rounded bg-white/10 hover:bg-[#E60067] text-white font-black flex items-center justify-center transition text-xs"
                          aria-label="Decrease"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-black w-5 text-center text-white">
                          {cartItem.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(cartItem.id, 1)}
                          className="w-5 h-5 rounded bg-[#FFD700] hover:bg-yellow-400 text-black font-black flex items-center justify-center transition text-xs"
                          aria-label="Increase"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Checkout & Customer Details Panel */}
        {cart.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-white/10 bg-[#1F0520]/95 space-y-3.5 overflow-y-auto max-h-[60vh]">
            {/* Error Message if any */}
            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Order Type Toggle */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-300">
                অর্ডারের ধরণ:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setOrderType('delivery')}
                  className={`py-2 px-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${
                    orderType === 'delivery'
                      ? 'bg-[#E60067] border-[#FFD700] text-white shadow'
                      : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                  }`}
                >
                  <Bike className="w-3.5 h-3.5" />
                  <span>হোম ডেলিভারি</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('dinein')}
                  className={`py-2 px-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${
                    orderType === 'dinein'
                      ? 'bg-[#E60067] border-[#FFD700] text-white shadow'
                      : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                  }`}
                >
                  <Utensils className="w-3.5 h-3.5" />
                  <span>ডাইন-ইন</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('takeaway')}
                  className={`py-2 px-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${
                    orderType === 'takeaway'
                      ? 'bg-[#E60067] border-[#FFD700] text-white shadow'
                      : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                  }`}
                >
                  <Store className="w-3.5 h-3.5" />
                  <span>টেকঅ্যাওয়ে</span>
                </button>
              </div>
            </div>

            {/* Customer Inputs */}
            <div className="space-y-2">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="আপনার নাম *"
                className="w-full bg-black/50 border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:border-[#FFD700] focus:outline-none"
              />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="মোবাইল নম্বর *"
                className="w-full bg-black/50 border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:border-[#FFD700] focus:outline-none"
              />
              <textarea
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                rows={2}
                placeholder={
                  orderType === 'delivery'
                    ? 'সম্পূর্ণ ডেলিভারি ঠিকানা (বাসা/দোকান, রোড, এলাকা) *'
                    : orderType === 'dinein'
                    ? 'টেবিল নম্বর লিখুন (ঐচ্ছিক)'
                    : 'পিকআপ সময় সংক্রান্ত মন্তব্য (ঐচ্ছিক)'
                }
                className="w-full bg-black/50 border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:border-[#FFD700] focus:outline-none resize-none"
              />
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="অর্ডারের বিশেষ কোনো মন্তব্য (যেমন: কম ঝাল, এক্সট্রা সস)"
                className="w-full bg-black/50 border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:border-[#FFD700] focus:outline-none"
              />
            </div>

            {/* Payment Method Selector */}
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="text-gray-300 font-semibold">পেমেন্ট:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold ${
                    paymentMethod === 'cash'
                      ? 'bg-[#FFD700] text-black border-[#FFD700]'
                      : 'bg-black/30 border-white/15 text-gray-300'
                  }`}
                >
                  ক্যাশ অন ডেলিভারি
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bkash')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold ${
                    paymentMethod === 'bkash'
                      ? 'bg-pink-600 text-white border-pink-500'
                      : 'bg-black/30 border-white/15 text-gray-300'
                  }`}
                >
                  বিকাশ (bKash)
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('nagad')}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold ${
                    paymentMethod === 'nagad'
                      ? 'bg-amber-600 text-white border-amber-500'
                      : 'bg-black/30 border-white/15 text-gray-300'
                  }`}
                >
                  নগদ
                </button>
              </div>
            </div>

            {/* Pricing Summary */}
            <div className="border-t border-white/10 pt-2.5 space-y-1.5 text-xs text-gray-300">
              <div className="flex justify-between">
                <span>আইটেম সাবটোটাল:</span>
                <span className="font-bold text-white">৳ {subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>
                  {orderType === 'delivery' ? 'বসুরহাট হোম ডেলিভারি চার্জ:' : 'ডেলিভারি চার্জ:'}
                </span>
                <span className="font-bold text-white">
                  {orderType === 'delivery' ? '৳ ৫০' : '৳ ০ (ফ্রি)'}
                </span>
              </div>
              <div className="flex justify-between text-base font-extrabold text-[#FFD700] border-t border-white/10 pt-2">
                <span>সর্বমোট বিল:</span>
                <span className="text-xl">৳ {grandTotal}</span>
              </div>
            </div>

            {/* Direct manual link helper & subtle check animation if message was just sent */}
            {lastSentMessage && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/80 border-2 border-emerald-500/60 text-xs text-emerald-100 space-y-2 animate-in fade-in zoom-in-95 duration-300 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl pointer-events-none"></div>
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-600 flex items-center justify-center shrink-0 shadow-md animate-bounce">
                    <Check className="w-4 h-4 text-white stroke-[3]" />
                  </div>
                  <div>
                    <p className="font-black text-emerald-300 text-sm">অর্ডার সফলভাবে পাঠানো হয়েছে!</p>
                    <p className="text-[11px] text-gray-300">হোয়াটসঅ্যাপে চ্যাট ওপেন হয়েছে। প্রয়োজনে নিচের লিঙ্কে ক্লিক করুন:</p>
                  </div>
                </div>
                <div className="pt-1">
                  <a
                    href={formatWhatsAppUrl(GFC_WHATSAPP_CONTACTS[0].waNumber, lastSentMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-center py-2 px-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-mono text-xs font-bold border border-emerald-400/50 flex items-center justify-center gap-1.5 shadow-md transition transform hover:scale-105"
                  >
                    <span>হোয়াটসঅ্যাপ খুলুন ({GFC_WHATSAPP_CONTACTS[0].phone})</span>
                  </a>
                </div>
              </div>
            )}

            {/* Actions: Direct WhatsApp & Receipt Modal */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleSendWhatsApp}
                className="w-full bg-gradient-to-r from-green-600 via-emerald-600 to-green-500 hover:from-green-500 hover:to-emerald-400 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer border border-emerald-400/40 whitespace-nowrap active:scale-[0.98]"
              >
                <Send className="w-4 h-4 text-white" />
                <span className="text-xs sm:text-sm">হোয়াটসঅ্যাপে অর্ডার করুন</span>
              </button>

              <button
                type="button"
                onClick={handleOpenReceipt}
                className="w-full glass-card hover:bg-[#4A0E4E]/60 text-gray-300 hover:text-white font-bold py-2 rounded-xl text-xs transition flex items-center justify-center gap-1.5 border border-white/15 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-[#FFD700]" />
                <span>অর্ডার রসিদ / মেমো দেখুন ও কপি করুন</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
