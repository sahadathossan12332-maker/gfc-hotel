import React from 'react';
import { Flame, BookOpen, MapPin, Sparkles, PhoneCall, Check, Award } from 'lucide-react';
import { getImageUrl, handleImageError } from '../utils/imageUrl';

interface HeroProps {
  onExploreMenu: () => void;
  onOpenPartyBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onOpenPartyBooking }) => {
  return (
    <section id="hero" className="relative min-h-[82vh] flex items-center justify-center overflow-hidden py-12 lg:py-16 px-4">
      {/* Background Neon Ambient Glows */}
      <div className="absolute top-1/4 -left-10 w-96 h-96 bg-[#E60067]/20 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-0 w-[450px] h-[450px] bg-[#FFD700]/15 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-[#4A0E4E]/40 rounded-full blur-[90px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10 w-full">
        {/* Left Copy */}
        <div className="text-center lg:text-left space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#4A0E4E]/80 border border-[#FFD700]/40 text-[#FFD700] text-xs sm:text-sm font-semibold shadow-inner">
            <Award className="w-4 h-4 text-[#FFD700]" />
            <span>বসুরহাটের বিশ্বস্ত সুস্বাদু খাবার ও পার্টি সেন্টারের ঠিকানা</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-[1.15] tracking-tight">
            সেরা খাবারের স্বাদ নিন <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] via-pink-400 to-[#E60067] text-glow">
              জি.এফ.সি. রেস্টুরেন্টে
            </span>
          </h1>

          <p className="text-gray-300 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed">
            স্পেশাল বার্গার, চিজ বাবল ইতালিয়ান পিজ্জা, মুচমুচে ফ্রাইড চিকেন, গরম থাই সুপ ও রাইস প্ল্যাটার!
          </p>

          {/* Key Bullet Badges */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 text-xs sm:text-sm text-gray-200">
            <span className="flex items-center gap-1.5 bg-[#1F0520] px-3 py-1.5 rounded-full border border-white/10">
              <Check className="w-3.5 h-3.5 text-emerald-400" /> জিরো পয়েন্ট, এইচ.আর. সিটি
            </span>
            <span className="flex items-center gap-1.5 bg-[#1F0520] px-3 py-1.5 rounded-full border border-white/10">
              <Check className="w-3.5 h-3.5 text-[#FFD700]" /> দ্রুত হোম ডেলিভারি
            </span>
            <span className="flex items-center gap-1.5 bg-[#1F0520] px-3 py-1.5 rounded-full border border-white/10">
              <Check className="w-3.5 h-3.5 text-[#E60067]" /> পার্টি হল রিজার্ভেশন
            </span>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-3">
            <button
              onClick={onExploreMenu}
              className="bg-gradient-to-r from-[#059669] via-[#10B981] to-[#0d9488] hover:from-[#047857] hover:to-[#0f766e] text-white font-extrabold px-7 sm:px-8 py-3.5 rounded-full shadow-[0_4px_25px_rgba(16,185,129,0.45)] hover:shadow-[0_6px_32px_rgba(16,185,129,0.65)] hover:scale-105 active:scale-95 transition-all duration-300 transform flex items-center gap-2.5 cursor-pointer text-sm sm:text-base border border-emerald-300/50 ring-2 ring-emerald-400/20"
            >
              <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-100" />
              <span>মেনু দেখুন ও অর্ডার করুন</span>
            </button>

            <button
              onClick={onOpenPartyBooking}
              className="glass-panel border-[#FFD700]/50 hover:bg-[#FFD700]/20 text-[#FFD700] font-bold px-6 py-3.5 rounded-full transition-all duration-300 flex items-center gap-2 text-sm sm:text-base cursor-pointer hover:border-[#FFD700]"
            >
              <Sparkles className="w-4 h-4 text-[#FFD700]" />
              <span>পার্টি হল বুকিং</span>
            </button>

            <a
              href="https://maps.app.goo.gl/3LJPVjZGXPFtxRUF6"
              target="_blank"
              rel="noopener noreferrer"
              className="glass-panel border-white/20 hover:border-[#E60067] text-gray-300 hover:text-white font-semibold px-5 py-3.5 rounded-full transition-all flex items-center gap-2 text-sm"
            >
              <MapPin className="w-4 h-4 text-blue-400" />
              <span>গুগল ম্যাপস লোকেশন</span>
            </a>
          </div>
        </div>

        {/* Right Floating Visual Showcase */}
        <div className="relative flex justify-center items-center py-6">
          {/* Animated Orbiting Ring */}
          <div className="w-72 h-72 sm:w-[380px] sm:h-[380px] lg:w-[420px] lg:h-[420px] rounded-full border-2 border-dashed border-[#E60067]/40 animate-spin-slow absolute"></div>
          {/* Neon back glow */}
          <div className="w-64 h-64 sm:w-[340px] sm:h-[340px] rounded-full bg-gradient-to-tr from-[#E60067]/30 via-[#4A0E4E]/40 to-[#FFD700]/25 blur-2xl absolute"></div>

          {/* Central Dish Card */}
          <div className="relative z-10 animate-float-slow animate-glow-pulse group">
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 rounded-full overflow-hidden shadow-2xl border-4 border-[#FFD700]/70 p-1 bg-gradient-to-tr from-[#FFD700] to-[#E60067]">
              <img
                src={getImageUrl('/images/regenerated_image_1792331116871.jpg')}
                alt="রেগুলার চিকেন বার্গার"
                decoding="async"
                className="w-full h-full object-cover object-center scale-105 group-hover:scale-110 transition-transform duration-700"
                onError={handleImageError}
              />
            </div>

            {/* Floating Top Badge */}
            <div className="absolute -top-3 -right-2 glass-panel p-3 rounded-2xl shadow-xl flex items-center gap-3 border-[#FFD700]/60 animate-bounce">
              <div className="bg-[#E60067] p-2.5 rounded-xl text-white shadow-md">
                <Flame className="w-5 h-5 text-yellow-300" />
              </div>
              <div>
                <p className="text-[11px] text-gray-300 font-medium">হট সেলিং আইটেম</p>
                <p className="text-sm font-black text-[#FFD700] leading-tight">জি.এফ.সি. স্পেশাল বার্গার</p>
              </div>
            </div>


            {/* Floating Quick Price Pill */}
            <div className="absolute bottom-6 right-2 bg-[#1F0520]/90 border border-[#FFD700] text-[#FFD700] px-3.5 py-1.5 rounded-full text-xs font-black shadow-lg">
              ৳ ১৪০ থেকে শুরু
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
