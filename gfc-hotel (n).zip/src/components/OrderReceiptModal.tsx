import React, { useState } from 'react';
import { CartItem, CustomerInfo } from '../types';
import { X, Copy, Check, Printer, Send, Sparkles, Users } from 'lucide-react';
import { GFC_WHATSAPP_CONTACTS, sendToBothWhatsApp, sendToSingleWhatsApp } from '../utils/whatsapp';

interface OrderReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  customerInfo: CustomerInfo | null;
  onNotify: (type: 'success' | 'info' | 'warning' | 'error', message: string) => void;
  savedOrderNumber?: string;
  savedDate?: string;
}

export const OrderReceiptModal: React.FC<OrderReceiptModalProps> = ({
  isOpen,
  onClose,
  cart,
  customerInfo,
  onNotify,
  savedOrderNumber,
  savedDate,
}) => {
  if (!isOpen || !customerInfo) return null;

  const [copied, setCopied] = useState(false);
  const [generatedOrderNumber] = useState(
    () => `GFC-${Math.floor(100000 + Math.random() * 900000)}`
  );
  const orderNumber = savedOrderNumber || generatedOrderNumber;
  const dateStr = savedDate || new Date().toLocaleDateString('bn-BD', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const subtotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const deliveryCharge = customerInfo.orderType === 'delivery' ? 50 : 0;
  const grandTotal = subtotal + deliveryCharge;

  const getPlainTextReceipt = () => {
    let receipt = `════════════════════════════════════\n`;
    receipt += `   GFC HOTEL & PARTY CENTER\n`;
    receipt += `এইচ.আর. সিটি কমপ্লেক্স, বঙ্গবন্ধু স্কয়ার, বসুরহাট\n`;
    receipt += `হটলাইন: 01833-060181, 01881-419670\n`;
    receipt += `════════════════════════════════════\n`;
    receipt += `অর্ডার নং: #${orderNumber}\n`;
    receipt += `তারিখ: ${dateStr}\n`;
    receipt += `গ্রাহক: ${customerInfo.name}\n`;
    receipt += `মোবাইল: ${customerInfo.phone}\n`;
    receipt += `ঠিকানা: ${customerInfo.address}\n`;
    receipt += `অর্ডার টাইপ: ${
      customerInfo.orderType === 'delivery'
        ? 'হোম ডেলিভারি'
        : customerInfo.orderType === 'dinein'
        ? 'ডাইন-ইন'
        : 'টেকঅ্যাওয়ে'
    }\n`;
    receipt += `পেমেন্ট: ${customerInfo.paymentMethod.toUpperCase()}\n`;
    receipt += `------------------------------------\n`;
    receipt += `খাবারের বিবরণ:\n`;
    cart.forEach((i, idx) => {
      receipt += `${idx + 1}. ${i.item.name} ${i.selectedSize ? `[${i.selectedSize}]` : ''} x${
        i.quantity
      } = ৳${i.unitPrice * i.quantity}\n`;
    });
    receipt += `------------------------------------\n`;
    receipt += `সাবটোটাল: ৳${subtotal}\n`;
    if (customerInfo.orderType === 'delivery') {
      receipt += `ডেলিভারি চার্জ: ৳৫০\n`;
    }
    receipt += `সর্বমোট বিল: ৳${grandTotal}\n`;
    receipt += `════════════════════════════════════\n`;
    receipt += `জি.এফ.সি-তে অর্ডারের জন্য আন্তরিক ধন্যবাদ!\n`;
    return receipt;
  };

  const handleCopy = () => {
    const text = getPlainTextReceipt();
    navigator.clipboard.writeText(text);
    setCopied(true);
    onNotify('success', 'অর্ডার রসিদ ক্লিপবোর্ডে কপি করা হয়েছে!');
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsApp = (target: 'both' | 'primary' | 'secondary' = 'both') => {
    const text = getPlainTextReceipt();
    if (target === 'both') {
      sendToBothWhatsApp(text);
      onNotify('success', 'উভয় নম্বরে (01833-060181 ও 01881-419670) রসিদ পাঠানো হচ্ছে...');
    } else if (target === 'primary') {
      sendToSingleWhatsApp(GFC_WHATSAPP_CONTACTS[0].waNumber, text);
      onNotify('success', `১নং নম্বরে (${GFC_WHATSAPP_CONTACTS[0].phone}) রসিদ পাঠানো হয়েছে!`);
    } else {
      sendToSingleWhatsApp(GFC_WHATSAPP_CONTACTS[1].waNumber, text);
      onNotify('success', `২নং নম্বরে (${GFC_WHATSAPP_CONTACTS[1].phone}) রসিদ পাঠানো হয়েছে!`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-lg glass-panel rounded-3xl border border-[#FFD700]/50 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-[#1F0520] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#FFD700]" />
            <h3 className="font-extrabold text-base sm:text-lg text-white">ডিজিটাল ক্যাশ মেমো / রসিদ</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Paper */}
        <div className="p-6 overflow-y-auto flex-1 bg-gradient-to-b from-[#1F0520] to-[#0d020e] text-gray-200 font-mono text-xs sm:text-sm space-y-4">
          {/* Header */}
          <div className="text-center space-y-1 border-b border-dashed border-white/20 pb-4">
            <h2 className="text-xl font-black text-[#FFD700] tracking-wider font-sans">
              GFC HOTEL & PARTY CENTER
            </h2>
            <p className="text-xs text-gray-300 font-sans">
              এইচ.আর. সিটি কমপ্লেক্স (জিরো পয়েন্ট), বঙ্গবন্ধু স্কয়ার, বসুরহাট
            </p>
            <p className="text-xs text-gray-400">হটলাইন: 01833-060181, 01881-419670</p>
            <div className="inline-block bg-[#E60067]/30 border border-[#E60067]/50 text-[#FFD700] text-[11px] font-bold px-3 py-0.5 rounded-full mt-1">
              অর্ডার মেমো: #{orderNumber}
            </div>
          </div>

          {/* Customer Metadata */}
          <div className="space-y-1 text-xs border-b border-dashed border-white/20 pb-3 font-sans">
            <div className="flex justify-between">
              <span className="text-gray-400">তারিখ:</span>
              <span className="text-white font-semibold">{dateStr}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">গ্রাহকের নাম:</span>
              <span className="text-white font-semibold">{customerInfo.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">মোবাইল:</span>
              <span className="text-white font-semibold">{customerInfo.phone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">ডেলিভারি ঠিকানা:</span>
              <span className="text-white font-semibold text-right max-w-xs">{customerInfo.address}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">অর্ডার টাইপ:</span>
              <span className="text-[#FFD700] font-bold">
                {customerInfo.orderType === 'delivery'
                  ? 'হোম ডেলিভারি'
                  : customerInfo.orderType === 'dinein'
                  ? 'ডাইন-ইন'
                  : 'পার্সেল টেকঅ্যাওয়ে'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">পেমেন্ট মেথড:</span>
              <span className="text-emerald-400 font-bold uppercase">{customerInfo.paymentMethod}</span>
            </div>
          </div>

          {/* Items Table */}
          <div className="space-y-2 font-sans">
            <div className="flex justify-between text-xs font-bold text-gray-400 border-b border-white/10 pb-1">
              <span>খাবারের নাম</span>
              <span>পরিমাণ × মূল্য</span>
            </div>
            {cart.map((c) => (
              <div key={c.id} className="flex justify-between items-start text-xs text-gray-200">
                <div className="pr-2">
                  <p className="font-semibold text-white">{c.item.name}</p>
                  {c.selectedSize && (
                    <span className="text-[10px] text-[#FFD700] mr-2">[{c.selectedSize}]</span>
                  )}
                  {c.selectedAddons && c.selectedAddons.length > 0 && (
                    <span className="text-[10px] text-gray-400">
                      +{c.selectedAddons.map((a) => a.name).join(', ')}
                    </span>
                  )}
                </div>
                <span className="font-bold whitespace-nowrap">
                  {c.quantity} × ৳{c.unitPrice} = ৳{c.quantity * c.unitPrice}
                </span>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div className="border-t border-dashed border-white/20 pt-3 space-y-1.5 font-sans">
            <div className="flex justify-between text-xs text-gray-300">
              <span>আইটেম সাবটোটাল:</span>
              <span>৳ {subtotal}</span>
            </div>
            {customerInfo.orderType === 'delivery' && (
              <div className="flex justify-between text-xs text-gray-300">
                <span>বসুরহাট হোম ডেলিভারি ফি:</span>
                <span>৳ ৫০</span>
              </div>
            )}
            <div className="flex justify-between text-base font-black text-[#FFD700] border-t border-white/15 pt-2">
              <span>সর্বমোট প্রদেয় বিল:</span>
              <span>৳ {grandTotal}</span>
            </div>
          </div>

          <div className="text-center pt-3 text-[11px] text-gray-400 font-sans">
            জি.এফ.সি. রেস্টুরেন্ট বেছে নেওয়ার জন্য ধন্যবাদ! আবার আসবেন।
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 bg-[#1F0520] flex flex-wrap gap-2 justify-end items-center">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 text-white transition border border-white/15 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 text-white transition border border-white/15 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>প্রিন্ট</span>
          </button>

          <div className="flex items-center gap-1.5 bg-black/40 p-1 rounded-xl border border-emerald-500/30">
            <button
              onClick={() => handleWhatsApp('both')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-black bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 text-white transition shadow-md cursor-pointer border border-emerald-400/50"
              title="উভয় নম্বরে (01833-060181 ও 01881-419670) একসাথে পাঠান"
            >
              <Users className="w-3.5 h-3.5 text-emerald-100" />
              <span>উভয় নম্বরে পাঠান</span>
            </button>
            <button
              onClick={() => handleWhatsApp('primary')}
              className="px-2 py-1.5 rounded-lg text-[11px] font-bold bg-white/5 hover:bg-emerald-700/60 text-gray-200 hover:text-white transition cursor-pointer"
              title="১নং কাউন্টার: 01833-060181"
            >
              ১নং
            </button>
            <button
              onClick={() => handleWhatsApp('secondary')}
              className="px-2 py-1.5 rounded-lg text-[11px] font-bold bg-white/5 hover:bg-emerald-700/60 text-gray-200 hover:text-white transition cursor-pointer"
              title="২নং ডেলিভারি: 01881-419670"
            >
              ২নং
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
