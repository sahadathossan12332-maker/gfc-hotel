import React, { useState } from 'react';
import { MenuItem } from '../types';
import { X, Star, Clock, Flame, Check, Plus, Minus, ShoppingBag } from 'lucide-react';
import { getCategoryTheme } from '../utils/categoryTheme';
import { getImageUrl, handleImageError } from '../utils/imageUrl';

interface FoodDetailModalProps {
  item: MenuItem | null;
  onClose: () => void;
  onAddToCartCustom: (
    item: MenuItem,
    quantity: number,
    selectedSize?: string,
    unitPrice?: number,
    selectedAddons?: { name: string; price: number }[],
    notes?: string
  ) => void;
}

export const FoodDetailModal: React.FC<FoodDetailModalProps> = ({
  item,
  onClose,
  onAddToCartCustom,
}) => {
  if (!item) return null;

  const theme = getCategoryTheme(item.category);

  const [selectedSize, setSelectedSize] = useState<string>(
    item.availableSizes && item.availableSizes.length > 0
      ? item.availableSizes[0].size
      : ''
  );

  React.useEffect(() => {
    if (item.availableSizes && item.availableSizes.length > 0) {
      setSelectedSize(item.availableSizes[0].size);
    } else {
      setSelectedSize('');
    }
  }, [item]);

  const basePrice =
    item.availableSizes && item.availableSizes.length > 0 && selectedSize
      ? item.availableSizes.find((s) => s.size === selectedSize)?.price || item.price
      : item.price;

  const [selectedAddons, setSelectedAddons] = useState<{ name: string; price: number }[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [instructions, setInstructions] = useState('');

  const toggleAddon = (addon: { name: string; price: number }) => {
    if (selectedAddons.some((a) => a.name === addon.name)) {
      setSelectedAddons(selectedAddons.filter((a) => a.name !== addon.name));
    } else {
      setSelectedAddons([...selectedAddons, addon]);
    }
  };

  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const unitPrice = basePrice + addonsTotal;
  const grandTotal = unitPrice * quantity;

  const handleAdd = () => {
    onAddToCartCustom(
      item,
      quantity,
      selectedSize || undefined,
      unitPrice,
      selectedAddons,
      instructions
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] glass-panel rounded-3xl border border-[#FFD700]/40 overflow-hidden flex flex-col shadow-2xl">
        {/* Header Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/70 hover:bg-[#E60067] text-white flex items-center justify-center transition border border-white/20"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Scrollable Content */}
        <div className="overflow-y-auto flex-1 pb-4">
          {/* Cover Image */}
          <div className="relative h-64 sm:h-72 w-full bg-black/60">
            <img
              src={getImageUrl(item.image)}
              alt={item.name}
              decoding="async"
              referrerPolicy="no-referrer"
              onError={handleImageError}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1F0520] via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-5 right-5 flex items-center justify-between">
              <span className="bg-[#FFD700] text-black font-black text-sm px-3.5 py-1.5 rounded-full shadow-lg">
                ৳ {basePrice}
              </span>
              <div className="flex items-center gap-1.5 bg-black/70 px-3 py-1 rounded-full text-xs text-white border border-white/10">
                <Star className="w-3.5 h-3.5 text-[#FFD700] fill-[#FFD700]" />
                <span className="font-bold">{item.rating || 4.9}</span>
                <span className="text-gray-400">|</span>
                <Clock className="w-3.5 h-3.5 text-gray-400" />
                <span>{item.prepTime || '15 মিনিট'}</span>
              </div>
            </div>
          </div>

          <div className="p-5 sm:p-6 space-y-5">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">{item.name}</h2>
              <p className="text-xs text-[#FFD700] font-semibold mt-0.5">{item.nameEn}</p>
              <p className="text-sm text-gray-300 mt-2.5 leading-relaxed">{item.description}</p>
            </div>

            {/* Available Sizes Option */}
            {item.availableSizes && item.availableSizes.length > 0 && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-300">
                    সাইজ বা অংশ পছন্দ করুন:
                  </label>
                  {selectedSize && (
                    <span className="text-xs font-bold text-[#FFD700]">
                      নির্বাচিত: {selectedSize}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {item.availableSizes.map((s) => {
                    const isSelected = selectedSize === s.size;
                    return (
                      <button
                        key={s.size}
                        type="button"
                        onClick={() => setSelectedSize(s.size)}
                        className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-gradient-to-r from-[#E60067] to-[#990045] border-[#FFD700] text-white shadow-[0_0_15px_rgba(230,0,103,0.5)] ring-2 ring-[#FFD700]/70 scale-[1.02]'
                            : 'bg-[#1F0520] border-white/10 text-gray-300 hover:border-[#FFD700]/50 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          {isSelected && <span className="text-[#FFD700] font-black text-xs">✓</span>}
                          <span className="text-sm font-extrabold">{s.size}</span>
                        </div>
                        <span className="text-xs font-black text-[#FFD700] bg-black/40 px-2.5 py-0.5 rounded-full border border-[#FFD700]/30 shadow-inner">
                          ৳ {s.price}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Addons Selection */}
            {item.addons && item.addons.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-300">
                  এক্সট্রা টপিং ও অ্যাড-অন (ঐচ্ছিক):
                </label>
                <div className="space-y-2">
                  {item.addons.map((addon) => {
                    const isSelected = selectedAddons.some((a) => a.name === addon.name);
                    return (
                      <div
                        key={addon.name}
                        onClick={() => toggleAddon(addon)}
                        className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition select-none ${
                          isSelected
                            ? 'bg-[#4A0E4E]/70 border-[#FFD700] text-white'
                            : 'bg-black/30 border-white/10 text-gray-300 hover:border-white/30'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-5 h-5 rounded flex items-center justify-center border ${
                              isSelected
                                ? 'bg-[#FFD700] border-[#FFD700] text-black'
                                : 'border-gray-500'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                          </div>
                          <span className="text-xs sm:text-sm font-semibold">{addon.name}</span>
                        </div>
                        <span className="text-xs font-bold text-[#FFD700]">+৳ {addon.price}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Special Instructions Note */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-300">
                বিশেষ কোনো নির্দেশ (ঐচ্ছিক):
              </label>
              <input
                type="text"
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="যেমন: কম ঝাল দেবেন, এক্সট্রা মেয়োনিজ সস দিন..."
                className="w-full bg-black/50 border border-white/15 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none transition"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-white/15 bg-[#1F0520] flex items-center justify-between gap-4">
          {/* Quantity selector */}
          <div className="flex items-center gap-2 bg-black/40 border border-white/15 rounded-xl p-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-8 h-8 rounded-lg bg-[#E60067]/40 hover:bg-[#E60067] text-white font-black flex items-center justify-center transition active:scale-95"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-extrabold text-sm text-white px-2.5">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="w-8 h-8 rounded-lg bg-[#FFD700] hover:bg-yellow-400 text-black font-black flex items-center justify-center transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add to Tray Submit Button */}
          <button
            onClick={handleAdd}
            className={`flex-1 ${theme.buttonGradient} hover:opacity-95 text-white font-extrabold py-3 px-5 rounded-xl shadow-lg border ${theme.borderColor} ${theme.shadowColor} transition flex items-center justify-center gap-2 text-sm active:scale-95 cursor-pointer`}
          >
            <ShoppingBag className={`w-4 h-4 ${theme.iconColor}`} />
            <span>ট্রেইতে যোগ করুন • ৳ {grandTotal}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
