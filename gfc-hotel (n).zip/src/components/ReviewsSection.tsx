import React, { useState } from 'react';
import { Review } from '../types';
import { Star, MessageSquarePlus, CheckCircle2, User, Sparkles, MapPin } from 'lucide-react';

const getGoogleAvatarGradient = (name: string) => {
  const charCode = name.charCodeAt(0) || 0;
  const colors = [
    'bg-gradient-to-tr from-[#1a73e8] to-[#174ea6]', // Google Blue
    'bg-gradient-to-tr from-[#0d904f] to-[#0b8043]', // Google Green
    'bg-gradient-to-tr from-[#a142f4] to-[#8430ce]', // Google Purple
    'bg-gradient-to-tr from-[#e37400] to-[#b06000]', // Google Amber/Orange
    'bg-gradient-to-tr from-[#d93025] to-[#c5221f]', // Google Red
    'bg-gradient-to-tr from-[#129eaf] to-[#007b83]', // Google Teal
  ];
  return colors[charCode % colors.length];
};

interface ReviewsSectionProps {
  reviews: Review[];
  onAddReview: (review: Review) => void;
  onNotify: (type: 'success' | 'info' | 'warning' | 'error', message: string) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({
  reviews,
  onAddReview,
  onNotify,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [rating, setRating] = useState(5);
  const [location, setLocation] = useState('');
  const [dish, setDish] = useState('');
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) {
      onNotify('warning', 'অনুগ্রহ করে আপনার নাম ও রিভিউ লিখুন।');
      return;
    }

    const newRev: Review = {
      id: `r_${Date.now()}`,
      name: name.trim(),
      rating,
      date: 'আজকে',
      comment: comment.trim(),
      dishRecommended: dish.trim() || undefined,
      location: location.trim() || 'বসুরহাট',
    };

    onAddReview(newRev);
    setShowModal(false);
    setName('');
    setLocation('');
    setDish('');
    setComment('');
    setRating(5);
    onNotify('success', 'আপনার মূল্যবান রিভিউ সফলভাবে যুক্ত হয়েছে! ধন্যবাদ।');
  };

  return (
    <section id="reviews" className="max-w-7xl mx-auto px-4 py-16 scroll-mt-20">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1F0520] border border-[#FFD700]/30 text-[#FFD700] text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>গ্রাহক সন্তুষ্টি আমাদের অহংকার</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white">
            সম্মানিত গ্রাহকদের <span className="text-[#FFD700] text-gold-glow">মতামত ও রিভিউ</span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            বসুরহাট ও কোম্পানীগঞ্জের ভোজনরসিকদের সত্য অনুভূতি
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <a
            href="https://maps.app.goo.gl/3LJPVjZGXPFtxRUF6"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#FFD700]/50 text-white transition text-xs font-bold shadow-md hover:bg-white/10"
            title="গুগল ম্যাপসে GFC Hotel and Party Center এর ভেরিফায়েড রিভিউ দেখুন"
          >
            <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center p-0.5 shadow-xs">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
            </div>
            <span className="text-[#FFD700] font-black text-sm">৪.৮</span>
            <div className="flex text-[#FFD700]">
              <Star className="w-3 h-3 fill-[#FFD700]" />
            </div>
            <span className="text-gray-300">গুগল ম্যাপস রেটিং</span>
            <span className="text-[10px] text-blue-400 underline ml-0.5">ম্যাপসে দেখুন →</span>
          </a>

          <button
            onClick={() => setShowModal(true)}
            className="bg-gradient-to-r from-[#E60067] to-[#4A0E4E] hover:opacity-95 text-white font-bold px-6 py-3 rounded-2xl shadow-lg border border-[#FFD700]/30 transition flex items-center gap-2 text-xs sm:text-sm active:scale-95 cursor-pointer"
          >
            <MessageSquarePlus className="w-4 h-4 text-[#FFD700]" />
            <span>আপনার রিভিউ দিন</span>
          </button>
        </div>
      </div>

      {/* Reviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="glass-card p-5 rounded-2xl border border-white/10 hover:border-[#FFD700]/40 transition flex flex-col justify-between space-y-4 shadow-xl"
          >
            <div className="space-y-3">
              {/* Star Rating */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < rev.rating
                            ? 'text-[#FFD700] fill-[#FFD700]'
                            : 'text-gray-600 fill-gray-700'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[11px] font-black text-[#FFD700] bg-[#1F0520] px-1.5 py-0.5 rounded border border-[#FFD700]/30 shadow-xs">
                    {rev.rating === 5 ? '৫.০' : rev.rating === 4 ? '৪.০' : `${rev.rating}.০`}
                  </span>
                </div>
                <span className="text-[11px] text-gray-400">{rev.date}</span>
              </div>

              {/* Comment */}
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed italic">
                "{rev.comment}"
              </p>
            </div>

            <div className="pt-3 border-t border-white/10">
              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  {/* Authentic Google Maps Letter Circle Avatar */}
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-extrabold text-sm shadow-md border border-white/20 select-none ${getGoogleAvatarGradient(
                      rev.name
                    )}`}
                  >
                    {rev.name.trim().charAt(0)}
                  </div>
                  {/* Google Maps icon badge */}
                  <div
                    className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-white shadow-sm flex items-center justify-center border border-gray-200"
                    title="গুগল ম্যাপস ভেরিফায়েড রিভিউ"
                  >
                    <svg className="w-2.5 h-2.5" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h4 className="text-xs font-bold text-white leading-tight truncate">{rev.name}</h4>
                    <span className="inline-flex items-center gap-0.5 text-[9px] text-blue-300 bg-blue-900/30 border border-blue-400/30 px-1.5 py-0.5 rounded font-semibold">
                      <span>গুগল ম্যাপস</span>
                      {rev.localGuideLevel && (
                        <span className="text-[#FFD700] font-bold">★ L{rev.localGuideLevel}</span>
                      )}
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-400 flex items-center gap-1 mt-0.5">
                    {rev.reviewCount && <span>{rev.reviewCount}টি রিভিউ • </span>}
                    {rev.location && (
                      <span className="flex items-center gap-0.5 truncate">
                        <MapPin className="w-2.5 h-2.5 text-blue-400 shrink-0" />
                        <span className="truncate">{rev.location}</span>
                      </span>
                    )}
                  </p>
                </div>
              </div>

              {rev.dishRecommended && (
                <div className="mt-2 text-[11px] text-[#FFD700] font-medium bg-[#1F0520]/80 px-2 py-1 rounded-lg border border-[#FFD700]/20 inline-block">
                  পছন্দের পদ: {rev.dishRecommended}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* View All on Google Maps Banner */}
      <div className="mt-8 flex justify-center">
        <a
          href="https://maps.app.goo.gl/3LJPVjZGXPFtxRUF6"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2.5 px-6 py-3 rounded-2xl bg-white/5 border border-white/10 hover:border-[#FFD700]/50 hover:bg-white/10 text-white font-bold text-xs sm:text-sm transition shadow-lg group"
        >
          <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center p-0.5 shrink-0">
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
          </div>
          <span>গুগল ম্যাপসে GFC Hotel and Party Center এর সকল রিভিউ ও ছবি দেখুন</span>
          <span className="text-[#FFD700] group-hover:translate-x-1 transition-transform">→</span>
        </a>
      </div>

      {/* Review Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md glass-panel p-6 rounded-3xl border border-[#FFD700]/40 shadow-2xl">
            <h3 className="text-xl font-black text-white mb-1">আপনার রিভিউ লিখুন</h3>
            <p className="text-xs text-gray-400 mb-4">
              আপনার মতামত আমাদের সেবার মান আরও বৃদ্ধি করতে সাহায্য করবে।
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Star Selection */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">
                  রেটিং সিলেক্ট করুন:
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 hover:scale-125 transition"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= rating
                            ? 'text-[#FFD700] fill-[#FFD700]'
                            : 'text-gray-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">
                  আপনার নাম:*
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">
                    ঠিকানা:
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">
                    খাবার:
                  </label>
                  <input
                    type="text"
                    value={dish}
                    onChange={(e) => setDish(e.target.value)}
                    className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">
                  আপনার রিভিউ বা মন্তব্য:*
                </label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  placeholder="খাবার ও সেবার অভিজ্ঞতা সম্পর্কে লিখুন..."
                  className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none resize-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-300 hover:text-white bg-white/10"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-[#E60067] hover:bg-pink-600 text-white shadow-lg transition"
                >
                  রিভিউ পোস্ট করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
