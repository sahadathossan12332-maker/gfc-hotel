import React, { useState } from 'react';
import { 
  ShoppingBag, 
  RotateCcw, 
  Phone, 
  Menu, 
  X, 
  Sparkles, 
  MapPin, 
  History 
} from 'lucide-react';
import brandLogo from '../assets/images/al_baraka_logo_1792248664167.jpg';

interface HeaderProps {
  cartCount: number;
  orderHistoryCount: number;
  onOpenCart: () => void;
  onOpenOrderHistory: () => void;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  cartCount, 
  orderHistoryCount, 
  onOpenCart, 
  onOpenOrderHistory, 
  onReset 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 glass-panel border-b border-[#E60067]/30 shadow-2xl transition-all backdrop-blur-xl bg-[#1F0520]/85">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Logo & Title */}
        <a href="#" className="flex items-center gap-2.5 sm:gap-3 group shrink-0 select-none">
          {/* Logo Circle Monogram */}
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-[#E60067] via-[#FFD700] to-[#E60067] p-0.5 shadow-[0_0_15px_rgba(255,215,0,0.35)] group-hover:shadow-[0_0_22px_rgba(255,215,0,0.6)] group-hover:scale-105 transition-all duration-300 shrink-0">
            <div className="w-full h-full bg-[#1F0520] rounded-full flex items-center justify-center border border-[#FFD700]/60 overflow-hidden">
              <img
                src={brandLogo}
                alt="হোটেল আল বারাকা এন্ড কাবাব লোগো"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Logo Text */}
          <div className="flex flex-col justify-center">
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-2xl font-black text-white tracking-tight leading-none group-hover:text-[#FFD700] transition-colors">
                GFC HOTEL
              </h1>
              <span className="hidden xs:inline-flex items-center text-[10px] font-bold text-[#FFD700] bg-[#FFD700]/15 border border-[#FFD700]/40 px-2 py-0.5 rounded-full tracking-wide shadow-sm">
                বসুরহাট
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-[#E60067] font-bold tracking-wider mt-0.5 leading-none">
              & PARTY CENTER
            </p>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-2 text-xs font-bold text-gray-200 shrink-0">
          <a
            href="#hero"
            className="px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-gradient-to-r hover:from-[#E60067] hover:to-[#4A0E4E] border border-white/10 hover:border-[#FFD700]/50 text-white transition-all duration-300 shadow-sm flex items-center gap-1.5"
          >
            <span>🏠</span>
            <span>হোম</span>
          </a>
          <a
            href="#menu"
            className="px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-gradient-to-r hover:from-[#E60067] hover:to-[#4A0E4E] border border-white/10 hover:border-[#FFD700]/50 text-white transition-all duration-300 shadow-sm flex items-center gap-1.5"
          >
            <span>🍔</span>
            <span>সম্পূর্ণ মেনু</span>
          </a>
          <a
            href="#party-center"
            className="px-3.5 py-1.5 rounded-full bg-[#4A0E4E]/80 border border-[#FFD700]/60 text-[#FFD700] hover:bg-[#E60067] hover:text-white transition-all duration-300 shadow-[0_0_12px_rgba(255,215,0,0.25)] flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FFD700]" />
            <span>পার্টি সেন্টার হল</span>
          </a>
          <a
            href="#reviews"
            className="px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-gradient-to-r hover:from-[#E60067] hover:to-[#4A0E4E] border border-white/10 hover:border-[#FFD700]/50 text-white transition-all duration-300 shadow-sm flex items-center gap-1.5"
          >
            <span>⭐</span>
            <span>রিভিউ</span>
          </a>
          <a
            href="#contact"
            className="px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-gradient-to-r hover:from-[#E60067] hover:to-[#4A0E4E] border border-white/10 hover:border-[#FFD700]/50 text-white transition-all duration-300 shadow-sm flex items-center gap-1.5"
          >
            <MapPin className="w-3.5 h-3.5 text-blue-400" />
            <span>যোগাযোগ ও ম্যাপ</span>
          </a>
        </nav>

        {/* Action Controls Group */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Direct Hotline Phone Call */}
          <a
            href="tel:01833060181"
            className="hidden md:inline-flex items-center gap-1.5 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 hover:border-blue-400 text-blue-400 px-3 py-2 rounded-xl text-xs font-extrabold transition shadow-md backdrop-blur-sm group"
            title="সরাসরি কল দিন: 01833-060181"
          >
            <Phone className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
            <span className="tracking-tight hidden lg:inline">01833-060181</span>
            <span className="tracking-tight lg:hidden">কল দিন</span>
          </a>

          {/* Reset App State Utility Button */}
          <button
            onClick={onReset}
            className="bg-gradient-to-b from-[#FFD700] via-[#EAB308] to-[#B45309] hover:from-[#FACC15] hover:to-[#D97706] text-black border border-white/20 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-black transition-all duration-300 flex items-center gap-1.5 active:scale-95 shadow-[0_4px_12px_rgba(234,179,8,0.3)] hover:shadow-[0_6px_16px_rgba(234,179,8,0.5)] cursor-pointer"
            title="কার্ট ও সার্চ রিসেট করুন"
          >
            <RotateCcw className="w-3.5 h-3.5 text-black" />
            <span className="hidden sm:inline">রিসেট</span>
          </button>

          {/* Cart Drawer Trigger Button */}
          <button
            onClick={onOpenCart}
            className="relative bg-gradient-to-r from-[#8B5CF6] via-[#6D28D9] to-[#4C1D95] hover:from-[#7C3AED] hover:to-[#5B21B6] text-white py-2 px-3 sm:px-4 rounded-xl shadow-[0_4px_16px_rgba(109,40,217,0.4)] hover:shadow-[0_4px_22px_rgba(109,40,217,0.6)] border border-purple-300/30 transition-all duration-200 transform active:scale-95 flex items-center gap-2 cursor-pointer group select-none"
            aria-label="View Cart"
          >
            <ShoppingBag className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-[#FFD700] group-hover:scale-110 transition-transform" />
            <span className="hidden xs:inline text-xs font-extrabold tracking-wide">
              ট্রেই
            </span>
            <span className="bg-[#FFD700] text-black text-[11px] font-black min-w-5 h-5 px-1 rounded-full flex items-center justify-center border border-[#1F0520] shadow">
              {cartCount}
            </span>
          </button>

          {/* Mobile Menu Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 text-gray-200 hover:text-[#FFD700] glass-card rounded-xl border border-white/15 hover:border-[#FFD700]/40 transition active:scale-95 cursor-pointer"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden glass-panel border-t border-[#E60067]/30 px-4 py-4 space-y-2 animate-in slide-in-from-top-2 bg-[#1F0520]/95 backdrop-blur-2xl">
          {/* Order History Highlight Button in Mobile Drawer */}
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenOrderHistory();
            }}
            className="w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-black bg-gradient-to-r from-[#E60067] via-[#D1005E] to-[#4A0E4E] border border-[#FFD700]/50 text-white shadow-lg transition active:scale-98 cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <History className="w-4 h-4 text-[#FFD700]" />
              <span>পূর্ববর্তী অর্ডার হিস্ট্রি</span>
            </span>
            <span className="bg-[#FFD700] text-black text-xs font-black px-2 py-0.5 rounded-full shadow">
              {orderHistoryCount}টি অর্ডার
            </span>
          </button>

          {/* Cart Drawer Trigger in Mobile Drawer */}
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenCart();
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-bold bg-[#1F0520] border border-purple-400/40 text-purple-300 shadow-sm transition active:scale-98 cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-purple-400" />
              <span>বর্তমান অর্ডারের ট্রেই</span>
            </span>
            <span className="bg-purple-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {cartCount}টি আইটেম
            </span>
          </button>

          <a
            href="#hero"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#4A0E4E]/50 text-gray-200 hover:text-[#FFD700] transition"
          >
            হোম পেজ
          </a>
          <a
            href="#menu"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#4A0E4E]/50 text-gray-200 hover:text-[#FFD700] transition"
          >
            সম্পূর্ণ মেনু ও অনলাইন অর্ডার
          </a>
          <a
            href="#party-center"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-bold bg-[#4A0E4E]/60 border border-[#FFD700]/40 text-[#FFD700] shadow-sm transition"
          >
            🎉 পার্টি সেন্টার হল বুকিং
          </a>
          <a
            href="#reviews"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#4A0E4E]/50 text-gray-200 hover:text-[#FFD700] transition"
          >
            গ্রাহক রিভিউ ও মতামত
          </a>
          <a
            href="#gallery"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#4A0E4E]/50 text-gray-200 hover:text-[#FFD700] transition"
          >
            রেস্টুরেন্ট ফটো গ্যালারি
          </a>
          <a
            href="#contact"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#4A0E4E]/50 text-gray-200 hover:text-[#FFD700] transition flex items-center gap-1.5"
          >
            <MapPin className="w-4 h-4 text-blue-400" />
            <span>যোগাযোগ ও লোকেশন ম্যাপ</span>
          </a>

          {/* Mobile Drawer Bottom Actions */}
          <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row gap-2">
            <a
              href="tel:01833060181"
              className="flex-1 flex items-center justify-center gap-2 bg-[#4A0E4E] hover:bg-[#E60067] text-[#FFD700] py-2.5 rounded-xl text-xs font-bold border border-[#FFD700]/30 transition"
            >
              <Phone className="w-4 h-4" /> হটলাইন: 01833-060181
            </a>
            <button
              onClick={() => {
                onReset();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-1.5 bg-black/40 hover:bg-[#4A0E4E] text-gray-300 hover:text-[#FFD700] py-2.5 px-4 rounded-xl text-xs font-bold border border-white/15 transition"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#FFD700]" />
              <span>কার্ট ও সার্চ রিসেট</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
