import React from 'react';
import { Camera, Sparkles } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const photos = [
    {
      title: 'জিএফসি স্পেশাল বার্গার প্রেজেন্টেশন',
      tag: 'Fast Food',
      img: '/images/regenerated_image_1792335624854.jpg',
    },

    {
      title: 'গরম চিজি ইতালিয়ান পিজ্জা',
      tag: 'Pizza Oven',
      img: '/images/regenerated_image_1792335731144.jpg',
    },
    {
      title: 'বার্থডে ও অ্যানিভার্সারি স্টেজ ডেকোরেশন',
      tag: 'Celebration',
      img: '/images/gal_party_stage.jpg',
    },
    {
      title: 'ক্রিস্পি গোল্ডেন চিকেন ফ্রাই',
      tag: 'Crispy Fry',
      img: '/images/gal_crispy_chicken.jpg',
    },
    {
      title: 'কোল্ড কফি ও সিগনেচার মকটেল বার',
      tag: 'Beverages',
      img: '/images/gal_mocktail_bar.jpg',
    },
  ];

  return (
    <section id="gallery" className="max-w-7xl mx-auto px-4 py-16 scroll-mt-20">
      <div className="text-center mb-10 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1F0520] border border-[#FFD700]/30 text-[#FFD700] text-xs font-bold">
          <Camera className="w-3.5 h-3.5" />
          <span>দৃশ্যমান আমাদের পরিচ্ছন্ন ও আধুনিক পরিবেশ</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white">
          জি.এফ.সি. <span className="text-[#FFD700] text-gold-glow">ফটো গ্যালারি</span>
        </h2>
        <p className="text-xs sm:text-sm text-gray-400 max-w-xl mx-auto">
          আমাদের মনোরম ডাইনিং ও পার্টি হলের কিছু স্মরণীয় মুহূর্ত ও সুস্বাদু খাবারের ঝলক
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {photos.map((item, idx) => (
          <div
            key={idx}
            className="group relative rounded-2xl overflow-hidden h-64 border border-white/15 hover:border-[#FFD700]/60 transition-all duration-300 shadow-xl"
          >
            <img
              src={item.img}
              alt={item.title}
              loading="lazy"
              decoding="async"
              className="w-full h-full object-cover group-hover:scale-110 transition duration-700 ease-out"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/images/food_fallback_default.jpg';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
            
            <div className="absolute bottom-4 left-4 right-4 space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-wider bg-[#E60067] text-white px-2 py-0.5 rounded shadow">
                {item.tag}
              </span>
              <h4 className="text-sm font-bold text-white group-hover:text-[#FFD700] transition-colors leading-snug">
                {item.title}
              </h4>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
