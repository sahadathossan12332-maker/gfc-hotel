import React from 'react';
import { OrderHistoryRecord, CartItem } from '../types';
import { getImageUrl, handleImageError } from '../utils/imageUrl';
import { 
  X, 
  History, 
  RotateCcw, 
  FileText, 
  Trash2, 
  ShoppingBag, 
  Calendar, 
  MapPin, 
  Phone, 
  ChevronRight, 
  CreditCard
} from 'lucide-react';

interface OrderHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderHistory: OrderHistoryRecord[];
  onReorder: (items: CartItem[]) => void;
  onViewReceipt: (order: OrderHistoryRecord) => void;
  onDeleteOrder: (orderId: string) => void;
  onClearHistory: () => void;
  onAddSampleOrder?: () => void;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({
  isOpen,
  onClose,
  orderHistory,
  onReorder,
  onViewReceipt,
  onDeleteOrder,
  onClearHistory,
  onAddSampleOrder,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#140216] border border-[#FFD700]/40 rounded-3xl overflow-hidden shadow-2xl my-8 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#1F0520] sticky top-0 z-20">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#E60067] to-[#FFD700] p-0.5 shadow-md">
              <div className="w-full h-full bg-[#1F0520] rounded-[14px] flex items-center justify-center">
                <History className="w-5 h-5 text-[#FFD700]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg sm:text-xl text-white">পূর্ববর্তী অর্ডার হিস্ট্রি</h3>
                <span className="text-[11px] font-bold text-black bg-[#FFD700] px-2 py-0.5 rounded-full shadow">
                  {orderHistory.length}টি
                </span>
              </div>
              <p className="text-xs text-gray-400">
                আপনার ব্রাউজারে সংরক্ষিত পূর্ববর্তী অর্ডার ও দ্রুত রি-অর্ডারের সুবিধা
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {orderHistory.length > 0 && (
              <button
                onClick={onClearHistory}
                className="text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10 px-2.5 py-1.5 rounded-xl border border-red-500/20 transition flex items-center gap-1 cursor-pointer"
                title="সমস্ত অর্ডার ইতিহাস মুছে ফেলুন"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">সব মুছুন</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#E60067] text-white flex items-center justify-center transition border border-white/15 cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Orders List Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {orderHistory.length === 0 ? (
            <div className="text-center py-16 px-4 space-y-4">
              <div className="w-20 h-20 rounded-full bg-[#1F0520] border-2 border-dashed border-[#FFD700]/40 flex items-center justify-center mx-auto text-[#FFD700] shadow-inner">
                <History className="w-10 h-10 opacity-70" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-white">কোনো পূর্ববর্তী অর্ডার পাওয়া যায়নি</h4>
                <p className="text-xs text-gray-400 max-w-sm mx-auto mt-1 leading-relaxed">
                  আপনি যখনই মেনু থেকে খাবার অর্ডার করবেন বা রসিদ তৈরি করবেন, তা স্বয়ংক্রিয়ভাবে এখানে সংরক্ষিত থাকবে।
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
                <button
                  onClick={onClose}
                  className="bg-gradient-to-r from-[#059669] to-[#10B981] hover:from-[#047857] hover:to-[#0f766e] text-white text-xs font-black px-5 py-2.5 rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>মেনু ব্রাউজ ও নতুন অর্ডার</span>
                </button>
              </div>
            </div>
          ) : (
            orderHistory.map((order, orderIdx) => {
              const totalItemsCount = order.items.reduce((s, it) => s + it.quantity, 0);
              return (
                <div
                  key={order.id || order.orderNumber || orderIdx}
                  className="glass-card rounded-2xl border border-white/10 hover:border-[#FFD700]/50 p-4 sm:p-5 space-y-3.5 transition-all shadow-xl relative overflow-hidden group"
                >
                  {/* Neon Top Bar */}
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#E60067] via-[#FFD700] to-[#4A0E4E]"></div>

                  {/* Card Header: Order No & Date */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-white tracking-wide">
                        #{order.orderNumber}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {order.status === 'delivered' ? 'ডেলিভার্ড' : 'সম্পন্ন'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Calendar className="w-3.5 h-3.5 text-[#FFD700]" />
                      <span>{order.formattedDate}</span>
                      <button
                        onClick={() => onDeleteOrder(order.id)}
                        className="text-gray-500 hover:text-red-400 p-1 transition ml-1"
                        title="এই অর্ডারটি রেকর্ড থেকে মুছুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Customer info & Delivery Badge */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-300 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="text-gray-400">গ্রাহক:</span>
                      <span className="font-bold text-white truncate">{order.customerInfo.name}</span>
                      <span className="text-gray-500">({order.customerInfo.phone})</span>
                    </div>
                    <div className="flex items-center gap-1.5 justify-start sm:justify-end">
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-[#1F0520] border border-[#FFD700]/30 text-[#FFD700]">
                        {order.customerInfo.orderType === 'delivery'
                          ? '🚚 হোম ডেলিভারি'
                          : order.customerInfo.orderType === 'dinein'
                          ? '🍽️ ডাইন-ইন'
                          : '🛍️ টেকঅ্যাওয়ে'}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-[#E60067]/20 border border-[#E60067]/40 text-pink-300 uppercase">
                        {order.customerInfo.paymentMethod}
                      </span>
                    </div>
                  </div>

                  {/* Ordered Items Breakdown */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-gray-400 font-semibold px-1">
                      <span>খাবারের আইটেম ({totalItemsCount}টি)</span>
                      <span>মূল্য</span>
                    </div>

                    <div className="divide-y divide-white/5 bg-black/25 rounded-xl p-2 border border-white/5 max-h-48 overflow-y-auto">
                      {order.items.map((cartItem, idx) => (
                        <div key={idx} className="py-1.5 flex items-center justify-between gap-2 text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            {cartItem.item.image && (
                              <img
                                src={getImageUrl(cartItem.item.image)}
                                alt={cartItem.item.name}
                                className="w-7 h-7 rounded-lg object-cover shrink-0 border border-white/10"
                                onError={handleImageError}
                              />
                            )}
                            <div className="truncate">
                              <span className="font-bold text-gray-200">
                                {cartItem.item.name}
                              </span>
                              {cartItem.selectedSize && (
                                <span className="text-[10px] text-[#FFD700] ml-1.5 font-semibold">
                                  [{cartItem.selectedSize}]
                                </span>
                              )}
                              {cartItem.selectedAddons && cartItem.selectedAddons.length > 0 && (
                                <span className="text-[10px] text-gray-400 block truncate">
                                  +{cartItem.selectedAddons.map(a => a.name).join(', ')}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="shrink-0 text-right">
                            <span className="text-gray-400 text-[11px] mr-1.5">
                              {cartItem.quantity}x
                            </span>
                            <span className="font-black text-[#FFD700]">
                              ৳ {cartItem.unitPrice * cartItem.quantity}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Total & Action Buttons */}
                  <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xs text-gray-400 font-semibold">সর্বমোট বিল:</span>
                      <span className="text-lg font-black text-[#FFD700]">
                        ৳ {order.grandTotal}
                      </span>
                      {order.deliveryCharge > 0 && (
                        <span className="text-[10px] text-gray-400">
                          (ডেলিভারি চার্জ ৳{order.deliveryCharge} সহ)
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      {/* View Receipt Memo */}
                      <button
                        onClick={() => onViewReceipt(order)}
                        className="flex-1 sm:flex-none glass-panel hover:bg-white/10 text-gray-200 hover:text-white px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border border-white/15 cursor-pointer"
                        title="এই অর্ডারের মেমো / ডিজিটাল রসিদ দেখুন"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#FFD700]" />
                        <span>রসিদ দেখুন</span>
                      </button>

                      {/* Re-order This Order */}
                      <button
                        onClick={() => onReorder(order.items)}
                        className="flex-1 sm:flex-none bg-gradient-to-r from-[#E60067] via-[#D1005E] to-[#4A0E4E] hover:from-[#FF0077] hover:to-[#6A1470] text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg shadow-pink-900/40 hover:shadow-pink-800/60 transition-all active:scale-95 flex items-center justify-center gap-1.5 border border-[#FFD700]/40 cursor-pointer"
                        title="এই খাবারের আইটেমগুলো পুনরায় অর্ডারের ট্রেইতে যোগ করুন"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-[#FFD700]" />
                        <span>আবার অর্ডার করুন</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
