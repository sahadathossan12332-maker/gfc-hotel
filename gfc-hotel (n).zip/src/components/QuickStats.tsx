import React from 'react';
import { ShieldCheck, Users, Bike, Star, Clock, Sparkles } from 'lucide-react';

export const QuickStats: React.FC = () => {
  const stats = [
    {
      icon: <ShieldCheck className="w-6 h-6 text-[#FFD700]" />,
      title: '১০০% হালাল ও স্বাস্থ্যসম্মত',
      subtitle: 'প্রতিদিনের তাজা মাংস ও ফ্রেশ উপাদান'
    },
    {
      icon: <Users className="w-6 h-6 text-[#E60067]" />,
      title: '১৫০+ সিটের এসি পার্টি হল',
      subtitle: 'বার্থডে, এঙ্গেজমেন্ট ও পারিবারিক আয়োজন'
    },
    {
      icon: <Bike className="w-6 h-6 text-emerald-400" />,
      title: 'দ্রুত হোম ডেলিভারি',
      subtitle: 'বসুরহাটের সর্বত্র ৩০-৪৫ মিনিটে পৌঁছে যায়'
    },
    {
      icon: <Star className="w-6 h-6 text-[#FFD700]" />,
      title: '৪.০★ গুগল ম্যাপস রেটিং',
      subtitle: 'কোম্পানীগঞ্জের ভোজনরসিকদের বিশ্বস্ত ঠিকানা'
    }
  ];

  return (
    <section className="relative z-20 -mt-6 sm:-mt-8 max-w-7xl mx-auto px-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((item, idx) => (
          <div
            key={idx}
            className="glass-card p-4 sm:p-5 rounded-2xl border border-[#FFD700]/25 hover:border-[#FFD700]/60 transition-all duration-300 hover:-translate-y-1 shadow-xl flex items-center gap-3.5 group"
          >
            <div className="w-12 h-12 rounded-xl bg-[#1F0520] border border-[#E60067]/40 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
              {item.icon}
            </div>
            <div>
              <h4 className="text-sm font-bold text-white group-hover:text-[#FFD700] transition-colors leading-snug">
                {item.title}
              </h4>
              <p className="text-xs text-gray-400 mt-0.5 leading-tight">
                {item.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
