import React from 'react';
import { MapPin, Phone, Clock, Bike, Compass } from 'lucide-react';

export const ContactMapSection: React.FC = () => {
  return (
    <section id="contact" className="max-w-7xl mx-auto px-4 py-16 scroll-mt-20">
      {/* Contact & Map Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Contact Info Card */}
        <div className="lg:col-span-5 glass-panel p-6 sm:p-8 rounded-3xl border border-[#E60067]/40 shadow-2xl flex flex-col justify-between space-y-6">
          <div className="space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#FFD700] bg-[#1F0520] px-3 py-1 rounded-full border border-[#FFD700]/30 inline-block mb-2">
                সহজ যোগাযোগ
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white">জি.এফ.সি. লোকেশন ও যোগাযোগ</h2>
              <p className="text-xs sm:text-sm text-gray-300 mt-1">
                সরাসরি চলে আসুন আমাদের রেস্টুরেন্টে অথবা ফোনে অর্ডার করুন।
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              {/* Address */}
              <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-black/40 border border-white/10">
                <div className="w-10 h-10 rounded-xl bg-[#E60067]/20 border border-[#E60067]/40 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="font-extrabold text-white text-sm">ঠিকানা:</p>
                  <p className="text-gray-300 leading-relaxed mt-0.5">
                    এইচ.আর. সিটি কমপ্লেক্স (জিরো পয়েন্ট), বঙ্গবন্ধু স্কয়ার, বসুরহাট, কোম্পানীগঞ্জ, নোয়াখালী।
                  </p>
                </div>
              </div>

              {/* Phones */}
              <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-black/40 border border-white/10">
                <div className="w-10 h-10 rounded-xl bg-[#FFD700]/20 border border-[#FFD700]/40 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-[#FFD700]" />
                </div>
                <div>
                  <p className="font-extrabold text-white text-sm">হটলাইন ও অর্ডার নম্বর:</p>
                  <div className="flex flex-wrap gap-2 mt-1">
                    <a
                      href="tel:01833060181"
                      className="text-[#FFD700] hover:underline font-mono font-bold"
                    >
                      01833-060181
                    </a>
                    <span className="text-gray-500">|</span>
                    <a
                      href="tel:01881419670"
                      className="text-[#FFD700] hover:underline font-mono font-bold"
                    >
                      01881-419670
                    </a>
                  </div>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-black/40 border border-white/10">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-purple-300" />
                </div>
                <div>
                  <p className="font-extrabold text-white text-sm">খোলা থাকার সময়সূচি:</p>
                  <p className="text-gray-300 mt-0.5">
                    প্রতিদিন সকাল ১০:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত (সপ্তাহের ৭ দিনই সেবা চালু)
                  </p>
                </div>
              </div>

              {/* Delivery coverage */}
              <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-black/40 border border-white/10">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                  <Bike className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="font-extrabold text-white text-sm">ডেলিভারি এরিয়া:</p>
                  <p className="text-gray-300 mt-0.5">
                    বসুরহাট পৌরসভা।
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-3">
            <a
              href="tel:01833060181"
              className="flex-1 bg-gradient-to-r from-[#4A0E4E] to-[#E60067] hover:opacity-95 text-white py-3 px-4 rounded-xl font-extrabold text-center transition flex items-center justify-center gap-2 text-xs sm:text-sm border border-[#FFD700]/30 shadow-md"
            >
              <Phone className="w-4 h-4 text-[#FFD700]" />
              <span>সরাসরি কল দিন</span>
            </a>
            <a
              href="https://wa.me/8801833060181"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-gradient-to-r from-[#25D366] to-emerald-600 hover:from-green-500 text-white py-3 px-4 rounded-xl font-extrabold text-center transition flex items-center justify-center gap-2 text-xs sm:text-sm shadow-md group"
            >
              <svg
                className="w-4 h-4 fill-current text-white shrink-0 group-hover:scale-110 transition-transform"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2ZM12.05 20.15C10.56 20.15 9.11 19.76 7.85 19.01L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.8 13.47 3.8 11.91C3.8 7.37 7.5 3.67 12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.05 20.15ZM16.57 14.36C16.32 14.23 15.1 13.64 14.88 13.56C14.65 13.47 14.49 13.43 14.32 13.68C14.16 13.93 13.69 14.48 13.54 14.65C13.4 14.81 13.25 14.84 13 14.71C12.75 14.59 11.95 14.33 11 13.49C10.26 12.83 9.76 12.02 9.61 11.77C9.47 11.52 9.6 11.39 9.72 11.27C9.83 11.16 9.97 10.98 10.1 10.83C10.22 10.68 10.26 10.57 10.35 10.4C10.43 10.24 10.39 10.1 10.33 9.97C10.27 9.85 9.77 8.63 9.57 8.13C9.37 7.65 9.17 7.71 9.02 7.71C8.88 7.7 8.71 7.7 8.55 7.7C8.38 7.7 8.12 7.76 7.89 8.01C7.67 8.26 7.03 8.85 7.03 10.07C7.03 11.29 7.92 12.46 8.04 12.63C8.17 12.79 9.78 15.28 12.26 16.35C12.85 16.6 13.31 16.76 13.67 16.87C14.26 17.06 14.8 17.03 15.23 16.97C15.71 16.9 16.7 16.37 16.91 15.79C17.11 15.2 17.11 14.71 17.05 14.6C16.99 14.49 16.82 14.43 16.57 14.36Z" />
              </svg>
              <span>হোয়াটসঅ্যাপ চ্যাট</span>
            </a>
          </div>
        </div>

        {/* Live Google Map Container */}
        <div className="lg:col-span-7 flex flex-col rounded-3xl overflow-hidden border border-[#FFD700]/40 shadow-2xl relative min-h-[380px] bg-[#1F0520]">
          {/* Live Location Marker Overlay Pill */}
          <div className="absolute top-3.5 left-3.5 z-10 bg-[#1F0520]/95 backdrop-blur-md border border-[#FFD700]/60 px-3.5 py-1.5 rounded-full shadow-xl flex items-center gap-2 pointer-events-none">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-black text-white tracking-wide">
              GFC Hotel and Party Center
            </span>
          </div>

          <iframe
            title="GFC Hotel and Party Center Google Map"
            src="https://maps.google.com/maps?q=22.8732041,91.2773511+(GFC%20Hotel%20and%20Party%20Center)&t=&z=16&ie=UTF8&iwloc=B&output=embed"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            className="flex-1 w-full min-h-[380px] transition-all duration-300"
          ></iframe>

          {/* Map Footer Bar */}
          <div className="bg-[#1F0520] p-4 border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#FFD700]" />
              <span className="text-xs font-bold text-gray-200">
                বঙ্গবন্ধু স্কয়ার, জিরো পয়েন্ট, বসুরহাট
              </span>
            </div>
            <a
              href="https://maps.app.goo.gl/3LJPVjZGXPFtxRUF6"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#E60067] hover:bg-pink-600 text-white text-xs font-bold px-3.5 py-1.5 rounded-lg transition flex items-center gap-1.5 shadow shrink-0 whitespace-nowrap"
            >
              <MapPin className="w-3.5 h-3.5 text-blue-400" />
              <span className="whitespace-nowrap">গুগল ম্যাপসে খুলুন</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
