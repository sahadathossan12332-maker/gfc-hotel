import React from 'react';
import { MenuItem } from '../types';
import { Flame, Star, Clock, Plus, Minus, Eye, Sparkles } from 'lucide-react';
import { getCategoryTheme } from '../utils/categoryTheme';
import { getImageUrl, handleImageError } from '../utils/imageUrl';

interface FoodCardProps {
  item: MenuItem;
  cartQuantity: number;
  onAddToCart: (item: MenuItem) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onOpenDetails: (item: MenuItem) => void;
}

export const FoodCard: React.FC<FoodCardProps> = ({
  item,
  cartQuantity,
  onAddToCart,
  onUpdateQuantity,
  onOpenDetails,
}) => {
  const theme = getCategoryTheme(item.category);

  return (
    <div className="glass-card rounded-2xl overflow-hidden hover:border-[#FFD700]/50 transition-all duration-300 flex flex-col justify-between group shadow-xl hover:-translate-y-1 relative">
      {/* Top Image Container */}
      <div className="relative overflow-hidden h-52 bg-black/40">
        <img
          src={getImageUrl(item.image)}
          alt={item.name}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={handleImageError}
          className="w-full h-full object-contain object-center p-2 group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1F0520] via-transparent to-black/30"></div>

        {/* Badges on Top Left */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {item.isChefSpecial && (
            <span className="bg-[#E60067] text-white font-extrabold text-[11px] px-2.5 py-1 rounded-full shadow-md flex items-center gap-1 border border-pink-300/30">
              <Sparkles className="w-3 h-3 text-[#FFD700]" /> স্পেশাল
            </span>
          )}
          {item.isPopular && (
            <span className="bg-amber-500 text-black font-extrabold text-[11px] px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
              <Flame className="w-3 h-3 text-red-700" /> জনপ্রিয়
            </span>
          )}
          {item.isSpicy && (
            <span className="bg-red-600/90 text-white font-bold text-[11px] px-2 py-0.5 rounded-full shadow flex items-center gap-1">
              🌶️ স্পাইসি
            </span>
          )}
        </div>

        {/* Price Tag on Top Right */}
        <div className="absolute top-3 right-3 flex flex-col items-end z-10">
          <div className="bg-[#1F0520]/95 border border-[#FFD700]/80 text-[#FFD700] font-black text-sm px-3 py-1 rounded-full shadow-lg flex items-baseline gap-1">
            <span className="text-xs">৳</span>
            <span>
              {item.availableSizes && item.availableSizes.length > 0
                ? `${Math.min(...item.availableSizes.map((s) => s.price))} - ${Math.max(...item.availableSizes.map((s) => s.price))}`
                : item.price}
            </span>
          </div>
          {item.availableSizes && item.availableSizes.length > 0 ? (
            <span className="text-[10px] text-[#FFD700] font-bold bg-[#1F0520]/90 border border-[#FFD700]/40 px-2 py-0.5 rounded-full mt-1 backdrop-blur-sm shadow">
              {item.availableSizes.length}টি সাইজ অপশন
            </span>
          ) : (
            item.originalPrice && (
              <span className="text-[11px] text-gray-400 line-through mt-0.5 bg-black/60 px-1.5 py-0.5 rounded">
                ৳ {item.originalPrice}
              </span>
            )
          )}
        </div>

        {/* Bottom Bar inside image: Rating & Prep Time */}
        <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-xs text-gray-300 z-10">
          <div className="flex items-center gap-1 bg-black/60 px-2 py-1 rounded-lg backdrop-blur-sm">
            <Star className="w-3.5 h-3.5 text-[#FFD700] fill-[#FFD700]" />
            <span className="font-bold text-white">{item.rating || 4.8}</span>
          </div>
          {item.prepTime && (
            <div className="flex items-center gap-1 bg-black/60 px-2 py-1 rounded-lg backdrop-blur-sm text-[11px]">
              <Clock className="w-3 h-3 text-gray-400" />
              <span>{item.prepTime}</span>
            </div>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-extrabold text-white text-base leading-snug group-hover:text-[#FFD700] transition-colors">
              {item.name}
            </h3>
            <button
              onClick={() => onOpenDetails(item)}
              className="text-gray-400 hover:text-[#FFD700] p-1 transition shrink-0 cursor-pointer"
              title="বিস্তারিত ও কাস্টমাইজ দেখুন"
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-gray-400 line-clamp-2 mt-1.5 leading-relaxed">
            {item.description}
          </p>

          {/* Quick Available Sizes Preview */}
          {item.availableSizes && item.availableSizes.length > 0 && (
            <div className="mt-2.5 pt-2 border-t border-white/5 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
                সাইজ অপশন:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {item.availableSizes.map((s) => (
                  <button
                    key={s.size}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenDetails(item);
                    }}
                    className="text-[11px] font-bold bg-[#1F0520] hover:bg-[#E60067] border border-[#FFD700]/30 hover:border-[#FFD700] px-2 py-0.5 rounded-lg text-gray-200 hover:text-white transition flex items-center gap-1 cursor-pointer shadow-sm"
                    title={`${s.size} - ৳${s.price}`}
                  >
                    <span>{s.size}:</span>
                    <span className="text-[#FFD700] font-black">৳{s.price}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
          {cartQuantity > 0 ? (
            <div className="w-full flex items-center justify-between bg-[#1F0520] border border-[#FFD700]/50 rounded-xl p-1 shadow-md">
              <button
                onClick={() => onUpdateQuantity(item.id, -1)}
                className="w-8 h-8 rounded-lg bg-red-600/40 hover:bg-red-600 text-white font-black flex items-center justify-center transition active:scale-95 cursor-pointer"
                aria-label="Decrease quantity"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-sm font-black text-[#FFD700] px-3">
                {cartQuantity} টি
              </span>
              <button
                onClick={() => onUpdateQuantity(item.id, 1)}
                className={`w-8 h-8 rounded-lg ${theme.buttonGradient} text-white font-black flex items-center justify-center transition active:scale-95 border ${theme.borderColor} cursor-pointer`}
                aria-label="Increase quantity"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="w-full flex items-center gap-2">
              <button
                onClick={() => {
                  if (item.availableSizes && item.availableSizes.length > 0) {
                    onOpenDetails(item);
                  } else {
                    onAddToCart(item);
                  }
                }}
                className={`flex-1 ${theme.buttonGradient} hover:opacity-95 text-white font-extrabold py-2.5 px-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-xs sm:text-sm active:scale-95 cursor-pointer border ${theme.borderColor} ${theme.shadowColor}`}
              >
                <Plus className={`w-4 h-4 ${theme.iconColor}`} />
                <span>
                  {item.availableSizes && item.availableSizes.length > 0
                    ? 'সাইজ বাছুন ও অর্ডার'
                    : 'অর্ডার ট্রেইতে যোগ'}
                </span>
              </button>
              <button
                onClick={() => onOpenDetails(item)}
                className="p-2.5 rounded-xl glass-panel hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white transition cursor-pointer"
                title="কাস্টমাইজেশন ও অপশন"
              >
                <Eye className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
