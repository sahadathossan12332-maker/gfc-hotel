import React from 'react';
import { Sparkles, Heart, Phone, MapPin, Send, Banknote, MessageCircle } from 'lucide-react';
import brandLogo from '../assets/images/al_baraka_logo_1792248664167.jpg';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-[#E60067]/30 bg-[#0d020e] text-sm text-gray-400 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#E60067] to-[#FFD700] p-0.5 shadow-md">
                <div className="w-full h-full bg-[#1F0520] rounded-full flex items-center justify-center overflow-hidden">
                  <img
                    src={brandLogo}
                    alt="হোটেল আল বারাকা লোগো"
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base">GFC HOTEL</h3>
                <p className="text-[10px] text-[#E60067] font-bold tracking-wider">& PARTY CENTER</p>
              </div>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              সুস্বাদু বার্গার, পিজ্জা, ফ্রাইড চিকেন এবং যেকোনো উৎসব আয়োজনের আধুনিক পার্টি সেন্টার।
            </p>
            <div className="inline-flex items-center gap-1.5 text-xs text-[#FFD700] bg-[#1F0520] px-3 py-1 rounded-full border border-[#FFD700]/30 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="font-['Arial',sans-serif]">১০০% হালাল খাদ্য নিশ্চয়তা</span>
            </div>
          </div>


          {/* Contact Details */}
          <div className="space-y-3 text-xs">
            <h4 className="text-white font-extrabold text-sm uppercase tracking-wider">যোগাযোগের ঠিকানা</h4>
            <p className="flex items-start gap-2 leading-relaxed">
              <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <span>এইচ.আর. সিটি কমপ্লেক্স (জিরো পয়েন্ট), বঙ্গবন্ধু স্কয়ার, বসুরহাট, কোম্পানীগঞ্জ, নোয়াখালী।</span>
            </p>
            <p className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#FFD700] shrink-0" />
              <span>হটলাইন: 01833-060181, 01881-419670</span>
            </p>
            <p className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>হোয়াটসঅ্যাপ: 01833-060181</span>
            </p>
          </div>

          {/* Operating Hours & Payment */}
          <div className="space-y-3 text-xs">
            <h4 className="text-white font-extrabold text-sm uppercase tracking-wider">খোলা থাকার সময়</h4>
            <p className="text-gray-300 font-['Arial',sans-serif] text-[11px]">
              সকাল ১০:০০ টা - রাত ১১:০০ টা <br />
              (প্রতিদিন খোলা, কোনো সাপ্তাহিক ছুটি নেই)
            </p>
            <div className="pt-2">
              <p className="text-gray-400 font-semibold mb-2">গৃহীত পেমেন্ট পদ্ধতি:</p>
              <div className="flex flex-wrap gap-2">
                {/* Cash on Delivery */}
                <div className="flex items-center gap-1.5 bg-[#1F0520] border border-[#FFD700]/70 hover:border-[#FFD700] px-3 py-1.5 rounded-xl text-xs font-black text-[#FFD700] shadow-md transition-transform hover:scale-105 cursor-default">
                  <Banknote className="w-4 h-4 text-[#FFD700]" />
                  <span>ক্যাশ অন ডেলিভারি</span>
                </div>

                {/* bKash */}
                <div className="flex items-center gap-1.5 bg-gradient-to-r from-[#D81B60] via-[#E2136E] to-[#C2185B] text-white px-3 py-1.5 rounded-xl text-xs font-black shadow-md border border-pink-400/40 transition-transform hover:scale-105 cursor-default">
                  <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M13.62 2L6 10.38l6.23 2.14L18 8.12 13.62 2zm-7.9 9.38L2 14.5l8.13 2.5 1.5-3.38-5.91-2.24zm8.65-1.5l-4.14 9.37 8.77-5.12-4.63-4.25z" />
                  </svg>
                  <span>বিকাশ</span>
                </div>

                {/* Nagad */}
                <div className="flex items-center gap-1.5 bg-gradient-to-r from-[#F7941D] to-[#ED1C24] text-white px-3 py-1.5 rounded-xl text-xs font-black shadow-md border border-orange-400/40 transition-transform hover:scale-105 cursor-default">
                  <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14.93c-2.48.42-4.73-.97-5.34-3.23-.62-2.3 1.05-4.62 3.44-4.88 1.48-.16 2.88.51 3.65 1.63l-1.63 1.05c-.44-.65-1.25-.97-2.07-.88-1.25.13-2.12 1.34-1.8 2.54.32 1.18 1.49 1.9 2.65 1.7 1.05-.18 1.79-1.02 1.79-1.02v.01l-1.92-1.05 1.06-1.65 3.32 1.83c-.3 1.9-1.74 3.53-3.15 3.95z" />
                  </svg>
                  <span>নগদ</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Social Media Links */}
          <div className="space-y-3">
            <h4 className="text-white font-extrabold text-sm uppercase tracking-wider">সোশ্যাল মিডিয়া লিংক</h4>
            <a
              href="https://www.facebook.com/GFChotelandpartycenter/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#1877F2] hover:bg-[#166FE5] text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md group"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874V12h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              <span>ফেসবুক পেজ</span>
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-3">
          <p>
            © {new Date().getFullYear()} GFC Hotel & Party Center. সর্বস্বত্ব সংরক্ষিত।
          </p>
          <p className="flex items-center gap-1">
            <span>বসুরহাটের প্রিয় খাবার রসিকদের ভালোবাসায় তৈরি</span>
            <Heart className="w-3.5 h-3.5 text-[#E60067] fill-[#E60067]" />
          </p>
        </div>
      </div>
    </footer>
  );
};
