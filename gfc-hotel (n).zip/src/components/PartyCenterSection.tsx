import React, { useState } from 'react';
import { PartyBookingInquiry } from '../types';
import { Sparkles, Users, Calendar, Clock, Music, CheckCircle2, Send, PhoneCall } from 'lucide-react';
import { sendToBothWhatsApp } from '../utils/whatsapp';
import { getImageUrl, handleImageError } from '../utils/imageUrl';

interface PartyCenterSectionProps {
  onNotify: (type: 'success' | 'info' | 'warning' | 'error', msg: string) => void;
}

export const PartyCenterSection: React.FC<PartyCenterSectionProps> = ({ onNotify }) => {
  const [eventType, setEventType] = useState<'birthday' | 'anniversary' | 'engagement' | 'corporate' | 'family'>('birthday');
  const [guestCount, setGuestCount] = useState<number>(35);
  const [eventDate, setEventDate] = useState<string>('');
  const [timeSlot, setTimeSlot] = useState<'lunch' | 'evening' | 'night'>('evening');
  const [packageChoice, setPackageChoice] = useState<'standard' | 'premium' | 'vip'>('premium');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  // Calculate estimated budget
  const calculateEstimate = () => {
    let perPersonFood = 280;
    if (packageChoice === 'standard') perPersonFood = 240;
    if (packageChoice === 'vip') perPersonFood = 380;

    let hallRent = 3500;
    if (packageChoice === 'premium') hallRent = 5500;
    if (packageChoice === 'vip') hallRent = 8000;

    const total = guestCount * perPersonFood + hallRent;
    return total;
  };

  const handleWhatsAppBooking = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim() || !customerPhone.trim()) {
      onNotify('warning', 'অনুগ্রহ করে আপনার নাম ও মোবাইল নম্বর লিখুন।');
      return;
    }

    if (!eventDate) {
      onNotify('warning', 'অনুগ্রহ করে অনুষ্ঠানের তারিখ নির্বাচন করুন।');
      return;
    }

    const eventNames = {
      birthday: 'বার্থডে পার্টি (Birthday Party)',
      anniversary: 'বিবাহবার্ষিকী / পারিবারিক উৎসব (Anniversary)',
      engagement: 'এনগেজমেন্ট / বিয়ের অনুষ্ঠান (Engagement)',
      corporate: 'অফিশিয়াল মিটিং / সেমিনার (Corporate)',
      family: 'পারিবারিক মিলনমেলা (Family Get-together)'
    };

    const slotNames = {
      lunch: 'দুপুর (১২:০০ - ৩:০০)',
      evening: 'বিকেল (৪:০০ - ৭:০০)',
      night: 'রাত (৭:৩০ - ১০:৩০)'
    };

    const pkgNames = {
      standard: 'স্ট্যান্ডার্ড প্যাকেজ (হালকা ডেকোরেশন + ফাস্টফুড সেট)',
      premium: 'প্রিমিয়াম প্যাকেজ (ফুল বেলুন/স্টেজ ডেকোরেশন + রাইস/বার্গার মিল)',
      vip: 'ভিআইপি রয়্যাল প্যাকেজ (স্পেশাল স্টেজ + সাউন্ড + কাচ্চি/রয়্যাল মিল)'
    };

    const estimatedCost = calculateEstimate();

    let text = `*🎉 GFC Party Center - হল রিজার্ভেশন ও বুকিং তথ্য*\n\n`;
    text += `👤 *নাম:* ${customerName}\n`;
    text += `📞 *মোবাইল:* ${customerPhone}\n`;
    text += `🎈 *অনুষ্ঠানের ধরন:* ${eventNames[eventType]}\n`;
    text += `👥 *অতিথি সংখ্যা:* ${guestCount} জন\n`;
    text += `📅 *তারিখ:* ${eventDate}\n`;
    text += `⏰ *সময়:* ${slotNames[timeSlot]}\n`;
    text += `✨ *পছন্দের প্যাকেজ:* ${pkgNames[packageChoice]}\n`;
    text += `💰 *আনুমানিক বাজেট:* ৳${estimatedCost.toLocaleString('bn-BD')}\n`;
    if (notes.trim()) {
      text += `📝 *বিশেষ চাওয়া:* ${notes.trim()}\n`;
    }
    text += `\nঅনুগ্রহ করে হলটি আমাদের জন্য বুকিং সংক্রান্ত বিস্তারিত তথ্য দিন। ধন্যবাদ!`;
 
    onNotify('success', 'আপনার হল বুকিং তথ্য উভয় হোয়াটসঅ্যাপ নম্বরে (01833-060181 ও 01881-419670) পাঠানো হচ্ছে...');
    sendToBothWhatsApp(text);
  };

  return (
    <section id="party-center" className="max-w-7xl mx-auto px-4 py-16 scroll-mt-20">
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-10 rounded-3xl border border-[#FFD700]/40 shadow-2xl relative overflow-hidden mb-12">
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-[#E60067]/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1F0520] border border-[#FFD700]/40 text-[#FFD700] text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>বসুরহাটের সর্বাধুনিক শীতাতপ নিয়ন্ত্রিত ব্যাঙ্কুয়েট হল</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight">
              স্মরণীয় যেকোনো মুহূর্ত উদযাপন করুন <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] via-pink-400 to-[#E60067] text-glow">
                জি.এফ.সি. পার্টি সেন্টারে
              </span>
            </h2>

            <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
              বার্থডে পার্টি, বিয়ের এঙ্গেজমেন্ট, আকিকা, কর্পোরেট মিটিং কিংবা ফ্রেন্ডস রিইউনিয়ন—সব আয়োজনেই আমরা আছি আপনার পাশে। মনোরম লাইটিং, স্টেজ ডেকোরেশন ও গরম সুস্বাদু খাবারের নিশ্চয়তা!
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs sm:text-sm text-gray-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>৫০০+ আসন ক্ষমতা</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>সেন্ট্রাল এসি হল</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>সাউন্ড ও প্রজেক্টর</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>কাস্টম স্টেজ ডেকর</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>লাইভ ফ্রেশ ফুড ক্যাটারিং</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>ভিআইপি কার পার্কিং</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 grid grid-cols-2 gap-3">
            <div className="rounded-2xl overflow-hidden h-40 border border-[#FFD700]/30 shadow-lg group">
              <img
                src={getImageUrl('/images/regenerated_image_1792253802147.jpg')}
                alt="Party Center Hall Interior"
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                referrerPolicy="no-referrer"
                onError={handleImageError}
              />
            </div>
            <div className="rounded-2xl overflow-hidden h-40 border border-[#FFD700]/30 shadow-lg group">
              <img
                src={getImageUrl('/images/regenerated_image_1792253811274.jpg')}
                alt="Birthday Decoration Setup"
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                referrerPolicy="no-referrer"
                onError={handleImageError}
              />
            </div>
            <div className="rounded-2xl overflow-hidden h-40 border border-[#FFD700]/30 shadow-lg group col-span-2">
              <img
                src={getImageUrl('/images/regenerated_image_1792326974789.jpg')}
                alt="Banquet Dinner Table"
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                referrerPolicy="no-referrer"
                onError={handleImageError}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Booking Calculator & Inquiry Form */}
      <div className="glass-card p-6 sm:p-8 rounded-3xl border border-[#FFD700]/30 shadow-2xl">
        <div className="border-b border-white/10 pb-4 mb-6">
          <h3 className="text-2xl font-black text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-[#FFD700]" />
            <span>পার্টি হল বুকিং ও আনুমানিক খরচ ক্যালকুলেটর</span>
          </h3>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            আপনার পছন্দের তারিখ ও গেস্ট সংখ্যা সিলেক্ট করে এক ক্লিকে বুকিং রিকুয়েস্ট পাঠান
          </p>
        </div>

        <form onSubmit={handleWhatsAppBooking} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Event Type */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              অনুষ্ঠানের ধরন:*
            </label>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value as any)}
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
            >
              <option value="birthday">🎂 জন্মদিন (Birthday Party)</option>
              <option value="engagement">💍 বিয়ে ও এঙ্গেজমেন্ট (Engagement)</option>
              <option value="anniversary">💖 বিবাহবার্ষিকী (Anniversary)</option>
              <option value="corporate">💼 অফিসিয়াল সেমিনার (Corporate)</option>
              <option value="family">👨‍👩‍👧‍👦 ফ্যামিলি পার্টি (Family Get-together)</option>
            </select>
          </div>

          {/* Guest Count */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-300">
                অতিথি সংখ্যা:*
              </label>
              <span className="text-xs font-black text-[#FFD700] bg-black/40 px-2 py-0.5 rounded">
                {guestCount} জন
              </span>
            </div>
            <input
              type="range"
              min="20"
              max="500"
              step="10"
              value={guestCount}
              onChange={(e) => setGuestCount(Number(e.target.value))}
              className="w-full accent-[#E60067] cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-gray-400 mt-1">
              <span>২০ জন</span>
              <span>২৫০ জন</span>
              <span>৫০০+ জন</span>
            </div>
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              অনুষ্ঠানের তারিখ:*
            </label>
            <input
              type="date"
              value={eventDate}
              onChange={(e) => setEventDate(e.target.value)}
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
              required
            />
          </div>

          {/* Time Slot */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              সময় স্লট:*
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setTimeSlot('lunch')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  timeSlot === 'lunch'
                    ? 'bg-[#E60067] border-[#FFD700] text-white'
                    : 'bg-black/30 border-white/10 text-gray-300 hover:border-white/30'
                }`}
              >
                দুপুর
              </button>
              <button
                type="button"
                onClick={() => setTimeSlot('evening')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  timeSlot === 'evening'
                    ? 'bg-[#E60067] border-[#FFD700] text-white'
                    : 'bg-black/30 border-white/10 text-gray-300 hover:border-white/30'
                }`}
              >
                বিকেল
              </button>
              <button
                type="button"
                onClick={() => setTimeSlot('night')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  timeSlot === 'night'
                    ? 'bg-[#E60067] border-[#FFD700] text-white'
                    : 'bg-black/30 border-white/10 text-gray-300 hover:border-white/30'
                }`}
              >
                রাত
              </button>
            </div>
          </div>

          {/* Package Choice */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              প্যাকেজ লেভেল:*
            </label>
            <select
              value={packageChoice}
              onChange={(e) => setPackageChoice(e.target.value as any)}
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
            >
              <option value="standard">স্ট্যান্ডার্ড (বাজেট ফ্রেন্ডলি)</option>
              <option value="premium">প্রিমিয়াম (জনপ্রিয় ফুল ডেকোরেশন)</option>
              <option value="vip">ভিআইপি রয়্যাল (স্পেশাল ক্যাটারিং ও স্টেজ)</option>
            </select>
          </div>

          {/* Customer Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              আপনার নাম:*
            </label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="আপনার পুরো নাম লিখুন"
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
              required
            />
          </div>

          {/* Customer Phone */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              মোবাইল নম্বর:*
            </label>
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="আপনার মোবাইল নম্বর"
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
              required
            />
          </div>

          {/* Extra Notes */}
          <div className="md:col-span-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
              বিশেষ কোনো চাহিদা বা নির্দেশনা:
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="যেমন: ফটো কর্নার ডেকোরেশন, চকলেট কেক অর্ডার বা প্রজেক্টর প্রয়োজন..."
              className="w-full bg-[#1F0520] border border-white/20 focus:border-[#FFD700] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
            />
          </div>

          {/* Live Estimate and Submit Button */}
          <div className="md:col-span-2 lg:col-span-3 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10 mt-2">
            <div>
              <p className="text-xs text-gray-400">আনুমানিক সম্ভাব্য খরচ (হল + খাবার):</p>
              <p className="text-2xl sm:text-3xl font-black text-[#FFD700]">
                ৳ {calculateEstimate().toLocaleString('bn-BD')}
                <span className="text-xs text-gray-400 font-normal ml-2">(চূড়ান্ত আলোচনার ভিত্তিতে নির্ধারিত হবে)</span>
              </p>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-extrabold px-8 py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm sm:text-base cursor-pointer border border-emerald-400/40"
            >
              <Send className="w-5 h-5" />
              <span>হোয়াটসঅ্যাপে হল বুকিং তথ্য পাঠান</span>
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};
