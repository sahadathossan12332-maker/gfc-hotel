import React, { useState, useMemo } from 'react';
import { CategoryId, MenuItem } from '../types';
import { CATEGORIES } from '../data/menuData';
import { FoodCard } from './FoodCard';
import { Search, X, Sparkles, ArrowUpDown } from 'lucide-react';

interface MenuSectionProps {
  items: MenuItem[];
  cartItemCounts: Record<string, number>;
  onAddToCart: (item: MenuItem) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onOpenDetails: (item: MenuItem) => void;
  activeCategory: CategoryId;
  onSelectCategory: (catId: CategoryId) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  items,
  cartItemCounts,
  onAddToCart,
  onUpdateQuantity,
  onOpenDetails,
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
}) => {
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'rating'>('default');

  const filteredAndSortedItems = useMemo(() => {
    let result = items.filter((item) => {
      // Category filter
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;

      // Search query (matches Bengali or English name or description)
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.nameEn.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });

    // Sorting
    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }

    return result;
  }, [items, activeCategory, searchQuery, sortBy]);

  return (
    <section id="menu" className="max-w-7xl mx-auto px-4 py-12 scroll-mt-24">
      {/* Section Header */}
      <div className="text-center mb-8 space-y-2.5">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1F0520] border border-[#FFD700]/30 text-[#FFD700] text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>তাজা ও সুস্বাদু খাবারের সমাহার</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-wide">
          আমাদের <span className="text-[#FFD700] text-gold-glow">সম্পূর্ণ মেনু তালিকা</span>
        </h2>
        <p className="text-gray-300 text-sm sm:text-base max-w-2xl mx-auto">
          পছন্দের বার্গার, পিজ্জা, ফ্রাইড চিকেন কিংবা কম্বো মিল বেছে নিয়ে ঘরে বসেই অর্ডার করুন।
        </p>
      </div>

      {/* Sticky Search & Category Bar */}
      <div className="sticky top-20 z-30 mb-8 space-y-3">
        <div className="glass-panel p-3.5 sm:p-4 rounded-2xl shadow-2xl border border-[#FFD700]/30 flex flex-col md:flex-row gap-3 items-center justify-between backdrop-blur-xl">
          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="খাবারের নাম লিখে খুঁজুন (উদা: বার্গার, পিজ্জা)..."
              className="w-full bg-[#1F0520]/95 text-white pl-10 pr-9 py-2.5 rounded-xl border border-[#E60067]/40 focus:outline-none focus:border-[#FFD700] transition text-xs sm:text-sm placeholder:text-gray-400 shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto w-full md:w-auto py-1 px-1 scrollbar-none no-scrollbar scroll-smooth">
            {CATEGORIES.map((cat) => {
              const isSelected = activeCategory === cat.id;
              const count =
                cat.id === 'all'
                  ? items.length
                  : items.filter((i) => i.category === cat.id).length;

              const categoryIcons: Record<string, string> = {
                all: '🍽️',
                combo: '🍱',
                burger: '🍔',
                pizza: '🍕',
                appetizer: '🍟',
                fry_bbq: '🍗',
                sandwich: '🥪',
                soup_pasta: '🍜',
                set_combo: '🍛',
                platter_rice: '🍚',
                masala_curry: '🥘',
                naan_salad: '🫓',
                dessert: '🍨',
                drinks: '🥤',
                party_pkg: '🎉',
              };

              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 border flex items-center gap-2 cursor-pointer select-none shrink-0 group active:scale-95 ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#E60067] via-[#c40058] to-[#4A0E4E] border-[#FFD700] text-white shadow-[0_4px_16px_rgba(230,0,103,0.5)] ring-1 ring-[#FFD700]/50'
                      : 'bg-[#1F0520]/85 border-white/15 text-gray-200 hover:border-[#FFD700]/50 hover:text-[#FFD700] hover:bg-[#4A0E4E]/40 shadow-sm'
                  }`}
                >
                  <span className="text-sm leading-none">{categoryIcons[cat.id] || '✨'}</span>
                  <span>{cat.nameBn}</span>
                  <span
                    className={`text-[11px] font-black px-2 py-0.5 rounded-full leading-none transition-colors ${
                      isSelected ? 'bg-[#FFD700] text-black shadow-sm' : 'bg-white/10 text-gray-400 group-hover:text-white'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Secondary Filter & Sort Row */}
        <div className="flex items-center justify-end px-2">

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 ml-auto">
            <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#1F0520] border border-white/15 text-xs text-gray-200 rounded-lg px-2.5 py-1 focus:outline-none focus:border-[#FFD700]"
            >
              <option value="default">ক্রমানুসার: সাধারণ</option>
              <option value="price-asc">মূল্য: কম থেকে বেশি</option>
              <option value="price-desc">মূল্য: বেশি থেকে কম</option>
              <option value="rating">সর্বোচ্চ রেটিং</option>
            </select>
          </div>
        </div>
      </div>

      {/* Menu Grid */}
      {filteredAndSortedItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAndSortedItems.map((item) => (
            <FoodCard
              key={item.id}
              item={item}
              cartQuantity={cartItemCounts[item.id] || 0}
              onAddToCart={onAddToCart}
              onUpdateQuantity={onUpdateQuantity}
              onOpenDetails={onOpenDetails}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="glass-panel text-center py-16 px-4 rounded-3xl border border-dashed border-[#E60067]/40 max-w-lg mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#1F0520] border border-[#FFD700]/40 flex items-center justify-center mx-auto text-[#FFD700]">
            <Search className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">কোনো খাবার খুঁজে পাওয়া যায়নি!</h3>
            <p className="text-xs sm:text-sm text-gray-400 mt-1">
              "{searchQuery}" দিয়ে কোনো আইটেম পাওয়া যায়নি। অন্য কোনো নাম দিয়ে সার্চ করুন অথবা ফিল্টার ক্লিয়ার করুন।
            </p>
          </div>
          <button
            onClick={() => {
              onSearchChange('');
              onSelectCategory('all');
            }}
            className="bg-[#E60067] hover:bg-pink-600 text-white font-bold px-5 py-2 rounded-xl text-xs transition"
          >
            সব খাবার পুনরায় দেখুন
          </button>
        </div>
      )}
    </section>
  );
};
