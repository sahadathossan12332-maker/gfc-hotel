import { CategoryId, MenuItem, Review } from '../types';

export const CATEGORIES: { id: CategoryId; nameBn: string; nameEn: string; icon: string }[] = [
  { id: 'all', nameBn: 'সব খাবার', nameEn: 'All Dishes', icon: 'Utensils' },
  { id: 'combo', nameBn: 'কম্বো প্যাকেজ', nameEn: 'Combo Packages', icon: 'Boxes' },
  { id: 'burger', nameBn: 'বার্গার', nameEn: 'Burgers', icon: 'Flame' },
  { id: 'pizza', nameBn: 'পিজ্জা', nameEn: 'Pizza', icon: 'Pizza' },
  { id: 'appetizer', nameBn: 'অ্যাপেটাইজার', nameEn: 'Appetizers', icon: 'UtensilsCrossed' },
  { id: 'fry_bbq', nameBn: 'ফ্রাই ও গ্রিল', nameEn: 'Fry & BBQ', icon: 'Drumstick' },
  { id: 'sandwich', nameBn: 'স্যান্ডউইচ ও শর্মা', nameEn: 'Sandwiches & Shawarma', icon: 'Sandwich' },
  { id: 'soup_pasta', nameBn: 'স্যুপ, পাস্তা ও নুডুলস', nameEn: 'Soup, Pasta & Noodles', icon: 'Soup' },
  { id: 'set_combo', nameBn: 'সেট মেনু', nameEn: 'Set Menu', icon: 'Boxes' },
  { id: 'platter_rice', nameBn: 'প্ল্যাটার ও বিরিয়ানি', nameEn: 'Platters & Rice', icon: 'Salad' },
  { id: 'masala_curry', nameBn: 'মাসালা ও সিজলিং', nameEn: 'Masala & Sizzling', icon: 'Flame' },
  { id: 'naan_salad', nameBn: 'নান ও সালাদ', nameEn: 'Naan & Salad', icon: 'Wheat' },
  { id: 'dessert', nameBn: 'মিষ্টি ও ডেজার্ট', nameEn: 'Desserts', icon: 'IceCream' },
  { id: 'drinks', nameBn: 'কফি, জুস ও লাচ্ছি', nameEn: 'Drinks & Juice', icon: 'Coffee' },
  { id: 'party_pkg', nameBn: 'পার্টি প্যাকেজ', nameEn: 'Party Packages', icon: 'PartyPopper' }
];

export const MENU_ITEMS: MenuItem[] = [
  // ==========================================
  // 1. BURGERS (Page 03)
  // ==========================================
  {
    id: 'b1',
    name: 'রেগুলার চিকেন বার্গার',
    nameEn: 'Regular Chicken Burger',
    category: 'burger',
    price: 140,
    image: '/images/regenerated_image_1792331117966.jpg',
    description: 'চিকেন, সতেজ লেটুস পাতা, টমেটো ও জি.এফ.সি. স্পেশাল মেয়নিজ সস দিয়ে তৈরি (এটিতে কোনো চিজ থাকে না, চাইলে এক্সট্রা চিজ যোগ করতে পারেন)।',
    descriptionEn: 'Juicy chicken patty, fresh lettuce, tomato slice, and GFC signature mayo sauce in a soft bun (No cheese included, extra cheese available as add-on).',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8,
    addons: [
      { name: 'এক্সট্রা চিজ স্লাইস', price: 30 },
      { name: 'চিকেন পেটি ডাবল', price: 70 },
      { name: 'স্পাইসি নাগা সস', price: 20 }
    ]
  },
  {
    id: 'b2',
    name: 'ক্রিসপি চিকেন চিজ বার্গার',
    nameEn: 'Crispy Chicken Cheese Burger',
    category: 'burger',
    price: 200,
    originalPrice: 220,
    image: '/images/regenerated_image_1792333235192.jpg',
    description: 'মুচমুচে ফ্রাইড চিকেন ফিলে, মেল্টেড চিজ ও সিক্রেট বার্গার সসের অনন্য স্বাদ।',
    descriptionEn: 'Super crunchy fried chicken fillet topped with melted cheddar cheese slice & secret spices.',
    isPopular: true,
    isChefSpecial: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা মেল্টেড চিজ', price: 35 },
      { name: 'ফ্রাইড এগ (ডিম)', price: 25 },
      { name: 'ফ্রেঞ্চ ফ্রাই কম্বো', price: 50 }
    ]
  },
  {
    id: 'b3',
    name: 'জুরি চিকেন চিজ বার্গার',
    nameEn: 'Jury Chicken Cheese Burger',
    category: 'burger',
    price: 250,
    image: '/images/regenerated_image_1792331249475.jpg',
    description: 'ডাবল চিকেন প্যাটি, ডাবল চিজ স্লাইস ও বিশেষ সসে তৈরি স্পেশাল জুসি বার্গার।',
    descriptionEn: 'Double juicy chicken patty loaded with double melted cheese and signature house dressing.',
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'b4',
    name: 'বারবিকিউ চিজ বার্গার',
    nameEn: 'B.B.Q. Chicken Cheese Burger',
    category: 'burger',
    price: 230,
    image: '/images/regenerated_image_1792330698775.jpg',
    description: 'স্মোকি বারবিকিউ সসে মাখানো চিকেন প্যাটি, ক্যারামেলাইজড পেঁয়াজ ও চিজি টপিংস।',
    descriptionEn: 'Smoky BBQ glazed chicken patty with caramelized onions and cheddar cheese slice.',
    isChefSpecial: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },
  {
    id: 'b5',
    name: 'নাগা চিকেন চিজ বার্গার',
    nameEn: 'Naga Chicken Cheese Burger',
    category: 'burger',
    price: 500,
    image: '/images/regenerated_image_1792330861462.jpg',
    description: 'প্রকৃত ঝালপ্রেমীদের জন্য আসল নাগা মরিচের এক্সট্রিম স্পাইসি মেয়নিজ ও চিজ বার্গার।',
    descriptionEn: 'Fiery authentic naga morich chili sauce with tender chicken and melted cheese slice.',
    isSpicy: true,
    prepTime: '15-20 মিনিট',
    rating: 4.7
  },
  {
    id: 'b6',
    name: 'প্রিমিয়াম বিফ বার্গার',
    nameEn: 'Premium Beef Burger',
    category: 'burger',
    price: 300,
    image: '/images/regenerated_image_1792331899168.jpg',
    description: '১০০% তাজা দেশি গরুর মাংসের জুসি গ্রিলড প্যাটি, চিজ ও বিশেষ স্পাইসি বার্গার সস।',
    descriptionEn: '100% prime ground beef patty char-grilled with cheddar cheese, lettuce, and secret relish.',
    isChefSpecial: true,
    prepTime: '20-25 মিনিট',
    rating: 5.0
  },
  {
    id: 'b7',
    name: 'ডাবল লেয়ার চিজ বার্গার',
    nameEn: 'Double Layer Cheese Burger',
    category: 'burger',
    price: 320,
    image: '/images/regenerated_image_1792332643793.jpg',
    description: 'ডাবল ক্রিস্পি চিকেন লেয়ার ও ডাবল চিজ ওভারলোডেড সবচেয়ে বড় ও তৃপ্তিদায়ক বার্গার।',
    descriptionEn: 'Double layer giant crispy chicken fillets topped with layers of rich cheddar cheese.',
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },

  // ==========================================
  // 2. PIZZA (Cover Page)
  // ==========================================
  {
    id: 'p1',
    name: 'চিকেন ইতালিয়ান পিজ্জা',
    nameEn: 'Chicken Italian Pizza',
    category: 'pizza',
    price: 400,
    image: '/images/regenerated_image_1792333875708.jpg',
    description: 'হাতে গড়া নরম ক্রাস্ট, প্রিমিয়াম মোজারেলা চিজ, কিউব চিকেন, অলিভ ও ইতালিয়ান ওরিগ্যানো।',
    descriptionEn: 'Hand-tossed crust with premium mozzarella, Italian herb chicken, capsicum & black olives.',
    isPopular: true,
    prepTime: '25-30 মিনিট',
    rating: 4.9,
    availableSizes: [
      { size: '8 ইঞ্চি', price: 400 },
      { size: '10 ইঞ্চি', price: 600 },
      { size: '12 ইঞ্চি', price: 700 }
    ]
  },
  {
    id: 'p2',
    name: 'ম্যাক্সিকান চিকেন স্পাইসি পিজ্জা',
    nameEn: 'Mexican Chicken Spicy Pizza',
    category: 'pizza',
    price: 420,
    image: '/images/regenerated_image_1792333991665.jpg',
    description: 'মেক্সিকান স্পাইসি হট সস, হ্যালপেনো, ক্যাপসিকাম, লাল মরিচ ও মশলাদার চিকেন।',
    descriptionEn: 'Mexican spicy salsa base, marinated chicken, jalapenos, bell peppers & stretchy mozzarella.',
    isSpicy: true,
    prepTime: '25-30 মিনিট',
    rating: 4.8,
    availableSizes: [
      { size: '8 ইঞ্চি', price: 420 },
      { size: '10 ইঞ্চি', price: 650 },
      { size: '12 ইঞ্চি', price: 750 }
    ]
  },
  {
    id: 'p3',
    name: 'বারবিকিউ চিকেন পিজ্জা',
    nameEn: 'Chicken Pizza',
    category: 'pizza',
    price: 420,
    image: '/images/regenerated_image_1792336631638.jpg',
    description: 'স্মোকি বারবিকিউ ফ্লেভার চিকেন, ক্যারামেলাইজড পেঁয়াজ ও গলিত চিজের পারফেক্ট কম্বিনেশন।',
    descriptionEn: 'Smoked BBQ chicken chunks, caramelized onions, BBQ drizzle and pure melted mozzarella.',
    isChefSpecial: true,
    prepTime: '25-30 মিনিট',
    rating: 4.9,
    availableSizes: [
      { size: '8 ইঞ্চি', price: 420 },
      { size: '10 ইঞ্চি', price: 650 },
      { size: '12 ইঞ্চি', price: 750 }
    ]
  },
  {
    id: 'p4',
    name: 'ফোর সিজন পিজ্জা',
    nameEn: 'Four Season Pizza',
    category: 'pizza',
    price: 580,
    image: '/images/regenerated_image_1792336262321.jpg',
    description: 'এক পিজ্জাতে চারটি ভিন্ন ফ্লেভারের স্বাদের রাজকীয় মেলবন্ধন।',
    descriptionEn: 'Four quadrant specialty pizza offering four unique topping sensations on one crust.',
    isPopular: true,
    prepTime: '30 মিনিট',
    rating: 4.9,
    availableSizes: [
      { size: '10 ইঞ্চি', price: 580 },
      { size: '12 ইঞ্চি', price: 700 }
    ]
  },
  {
    id: 'p5',
    name: 'জিএফসি স্পেশাল চিকেন পিজ্জা',
    nameEn: 'GFC Special Chicken Pizza',
    category: 'pizza',
    price: 500,
    image: '/images/regenerated_image_1792336395421.jpg',
    description: 'আমাদের নিজস্ব শেফের বিশেষ সিক্রেট চিকেন রেসিপি, এক্সট্রা চিজ বাবল ও মাশরুম।',
    descriptionEn: 'Signature house blend with loaded seasoned chicken, rich cheese blend, sweet corn and mushrooms.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '25-30 মিনিট',
    rating: 5.0,
    availableSizes: [
      { size: '8 ইঞ্চি', price: 500 },
      { size: '10 ইঞ্চি', price: 700 },
      { size: '12 ইঞ্চি', price: 900 }
    ]
  },
  {
    id: 'p6',
    name: 'জিএফসি স্পেশাল বিফ পিজ্জা',
    nameEn: 'GFC Special Beef Pizza',
    category: 'pizza',
    price: 550,
    image: '/images/regenerated_image_1792333728381.jpg',
    description: 'রসালো প্রিমিয়াম বিফ টপিংস, ব্ল্যাক অলিভ, ক্যাপসিকাম ও ডাবল মোজারেলা চিজ।',
    descriptionEn: 'Loaded tender seasoned beef chunks, capsicum, olives and luxurious melted cheese.',
    isChefSpecial: true,
    prepTime: '30 মিনিট',
    rating: 5.0,
    availableSizes: [
      { size: '8 ইঞ্চি', price: 550 },
      { size: '10 ইঞ্চি', price: 750 },
      { size: '12 ইঞ্চি', price: 950 }
    ]
  },

  // ==========================================
  // 3. APPETIZERS (Page 01)
  // ==========================================
  {
    id: 'app1',
    name: 'ফ্রেঞ্চ ফ্রাই',
    nameEn: 'French Fry',
    category: 'appetizer',
    price: 150,
    image: '/images/regenerated_image_1792334056531.jpg',
    description: 'মুচমুচে সোনালী গোল্ডেন ক্রিস্পি ফ্রাই সাথে টমেটো ও চিলি সস।',
    descriptionEn: 'Golden crispy deep-fried potato fries with tomato ketchup.',
    prepTime: '10 মিনিট',
    rating: 4.7
  },
  {
    id: 'app2',
    name: 'মিট বক্স',
    nameEn: 'Meat Box',
    category: 'appetizer',
    price: 220,
    image: '/images/regenerated_image_1792334179588.jpg',
    description: 'চিকেন কিউব, সসেজ, ফ্রাই ও গলিত স্পেশাল মেয়ো-চিজ সসে ভরপুর মিট বক্স।',
    descriptionEn: 'Layers of crispy fries, diced chicken, sliced sausage, and generous cheese-mayo dressing.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.9
  },
  {
    id: 'app3',
    name: 'ফ্রাইড ওয়ানথন (৬ পিস)',
    nameEn: 'Fried Wonton 6 Pcs',
    category: 'appetizer',
    price: 220,
    image: '/images/regenerated_image_1792334314084.jpg',
    description: 'চিকেন কিমা ভর্তি মুচমুচে ফ্রাইড ওয়ানথন সাথে সুইট অ্যান্ড স্পাইসি চিলি সস।',
    descriptionEn: 'Crispy deep-fried wonton pouches stuffed with savory seasoned minced chicken.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'app4',
    name: 'নাচোস',
    nameEn: 'Nachos',
    category: 'appetizer',
    price: 300,
    image: '/images/regenerated_image_1792334390229.jpg',
    description: 'মুচমুচে টর্টিলা চিপস, চিকেন, ফ্রেশ সালসা ও গলিত চিজি টপিং।',
    descriptionEn: 'Crisp tortilla chips topped with spiced chicken, tomato salsa, jalapenos and creamy melted cheese.',
    isChefSpecial: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'app5',
    name: 'ফ্রাইড মাশরুম',
    nameEn: 'Fried Mushrooms',
    category: 'appetizer',
    price: 250,
    image: '/images/regenerated_image_1792334494069.jpg',
    description: 'ব্যাটার কোটেড মুচমুচে ফ্রাইড ফ্রেশ বাটন মাশরুম।',
    descriptionEn: 'Crispy golden batter-fried whole button mushrooms seasoned with aromatic spices.',
    prepTime: '15 মিনিট',
    rating: 4.6
  },
  {
    id: 'app6',
    name: 'গার্লিক মাশরুম',
    nameEn: 'Garlic Mushrooms',
    category: 'appetizer',
    price: 280,
    image: '/images/regenerated_image_1792334912908.jpg',
    description: 'খাঁটি বাটার ও রসুনে হালকা আঁচে সঁতে করা রসালো বাটন মাশরুম।',
    descriptionEn: 'Button mushrooms sautéed in pure butter, minced garlic, cracked pepper and fresh herbs.',
    prepTime: '15 মিনিট',
    rating: 4.7
  },
  {
    id: 'app7',
    name: 'চিকেন ললিপপ',
    nameEn: 'Chicken Lollipop',
    category: 'appetizer',
    price: 240,
    image: '/images/regenerated_image_1792336475661.jpg',
    description: 'মশলায় ম্যারিনেট করা মুচমুচে ফ্রাইড চিকেন উইংলেট ললিপপ।',
    descriptionEn: 'Crispy fried frenched chicken winglets coated in spicy house batter.',
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'app8',
    name: 'ক্রিস্পি উইংস',
    nameEn: 'Crispy Wings',
    category: 'appetizer',
    price: 280,
    image: '/images/regenerated_image_1792336558207.jpg',
    description: 'স্পেশাল ক্রাঞ্চি ক্রাম্ব কোটেড মুচমুচে চিকেন উইংস।',
    descriptionEn: 'Golden crispy crumb-coated chicken wings served piping hot with garlic dip.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },
  {
    id: 'app9',
    name: 'পেরি পেরি স্পাইসি উইংস',
    nameEn: 'Peri Peri Spicy Wings',
    category: 'appetizer',
    price: 320,
    image: '/images/regenerated_image_1792336724371.jpg',
    description: 'ঝাল পেরি পেরি সসে মাখানো টক-ঝাল গরম চিকেন উইংস।',
    descriptionEn: 'Tender chicken wings tossed in fiery African peri peri sauce and herbs.',
    isSpicy: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'app10',
    name: 'বারবিকিউ চিকেন উইংস',
    nameEn: 'B.B.Q Chicken Wings',
    category: 'appetizer',
    price: 300,
    image: '/images/regenerated_image_1792335295734.jpg',
    description: 'স্মোকি বারবিকিউ গ্লেজ সসে মাখানো সুস্বাদু রোস্টেড চিকেন উইংস।',
    descriptionEn: 'Juicy wings glazed in thick smoky-sweet hickory BBQ barbecue sauce.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },

  // ==========================================
  // 4. FRY CHICKEN & GRILLED / BBQ (Page 02 & 10)
  // ==========================================
  {
    id: 'fry1',
    name: 'চিকেন ফ্রাই (২ পিস)',
    nameEn: 'Chicken Fry (2 Pcs)',
    category: 'fry_bbq',
    price: 160,
    image: '/images/regenerated_image_1792336844110.jpg',
    description: 'বাইরে থেকে দারুণ মুচমুচে আর ভেতরে জুসি গরম চিকেন ফ্রাই (২ পিস)।',
    descriptionEn: 'Crunchy golden deep-fried chicken 2 pieces served hot with house dip.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'fry2',
    name: 'চিকেন ফ্রাই (৪ পিস)',
    nameEn: 'Chicken Fry (4 Pcs)',
    category: 'fry_bbq',
    price: 300,
    image: '/images/regenerated_image_1792337036293.jpg',
    description: 'পরিবার বা বন্ধুদের সাথে শেয়ার করার জন্য ৪ পিস মুচমুচে চিকেন ফ্রাই।',
    descriptionEn: 'Generous 4 pieces of crispy fried chicken perfection.',
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'fry3',
    name: 'ব্রোস্ট চিকেন (২ পিস)',
    nameEn: 'Broast Chicken (2 Pcs)',
    category: 'fry_bbq',
    price: 240,
    image: '/images/regenerated_image_1792337037843.jpg',
    description: 'প্রেসার ফ্রাইড স্পেশাল ব্রোস্ট চিকেন (২ পিস), যা এক্সট্রা ক্রিস্পি ও জুসি।',
    descriptionEn: 'Authentic pressure-fried broasted chicken 2 pieces sealing in all natural juices.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'fry4',
    name: 'ব্রোস্ট চিকেন (৪ পিস)',
    nameEn: 'Broast Chicken (4 Pcs)',
    category: 'fry_bbq',
    price: 450,
    image: '/images/regenerated_image_1792337820264.jpg',
    description: '৪ পিস ফ্যামিলি সাইজ স্পেশাল ক্রিস্পি ব্রোস্টেড চিকেন।',
    descriptionEn: 'Full 4-piece broasted crispy chicken platter with signature spices.',
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'grill1',
    name: 'চিকেন গ্রিল',
    nameEn: 'Chicken Grilled (Full / Half / Quarter)',
    category: 'fry_bbq',
    price: 480,
    image: '/images/regenerated_image_1792338020039.jpg',
    description: 'কয়লার আঁচে পোড়ানো অত্যন্ত জুসি ও সুস্বাদু গ্রিল চিকেন সাথে স্পেশাল সালাদ ও মেয়ো সস। পুরোটা (ফুল), হাফ এবং এক ফোঁয়া সাইজে উপলব্ধ।',
    descriptionEn: 'Juicy charcoal-grilled chicken marinated with authentic barbecue spices, served with fresh salad & special sauce. Available in Full, Half, and Quarter (Ek Foya) portions.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9,
    availableSizes: [
      { size: 'ফুল', price: 480 },
      { size: 'হাফ', price: 240 },
      { size: 'এক কোয়াটার', price: 120 }
    ],
    addons: [
      { name: 'স্পেশাল বাটার নান রুটি', price: 40 },
      { name: 'গার্লিক মেয়ো সস', price: 25 },
      { name: 'এক্সট্রা সালাদ ও চাটনি', price: 20 }
    ]
  },
  {
    id: 'grill2',
    name: 'তান্দুরি চিকেন (১ পিস)',
    nameEn: 'Tandoori Chicken (1 Pc)',
    category: 'fry_bbq',
    price: 150,
    image: '/images/regenerated_image_1792338123242.jpg',
    description: 'তান্দুরে পোড়ানো লাল মশলাদার সুস্বাদু তান্দুরি চিকেন কোয়ার্টার পিস।',
    descriptionEn: 'Classic clay-oven roasted chicken quarter marinated in yogurt, tandoori spices and lemon.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'grill3',
    name: 'চিকেন চাপ',
    nameEn: 'Chicken Chaap',
    category: 'fry_bbq',
    price: 140,
    image: '/images/regenerated_image_1792338326592.jpg',
    description: 'তাওয়ায় ঘিয়ে ভাজা ঐতিহ্যবাহী মশলাদার মুচমুচে চিকেন চাপ।',
    descriptionEn: 'Traditional slow shallow-fried chicken chaap seasoned with aromatic Mughlai spices.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'grill4',
    name: 'বিফ শিক কাবাব',
    nameEn: 'Beef Shik Kabab',
    category: 'fry_bbq',
    price: 250,
    image: '/images/regenerated_image_1792338843668.jpg',
    description: 'কয়লায় ঝলসানো নরম ও জুসি মশলাদার বিফ শিক কাবাব।',
    descriptionEn: 'Tender ground beef skewer seasoned with traditional seekh spices and grilled over hot coals.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'grill5',
    name: 'বারবিকিউ ফিশ (সুরমা)',
    nameEn: 'B.B.Q. Fish (Surma)',
    category: 'fry_bbq',
    price: 380,
    image: '/images/regenerated_image_1792338845398.jpg',
    description: 'তাজা সুরমা মাছের বারবিকিউ, কয়লার আঁচে পোড়া মশলাদার ফিশ ফ্রাই।',
    descriptionEn: 'Whole fresh Surma fish seasoned with tangy spicy rub and slow-grilled over charcoal.',
    prepTime: '25 মিনিট',
    rating: 4.7
  },
  {
    id: 'grill6',
    name: 'বারবিকিউ ফিশ (কোরাল)',
    nameEn: 'B.B.Q. Fish (Koral)',
    category: 'fry_bbq',
    price: 480,
    image: '/images/regenerated_image_1792338947230.jpg',
    description: 'প্রিমিয়াম কোরাল মাছের রাজকীয় বারবিকিউ সাথে লেবু ও পুদিনার সালাদ।',
    descriptionEn: 'Deluxe fresh Koral sea bass fish char-grilled to perfection with special marinade.',
    isChefSpecial: true,
    prepTime: '25-30 মিনিট',
    rating: 5.0
  },

  // ==========================================
  // 5. SANDWICH & SHAWARMA (Page 02)
  // ==========================================
  {
    id: 'snd1',
    name: 'চিকেন স্যান্ডউইচ',
    nameEn: 'Chicken Sandwich',
    category: 'sandwich',
    price: 120,
    image: '/images/regenerated_image_1792339261585.jpg',
    description: 'চিকেন স্প্রেড, শসা, মেয়ো ও টোস্টেড পাউরুটি দিয়ে তৈরি ফ্রেশ স্যান্ডউইচ।',
    descriptionEn: 'Toasted bread filled with shredded seasoned chicken, cucumber, lettuce and light mayo.',
    prepTime: '10 মিনিট',
    rating: 4.6
  },
  {
    id: 'snd2',
    name: 'ক্লাব স্যান্ডউইচ',
    nameEn: 'Club Sandwich',
    category: 'sandwich',
    price: 200,
    image: '/images/regenerated_image_1792339263491.jpg',
    description: 'ট্রিপল লেয়ার টোস্টেড পাউরুটি, চিকেন, ডিমের ওমলেট, চিজ ও সালাদ।',
    descriptionEn: 'Double-decker toasted sandwich packed with chicken breast, fried egg, cheese and crisp lettuce.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'snd3',
    name: 'রেগুলার সাব স্যান্ডউইচ',
    nameEn: 'Regular Sub Sandwich',
    category: 'sandwich',
    price: 170,
    image: '/images/regenerated_image_1792339264700.jpg',
    description: 'লম্বা নরম সাব বান, রোস্টেড চিকেন স্ট্রিপস, সালাদ ও মেয়নিজ।',
    descriptionEn: 'Fresh sub roll filled with grilled seasoned chicken strips, crispy vegetables and special sauce.',
    prepTime: '12 মিনিট',
    rating: 4.7
  },
  {
    id: 'snd4',
    name: 'চিজ সাব স্যান্ডউইচ',
    nameEn: 'Cheese Sub Sandwich',
    category: 'sandwich',
    price: 200,
    image: '/images/regenerated_image_1792339265687.jpg',
    description: 'মেল্টেড চিজ ও রসালো চিকেনে ভর্তি চিজি সাব স্যান্ডউইচ।',
    descriptionEn: 'Warm sub loaded with tender chicken, melted cheddar cheese sauce and fresh veggies.',
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'snd5',
    name: 'বারবিকিউ সাব স্যান্ডউইচ',
    nameEn: 'B.B.Q Sub Sandwich',
    category: 'sandwich',
    price: 190,
    image: '/images/regenerated_image_1792339614519.jpg',
    description: 'স্মোকি বারবিকিউ চিকেন, ক্যারামেলাইজড পেঁয়াজ ও স্পাইসি সস সাব।',
    descriptionEn: 'Tender chicken glazed in smoky barbecue sauce in a soft sub roll with crisp greens.',
    prepTime: '15 মিনিট',
    rating: 4.8
  },
  {
    id: 'snd6',
    name: 'চিকেন শর্মা',
    nameEn: 'Chicken Shawarma',
    category: 'sandwich',
    price: 150,
    image: '/images/regenerated_image_1792339615759.jpg',
    description: 'মশলাদার রোটিসারি চিকেন, এরাবিয়ান গার্লিক মেয়ো সস ও পাতলা রুটি রোল।',
    descriptionEn: 'Authentic Middle Eastern spiced chicken wrap with tangy garlic toum and pickles.',
    isPopular: true,
    prepTime: '10-15 মিনিট',
    rating: 4.9
  },

  // ==========================================
  // 6. SOUP, NOODLES, PASTA & KHICHURI (Page 03 & 04)
  // ==========================================
  {
    id: 'sp1',
    name: 'থাই স্যুপ (১:২)',
    nameEn: 'Thai Soup (1:2)',
    category: 'soup_pasta',
    price: 250,
    image: '/images/regenerated_image_1792339617005.jpg',
    description: 'লেমনগ্রাস, থাই পাতা, চিকেন ও প্রনযুক্ত আসল ঘন থাই স্যুপ (২ জনের জন্য)।',
    descriptionEn: 'Aromatic thick authentic Thai soup with chicken, fresh herbs, prawns and chili oil.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },
  {
    id: 'sp2',
    name: 'থাই স্যুপ (১:৩)',
    nameEn: 'Thai Soup (1:3)',
    category: 'soup_pasta',
    price: 380,
    image: '/images/regenerated_image_1792339618465.jpg',
    description: '৩ জনের ফ্যামিলি বাটি সুস্বাদু আসল থাই স্যুপ।',
    descriptionEn: 'Family bowl thick rich Thai soup portion for 3 guests with generous chicken & prawns.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'sp3',
    name: 'চিকেন কর্ন স্যুপ',
    nameEn: 'Chicken Corn Soup',
    category: 'soup_pasta',
    price: 200,
    image: '/images/regenerated_image_1792339619471.jpg',
    description: 'হালকা ও পুষ্টিকর তাজা সুইট কর্ন, চিকেন কুচি ও ডিমের স্যুপ।',
    descriptionEn: 'Comforting warm soup made with tender shredded chicken, sweet corn and ribbon egg drop.',
    prepTime: '15 মিনিট',
    rating: 4.7,
    availableSizes: [
      { size: '১:২ (২ জন)', price: 200 },
      { size: 'ফুল (১:৩)', price: 320 }
    ]
  },
  {
    id: 'sp4',
    name: 'মাশরুম স্যুপ (১:৩)',
    nameEn: 'Mushrooms Soup (1:3)',
    category: 'soup_pasta',
    price: 320,
    image: '/images/regenerated_image_1792339782966.jpg',
    description: 'ফ্রেশ বাটন মাশরুম ও ক্রিমি ঘন ব্রথ মিশ্রিত সুস্বাদু স্যুপ (৩ জনের জন্য)।',
    descriptionEn: 'Rich creamy mushroom soup with sautéed button mushrooms and savory broth for 3.',
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'sp5',
    name: 'ভেজিটেবল স্যুপ (১:৩)',
    nameEn: 'Vegetable Soup (1:3)',
    category: 'soup_pasta',
    price: 300,
    image: '/images/regenerated_image_1792339783955.jpg',
    description: 'টাটকা মৌসুমি সবজির হালকা পুষ্টিকর গরম ক্লিয়ার ভেজিটেবল স্যুপ (৩ জন)।',
    descriptionEn: 'Wholesome clear vegetable broth filled with assorted farm-fresh colorful vegetables.',
    isVegetarian: true,
    prepTime: '15 মিনিট',
    rating: 4.6
  },
  {
    id: 'sp6',
    name: 'জি.এফ.সি. স্পেশাল স্যুপ (১:৩)',
    nameEn: 'GFC Special Soup (1:3)',
    category: 'soup_pasta',
    price: 450,
    image: '/images/regenerated_image_1792339973407.jpg',
    description: 'চিকেন, চিংড়ি, মাশরুম ও বিশেষ শেফ সিক্রেট স্পাইসের স্পেশাল প্রিমিয়াম স্যুপ।',
    descriptionEn: 'Our grand house master soup loaded with chicken, prawns, mushrooms and savory richness.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'ndl1',
    name: 'চিকেন নুডুলস (১:২)',
    nameEn: 'Chicken Noodles (1:2)',
    category: 'soup_pasta',
    price: 320,
    image: '/images/regenerated_image_1792339974402.jpg',
    description: 'চাইনিজ ওক-টসে তৈরি মশলাদার চিকেন ও ডিম নুডুলস (২ জনের জন্য)।',
    descriptionEn: 'Chinese wok-tossed chow mein noodles with chicken strips, egg ribbon and fresh bell peppers.',
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'ndl2',
    name: 'এগ ভেজিটেবল নুডুলস (১:২)',
    nameEn: 'Egg Vegetable Noodles (1:2)',
    category: 'soup_pasta',
    price: 280,
    image: '/images/regenerated_image_1792340343760.jpg',
    description: 'ডিম ও টাটকা নানা রকমের রঙিন সবজি সহযোগে তৈরি নুডুলস।',
    descriptionEn: 'Stir-fried classic noodles with scrambled egg, shredded cabbage, carrots and spring onions.',
    prepTime: '15-20 মিনিট',
    rating: 4.7
  },
  {
    id: 'ndl3',
    name: 'মিক্স নুডুলস (১:২)',
    nameEn: 'Mix Noodles (1:2)',
    category: 'soup_pasta',
    price: 400,
    image: '/images/regenerated_image_1792340345113.jpg',
    description: 'চিকেন, বিফ, প্রন ও এগ মিশ্রিত সুস্বাদু স্পেশাল মিক্সড নুডুলস।',
    descriptionEn: 'Deluxe combination noodles with tender chicken, spiced beef, juicy prawns and scrambled egg.',
    isChefSpecial: true,
    prepTime: '20-25 মিনিট',
    rating: 4.9
  },
  {
    id: 'pst1',
    name: 'চিকেন পাস্তা (১:২)',
    nameEn: 'Chicken Pasta (1:2)',
    category: 'soup_pasta',
    price: 320,
    image: '/images/regenerated_image_1792340346409.jpg',
    description: 'চিকেন কিউব, চিজ ও টমেটো-হার্ব সসে তৈরি পেন্নে পাস্তা।',
    descriptionEn: 'Penne pasta tossed in a savory tomato-herb sauce with seasoned chicken and parmesan.',
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'pst2',
    name: 'ইতালিয়ান স্পাইসি পাস্তা (১:২)',
    nameEn: 'Italian Spicy Pasta (1:2)',
    category: 'soup_pasta',
    price: 350,
    image: '/images/regenerated_image_1792340347561.jpg',
    description: 'ইতালিয়ান হট সস, লাল মরিচের কুচি ও ওরিগ্যানো ফ্লেভারে ঝাল পাস্তা।',
    descriptionEn: 'Fiery Italian arrabbiata style penne pasta cooked with chili flakes, garlic and herb chicken.',
    isSpicy: true,
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'pst3',
    name: 'চিজ ক্রিমি পাস্তা (১:২)',
    nameEn: 'Cheese Creamy Pasta (1:2)',
    category: 'soup_pasta',
    price: 420,
    image: '/images/regenerated_image_1792340348941.jpg',
    description: 'ওভেন বেকড প্রচুর মেল্টেড চিজ ও হোয়াইট সসে ভরপুর প্রিমিয়াম চিজি পাস্তা।',
    descriptionEn: 'Rich baked pasta generously coated in velvet creamy white bechamel and melted mozzarella.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '25 মিনিট',
    rating: 5.0
  },
  {
    id: 'pst4',
    name: 'মিক্স পাস্তা (১:২)',
    nameEn: 'Mixed Pasta (1:2)',
    category: 'soup_pasta',
    price: 400,
    image: '/images/regenerated_image_1792340350321.jpg',
    description: 'চিকেন, বিফ ও চিজের সমন্বয়ে তৈরি দারুণ স্বাদের মিক্স পাস্তা।',
    descriptionEn: 'Fusion pasta cooked with flavorful chunks of chicken and beef in a rich mixed sauce.',
    prepTime: '20-25 মিনিট',
    rating: 4.9
  },
  {
    id: 'khc1',
    name: 'চিকেন খিচুড়ি',
    nameEn: 'Chicken Khichuri',
    category: 'platter_rice',
    price: 280,
    image: '/images/regenerated_image_1792340351586.jpg',
    description: 'সুগন্ধি পোলাও চাল ও মুগ ডালের খাঁটি ভুনা খিচুড়ি সাথে রোস্টেড চিকেন ও সিদ্ধ ডিম।',
    descriptionEn: 'Aromatic roasted moong dal & chinigura rice khichuri paired with spicy chicken roast & boiled egg.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },
  {
    id: 'khc2',
    name: 'বিফ খিচুড়ি',
    nameEn: 'Beef Khichuri',
    category: 'platter_rice',
    price: 320,
    image: '/images/regenerated_image_1792340496215.jpg',
    description: 'ঘরোয়া মশলায় রান্না করা নরম বিফ ভুনা সহযোগে গরম ভুনা খিচুড়ি।',
    descriptionEn: 'Rich slow-cooked beef curry paired with piping-hot aromatic Bengali style khichuri.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },

  // ==========================================
  // 7. COMBO PACKAGES (Page 07, 08)
  // ==========================================
  {
    id: 'cb1',
    name: 'কম্বো ০১ (চিকেন চিলি অনিয়ন + বাটার নান + সালাদ)',
    nameEn: 'Combo 01 - Chicken Chili Onion + Butter Naan + Salad',
    category: 'combo',
    price: 200,
    image: '/images/combo_chili_naan_1792470132988.jpg',
    description: 'চিকেন চিলি অনিয়ন + বাটার নান + সালাদ। চাইনিজ স্টাইলের সুস্বাদু চিকেন চিলি অনিয়ন সাথে গরম তুলতুলে তান্দুরি বাটার নান ও সতেজ সালাদ।',
    descriptionEn: 'Stir-fried Chicken Chili Onion with soft tandoori butter naan and fresh green salad.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'সফট ড্রিঙ্কস (২৫০ মি.লি.)', price: 30 },
      { name: 'এক্সট্রা মেয়ো ও চাটনি', price: 20 }
    ]
  },
  {
    id: 'cb2',
    name: 'কম্বো ০২ (চিকেন মাসালা + বাটার নান + সালাদ)',
    nameEn: 'Combo 02 - Chicken Masala + Butter Naan + Salad',
    category: 'combo',
    price: 220,
    image: '/images/combo_masala_naan_1792470151387.jpg',
    description: 'চিকেন মাসালা + বাটার নান + সালাদ। ঘন মশলাদার গ্রেভির সুস্বাদু চিকেন মাসালা সাথে গরম বাটার নান এবং সতেজ সালাদ।',
    descriptionEn: 'Rich, spiced Chicken Masala curry paired with fluffy butter naan and garden salad.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'সফট ড্রিঙ্কস (২৫০ মি.লি.)', price: 30 },
      { name: 'স্পেশাল রায়তা সালাদ', price: 30 }
    ]
  },
  {
    id: 'cb3',
    name: 'কম্বো ০৩ (চিকেন আচারি + বাটার নান + সালাদ)',
    nameEn: 'Combo 03 - Chicken Achari + Butter Naan + Salad',
    category: 'combo',
    price: 240,
    image: '/images/combo_achari_naan_1792470173886.jpg',
    description: 'চিকেন আচারি + বাটার নান + সালাদ। খাঁটি আচারের সুবাসে টক-ঝাল মুখরোচক চিকেন আচারি কারি সাথে নরম বাটার নান ও সালাদ।',
    descriptionEn: 'Tangy pickle-spiced Chicken Achari curry with warm tandoor butter naan and fresh salad.',
    isSpicy: true,
    prepTime: '20 মিনিট',
    rating: 4.8,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'সফট ড্রিঙ্কস (২৫০ মি.লি.)', price: 30 }
    ]
  },
  {
    id: 'cb4',
    name: 'কম্বো ০৪ (ক্রিস্পি চিজ বার্গার + ফ্রেঞ্চ ফ্রাই)',
    nameEn: 'Combo 04 - Crispy Cheese Burger + French Fry',
    category: 'combo',
    price: 240,
    image: '/images/combo_burger_fry_1792470190649.jpg',
    description: 'ক্রিস্পি চিজ বার্গার + ফ্রেঞ্চ ফ্রাই। রসালো ক্রিস্পি চিকেন ও গলিত চিজে ভরা বার্গার সাথে সোনালী ক্রিস্পি ফ্রেঞ্চ ফ্রাই ও টমেটো-চিলি সস।',
    descriptionEn: 'Crunchy Chicken Cheese Burger loaded with melted cheese slice served with crispy golden french fries.',
    isPopular: true,
    isChefSpecial: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা চিজ স্লাইস', price: 30 },
      { name: 'কোল্ড কফি / সফট ড্রিঙ্কস', price: 40 }
    ]
  },
  {
    id: 'cb5',
    name: 'কম্বো ০৫ (থাই স্যুপ + ওয়ান্থন ২ পিস)',
    nameEn: 'Combo 05 - Thai Soup + Wonton (2 Pcs)',
    category: 'combo',
    price: 220,
    image: '/images/combo_thaisoup_wonton_1792470214108.jpg',
    description: 'থাই স্যুপ + ওয়ান্থন ২ পিস। লেমনগ্রাস ও খাঁটি থাই মশলার গরম ধোঁয়া ওঠা থাই স্যুপ সাথে ২ পিস মুচমুচে চিকেন ওয়ান্থন ও ডিপ সস।',
    descriptionEn: 'Steaming authentic thick Thai soup with chicken and herbs, served with 2 crispy golden wontons.',
    isPopular: true,
    isChefSpecial: true,
    prepTime: '15 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা ওয়ান্থন (২ পিস)', price: 60 },
      { name: 'স্পাইসি হট চিলি সস', price: 20 }
    ]
  },
  {
    id: 'cb6',
    name: 'কম্বো ০৬ (চিকেন তান্দুরি + বাটার নান + সালাদ + আচার)',
    nameEn: 'Combo 06 - Chicken Tandoori + Butter Naan + Salad + Pickle',
    category: 'combo',
    price: 220,
    image: '/images/combo_tandoori_naan_1792470231160.jpg',
    description: 'চিকেন তান্দুরি + বাটার নান + সালাদ + আচার। তান্দুরে পোড়ানো খাঁটি মশলাদার তান্দুরি চিকেন কোয়ার্টার, নরম তুলতুলে বাটার নান, তাজা সালাদ ও দেশি আচার।',
    descriptionEn: 'Clay-oven roasted juicy Tandoori Chicken served with fresh butter naan, garden salad and savory pickle.',
    isPopular: true,
    isChefSpecial: true,
    prepTime: '15-20 মিনিট',
    rating: 5.0,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'স্পেশাল বোরহানি', price: 40 }
    ]
  },
  {
    id: 'cb7',
    name: 'কম্বো ০৭ (চিকেন চাপ + বাটার নান + সালাদ + আচার)',
    nameEn: 'Combo 07 - Chicken Chaap + Butter Naan + Salad + Pickle',
    category: 'combo',
    price: 200,
    image: '/images/combo_chap_naan_1792470250713.jpg',
    description: 'চিকেন চাপ + বাটার নান + সালাদ + আচার। তাওয়ায় ঘিয়ে ভাজা স্পেশাল ঐতিহ্যবাহী মশলাদার চিকেন চাপ, নরম বাটার নান, পেঁয়াজ-শসার সালাদ ও আচার।',
    descriptionEn: 'Slow shallow-fried aromatic Chicken Chaap served with oven-baked butter naan, sliced salad and pickle.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'স্পেশাল বোরহানি', price: 40 }
    ]
  },
  {
    id: 'cb8',
    name: 'কম্বো ০৮ (চিকেন কাশ্মীরি + বাটার নান + সালাদ + আচার)',
    nameEn: 'Combo 08 - Chicken Kashmiri + Butter Naan + Salad + Pickle',
    category: 'combo',
    price: 200,
    image: '/images/combo_kashmiri_naan_1792470267149.jpg',
    description: 'চিকেন কাশ্মীরি + বাটার নান + সালাদ + আচার। বাদাম, কিশমিশ ও কাশ্মীরি মশলায় রান্না করা রাজকীয় স্বাদের চিকেন কাশ্মীরি, তুলতুলে বাটার নান, সালাদ ও আচার।',
    descriptionEn: 'Royal mild-sweet and nutty Kashmiri Chicken curry served with hot butter naan, fresh salad and pickle.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'সফট ড্রিঙ্কস (২৫০ মি.লি.)', price: 30 }
    ]
  },
  {
    id: 'cb9',
    name: 'কম্বো ০৯ (চিকেন গ্রিল + বাটার নান + সালাদ)',
    nameEn: 'Combo 09 - Chicken Grilled + Butter Naan + Salad',
    category: 'combo',
    price: 190,
    image: '/images/combo_grilled_naan_1792470284409.jpg',
    description: 'চিকেন গ্রিল + বাটার নান + সালাদ। কয়লার আঁচে পোড়ানো রসালো বারবিকিউ চিকেন গ্রিল কোয়ার্টার, তুলতুলে নরম বাটার নান, গার্লিক মেयो ও ফ্রেশ সালাদ।',
    descriptionEn: 'Charcoal-grilled smoky tender chicken quarter served with fresh tandoor butter naan, garlic mayo and salad.',
    isPopular: true,
    isChefSpecial: true,
    prepTime: '15-20 মিনিট',
    rating: 5.0,
    addons: [
      { name: 'এক্সট্রা বাটার নান', price: 40 },
      { name: 'গার্লিক মেয়ো সস', price: 25 },
      { name: 'স্পেশাল বোরহানি', price: 40 }
    ]
  },
  // ==========================================
  // 7.1 SET MENU (Page 06)
  // ==========================================
  {
    id: 'sm1',
    name: 'সেট মেনু ০১',
    nameEn: 'Set Menu 01',
    category: 'set_combo',
    price: 250,
    image: '/images/regenerated_image_1792382795310.jpg',
    description: 'ফ্রাইড রাইস + ক্রিস্পি চিকেন ফ্রাই + চিকেন চিলি অনিয়ন + রাইতা সালাদ।',
    descriptionEn: 'Chinese egg fried rice, golden chicken fry, chicken chili onion, and fresh raita salad.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.9
  },
  {
    id: 'sm2',
    name: 'সেট মেনু ০২',
    nameEn: 'Set Menu 02',
    category: 'set_combo',
    price: 340,
    image: '/images/regenerated_image_1792383143688.jpg',
    description: 'ফ্রাইড রাইস + তান্দুরি চিকেন কোয়ার্টার + চিকেন চিলি অনিয়ন + রাইতা সালাদ।',
    descriptionEn: 'Fried rice served with tandoori roasted chicken, chicken chili onion, and cooling raita salad.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'sm3',
    name: 'সেট মেনু ০৩',
    nameEn: 'Set Menu 03',
    category: 'set_combo',
    price: 320,
    image: '/images/regenerated_image_1792383146739.jpg',
    description: 'ফ্রাইড রাইস + চিকেন মাসালা + চাইনিজ মিক্সড ভেজিটেবল + রাইতা সালাদ।',
    descriptionEn: 'Egg fried rice, spicy chicken masala, Chinese mixed vegetable, and yogurt raita salad.',
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'sm4',
    name: 'সেট মেনু ০৪',
    nameEn: 'Set Menu 04',
    category: 'set_combo',
    price: 360,
    image: '/images/regenerated_image_1792383151066.jpg',
    description: 'ফ্রাইড রাইস + ভুনা বিফ মাসালা + চাইনিজ ভেজিটেবল + রাইতা সালাদ।',
    descriptionEn: 'Egg fried rice, tender slow-cooked beef masala, fresh Chinese vegetable, and raita.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },

  // ==========================================
  // 8. PLATTERS & RICE (Page 05 & 08)
  // ==========================================
  {
    id: 'plt1',
    name: 'প্ল্যাটার ০১ - এরাবিয়ান কাবাজ বিরিয়ানি',
    nameEn: 'Platter 01 (Arabian Kabaz Biryani)',
    category: 'platter_rice',
    price: 320,
    image: '/images/regenerated_image_1792383335533.jpg',
    description: 'এরাবিয়ান কাবাজ বিরিয়ানি + ১ পিস কক রোস্ট + আচার + রাইতা সালাদ।',
    descriptionEn: 'Fragrant Arabian spiced kabsa biryani served with whole cock chicken roast, pickle & raita.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'plt2',
    name: 'প্ল্যাটার ০২ - চিকেন হাড়ি বিরিয়ানি',
    nameEn: 'Platter 02 (Hari Biryani Chicken)',
    category: 'platter_rice',
    price: 320,
    image: '/images/regenerated_image_1792383339257.jpg',
    description: 'মাটির হাড়িতে দম দেওয়া সুস্বাদু বিরিয়ানি + চিকেন ২ পিস + আচার + রাইতা সালাদ।',
    descriptionEn: 'Clay pot steamed dum biryani with 2 pieces of spiced chicken, homemade pickle and raita.',
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'plt3',
    name: 'প্ল্যাটার ০৩ - বিফ হাড়ি বিরিয়ানি',
    nameEn: 'Platter 03 (Hari Biryani Beef)',
    category: 'platter_rice',
    price: 370,
    image: '/images/regenerated_image_1792383514368.jpg',
    description: 'মাটির হাড়ির খাঁটি দম বিরিয়ানি + নরম গরুর মাংস ভুনা + আচার + রাইতা সালাদ।',
    descriptionEn: 'Aromatic clay pot dum biryani served with melt-in-mouth beef chunks, pickle and raita.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'plt4',
    name: 'প্ল্যাটার ০৪ - হায়দ্রাবাদি বিরিয়ানি বিফ',
    nameEn: 'Platter 04 (Hydarbadi Biryani Beef)',
    category: 'platter_rice',
    price: 390,
    image: '/images/regenerated_image_1792383517499.jpg',
    description: 'ঐতিহ্যবাহী হায়দ্রাবাদি বিরিয়ানি + বিফ কারি + আচার + স্পেশাল রাইতা সালাদ।',
    descriptionEn: 'Authentic Hyderabadi layered spiced biryani with savory beef curry, pickle and raita.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'rc1',
    name: 'চিকেন ফ্রাইড রাইস (১:২)',
    nameEn: 'Chicken Fried Rice (1:2)',
    category: 'platter_rice',
    price: 300,
    image: '/images/regenerated_image_1792386209503.jpg',
    description: 'বাসমতী চালের সুস্বাদু চাইনিজ চিকেন ফ্রাইড রাইস (২ জনের জন্য)।',
    descriptionEn: 'Wok-fried premium long-grain rice tossed with seasoned chicken, egg, and spring vegetables.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'rc2',
    name: 'মিক্স ফ্রাইড রাইস (১:২)',
    nameEn: 'Mixed Fried Rice (1:2)',
    category: 'platter_rice',
    price: 350,
    image: '/images/regenerated_image_1792386213421.jpg',
    description: 'চিকেন, বিফ, প্রন ও এগ মিশ্রিত বিশেষ চাইনিজ মিক্সড ফ্রাইড রাইস (২ জন)।',
    descriptionEn: 'Master blend wok fried rice with tender chicken, spiced beef, juicy prawns and scrambled egg.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'rc3',
    name: 'জি.এফ.সি. স্পেশাল ফ্রাইড রাইস (১:২)',
    nameEn: 'GFC Special Fried Rice (1:2)',
    category: 'platter_rice',
    price: 420,
    image: '/images/regenerated_image_1792386216831.jpg',
    description: 'আমাদের শেফের স্পেশাল রেসিপির রিচ ফ্রাইড রাইস (২ জনের জন্য)।',
    descriptionEn: 'Signature grand fried rice prepared with secret house spices, cashew nuts and assorted meats.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'rc4',
    name: 'এগ ভেজিটেবল ফ্রাইড রাইস (১:২)',
    nameEn: 'Egg Vegetable Fried Rice (1:2)',
    category: 'platter_rice',
    price: 280,
    image: '/images/regenerated_image_1792386220297.jpg',
    description: 'ডিম ও টাটকা সবুজ সবজির হালকা মশলাদার ফ্রাইড রাইস (২ জন)।',
    descriptionEn: 'Fragrant wok-tossed rice with fluffy scrambled eggs, green peas, carrots and mild seasonings.',
    prepTime: '15 মিনিট',
    rating: 4.7
  },

  // ==========================================
  // 9. MASALA & SIZZLING (1:2) (Page 09)
  // ==========================================
  {
    id: 'mas1',
    name: 'চিকেন মাসালা (১:২)',
    nameEn: 'Chicken Masala (1:2)',
    category: 'masala_curry',
    price: 360,
    image: '/images/regenerated_image_1792387984922.jpg',
    description: 'ঘরোয়া সুস্বাদু মশলায় রান্না করা থিক গ্রেভির চিকেন মাসালা।',
    descriptionEn: 'Rich, aromatic chicken curry slow-cooked with tomatoes, onions and authentic spices.',
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 4.8,
    availableSizes: [
      { size: 'ব্রয়লার চিকেন', price: 360 },
      { size: 'সোনালী চিকেন', price: 420 }
    ]
  },
  {
    id: 'mas2',
    name: 'বিফ মাসালা (১:২)',
    nameEn: 'Beef Masala (1:2)',
    category: 'masala_curry',
    price: 520,
    image: '/images/regenerated_image_1792387988440.jpg',
    description: 'নরম গরুর মাংসের কষা ভুনা মাসালা কারি (২ জনের জন্য)।',
    descriptionEn: 'Tender succulent beef chunks simmered in a dark, fragrant traditional spice gravy.',
    isChefSpecial: true,
    prepTime: '20-25 মিনিট',
    rating: 4.9
  },
  {
    id: 'mas3',
    name: 'হাঁস / ডাক মাসালা ও কড়াই (১:২)',
    nameEn: 'Duck Masala / Korai (1:2)',
    category: 'masala_curry',
    price: 480,
    image: '/images/regenerated_image_1792387991713.jpg',
    description: 'দেশি হাঁসের মাংসের স্পেশাল কড়াই ভুনা মশলাদার রেসিপি (২ জন)।',
    descriptionEn: 'Rich country duck meat braised in a spicy Bengali korai masala gravy with garlic and whole spices.',
    isChefSpecial: true,
    prepTime: '25-30 মিনিট',
    rating: 5.0
  },
  {
    id: 'mas4',
    name: 'চিকেন আচারি (১:২)',
    nameEn: 'Chicken Achari (1:2)',
    category: 'masala_curry',
    price: 380,
    image: '/images/regenerated_image_1792389038669.jpg',
    description: 'খাঁটি আচারের মশলা ও সর্ষের তেলে তৈরি টক-ঝাল মুখরোচক চিকেন আচারি।',
    descriptionEn: 'Pickle-flavored chicken curry simmered with mustard seeds, fenugreek, and spicy achari masala.',
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'mas5',
    name: 'চিকেন কড়াই (১:২)',
    nameEn: 'Chicken Korai (1:2)',
    category: 'masala_curry',
    price: 400,
    image: '/images/regenerated_image_1792389042121.jpg',
    description: 'কড়াইয়ে তাজা টমেটো, ধনেপাতা ও আদা-রসুনে কষানো চিকেন কড়াই।',
    descriptionEn: 'Traditional wok-tossed chicken korai with crushed coriander, ginger juliennes and capsicum.',
    isPopular: true,
    prepTime: '20 মিনিট',
    rating: 4.8
  },
  {
    id: 'mas6',
    name: 'চিকেন সিজলিং (১:২)',
    nameEn: 'Chicken Sizzling (1:2)',
    category: 'masala_curry',
    price: 350,
    image: '/images/regenerated_image_1792389045814.jpg',
    description: 'লোহার গরম প্লেটে ধোঁয়া ওঠা গরম সুস্বাদু চিকেন সিজলিং।',
    descriptionEn: 'Sizzling hot plate chicken tossed with sweet-savory glaze, bell peppers, and sweet onions.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'mas7',
    name: 'বিফ সিজলিং (১:২)',
    nameEn: 'Beef Sizzling (1:2)',
    category: 'masala_curry',
    price: 400,
    image: '/images/regenerated_image_1792389049784.jpg',
    description: 'ধোঁয়া ওঠা গরম লোহার তাওয়ায় পরিবেশন করা জুসি বিফ সিজলিং।',
    descriptionEn: 'Tender strips of beef seared on a cast-iron sizzling platter with onion and spicy sauce.',
    isChefSpecial: true,
    prepTime: '20 মিনিট',
    rating: 5.0
  },
  {
    id: 'mas8',
    name: 'চিকেন চিলি অনিয়ন (১:২)',
    nameEn: 'Chicken Chili Onion (1:2)',
    category: 'masala_curry',
    price: 280,
    image: '/images/regenerated_image_1792389334322.jpg',
    description: 'চাইনিজ স্টাইলে পেঁয়াজের রিং ও কাঁচামরিচে ভাজা মুচমুচে চিকেন চিলি অনিয়ন।',
    descriptionEn: 'Crispy chicken cubes stir-fried with chunky onions, green chillies and soy-chili sauce.',
    isPopular: true,
    prepTime: '15-20 মিনিট',
    rating: 4.8
  },
  {
    id: 'mas9',
    name: 'বিফ চিলি অনিয়ন (১:২)',
    nameEn: 'Beef Chili Onion (1:2)',
    category: 'masala_curry',
    price: 400,
    image: '/images/regenerated_image_1792389340007.jpg',
    description: 'মশলাদার বিফ স্ট্রিপস, ক্যাপসিকাম ও পেঁয়াজের ঝাল কম্বিনেশন।',
    descriptionEn: 'Stir-fried strips of beef tossed with crisp onions, capsicum and tangy Chinese chili glaze.',
    isSpicy: true,
    prepTime: '20 মিনিট',
    rating: 4.9
  },
  {
    id: 'mas10',
    name: 'চাইনিজ ভেজিটেবল (১:২)',
    nameEn: 'Chinese Vegetable (1:2)',
    category: 'masala_curry',
    price: 220,
    image: '/images/regenerated_image_1792389343055.jpg',
    description: 'গাজর, পেঁপে, বরবটি ও চিকেন কিমার হালকা সুস্বাদু চাইনিজ সবজি।',
    descriptionEn: 'Stir-fried seasonal crisp vegetables lightly seasoned in mild garlic-cornstarch Chinese broth.',
    prepTime: '15 মিনিট',
    rating: 4.7
  },

  // ==========================================
  // 10. NAAN ITEM & SALAD (Page 08 & 10)
  // ==========================================
  {
    id: 'nan1',
    name: 'প্লেন নান',
    nameEn: 'Plain Naan',
    category: 'naan_salad',
    price: 35,
    image: '/images/regenerated_image_1792390636322.jpg',
    description: 'মাটির তান্দুরে সেঁকা তুলতুলে নরম তাজা প্লেন নান।',
    descriptionEn: 'Traditional fresh clay-oven baked soft plain flatbread.',
    prepTime: '5-10 মিনিট',
    rating: 4.7
  },
  {
    id: 'nan2',
    name: 'বাটার নান',
    nameEn: 'Butter Naan',
    category: 'naan_salad',
    price: 50,
    image: '/images/regenerated_image_1792390637391.jpg',
    description: 'খাঁটি বাটার মাখানো সুগন্ধি তুলতুলে বাটার নান।',
    descriptionEn: 'Oven-fresh naan generously brushed with creamy golden melted butter.',
    isPopular: true,
    prepTime: '5-10 মিনিট',
    rating: 4.9
  },
  {
    id: 'nan3',
    name: 'গার্লিক নান',
    nameEn: 'Garlic Naan',
    category: 'naan_salad',
    price: 60,
    image: '/images/regenerated_image_1792390879611.jpg',
    description: 'কুচানো রসুন, ধনেপাতা ও বাটার দেওয়া সুস্বাদু গার্লিক নান।',
    descriptionEn: 'Fluffy tandoor naan infused with fresh minced garlic, butter, and coriander leaves.',
    isPopular: true,
    prepTime: '10 মিনিট',
    rating: 4.9
  },
  {
    id: 'nan4',
    name: 'পরোটা',
    nameEn: 'Paratha',
    category: 'naan_salad',
    price: 15,
    image: '/images/regenerated_image_1792390881112.jpg',
    description: 'মুচমুচে গরম লেয়ার পরোটা।',
    descriptionEn: 'Flaky, layered traditional crisp flatbread pan-fried golden brown.',
    prepTime: '5-10 মিনিট',
    rating: 4.6
  },
  {
    id: 'nan5',
    name: 'চিকেন নান',
    nameEn: 'Chicken Naan',
    category: 'naan_salad',
    price: 100,
    image: '/images/regenerated_image_1792390882235.jpg',
    description: 'চিকেন কিমা ও মশলায় পুর ভরা স্পেশাল স্টাফড চিকেন নান।',
    descriptionEn: 'Special flatbread stuffed with savory spiced minced chicken and baked to perfection.',
    isChefSpecial: true,
    prepTime: '10-15 মিনিট',
    rating: 4.9
  },
  {
    id: 'sld1',
    name: 'কেশনাট সালাদ',
    nameEn: 'Cashew Nut Salad',
    category: 'naan_salad',
    price: 400,
    image: '/images/regenerated_image_1792391131892.jpg',
    description: 'রোস্টেড কাজুবাদাম, ক্রিস্পি চিকেন কিউব, শসা, টমেটো ও সুইট-স্পাইসি ড্রেসিং।',
    descriptionEn: 'Premium salad with toasted crunchy cashew nuts, tender chicken, fresh vegetables and tangy dressing.',
    isChefSpecial: true,
    isPopular: true,
    prepTime: '15 মিনিট',
    rating: 5.0
  },
  {
    id: 'sld2',
    name: 'মিক্স সালাদ',
    nameEn: 'Mixed Salad',
    category: 'naan_salad',
    price: 100,
    image: '/images/regenerated_image_1792391132872.jpg',
    description: 'তাজা শসা, টমেটো, গাজর, পেঁয়াজ ও কাঁচামরিচের সতেজ সালাদ।',
    descriptionEn: 'Fresh crisp garden salad plate with cucumber, tomato, carrot, onion and lemon wedges.',
    isVegetarian: true,
    prepTime: '5 মিনিট',
    rating: 4.7
  },
  {
    id: 'sld3',
    name: 'রাইতা সালাদ',
    nameEn: 'Raita Salad',
    category: 'naan_salad',
    price: 150,
    image: '/images/regenerated_image_1792391134103.jpg',
    description: 'টকদই, কুচানো শসা, ভাজা জিরার গুঁড়ো ও বিট লবণের সুস্বাদু রাইতা।',
    descriptionEn: 'Cooling yogurt condiment whipped with diced cucumber, roasted cumin and black salt.',
    isVegetarian: true,
    prepTime: '5 মিনিট',
    rating: 4.8
  },

  // ==========================================
  // 11. DESSERTS (Page 10)
  // ==========================================
  {
    id: 'des1',
    name: 'স্পেশাল ফালুদা',
    nameEn: 'Faluda',
    category: 'dessert',
    price: 150,
    image: '/images/regenerated_image_1792391485338.jpg',
    description: 'আইসক্রিম স্কুপ, নুডুলস, ফ্রুট জেলি, সাবু ও দুধের সুস্বাদু ঠান্ডা ফালুদা।',
    descriptionEn: 'Decadent layered dessert beverage with vermicelli, fruit jelly, basil seeds, ice cream and rose syrup.',
    isPopular: true,
    prepTime: '10 মিনিট',
    rating: 4.9
  },
  {
    id: 'des2',
    name: 'মিক্স আইসক্রিম',
    nameEn: 'Mix Ice Cream',
    category: 'dessert',
    price: 160,
    image: '/images/regenerated_image_1792391486112.jpg',
    description: 'ভ্যানিলা, চকলেট ও স্ট্রবেরি আইসক্রিমের লোভনীয় ট্রিপল স্কুপ।',
    descriptionEn: 'Trio of velvety vanilla, decadent chocolate and strawberry ice cream scoops with toppings.',
    prepTime: '5 মিনিট',
    rating: 4.8
  },
  {
    id: 'des3',
    name: 'মিক্স ফ্রুট বোল',
    nameEn: 'Mix Fruit',
    category: 'dessert',
    price: 180,
    image: '/images/regenerated_image_1792391487045.jpg',
    description: 'তাজা আপেল, কমলা, আঙ্গুর, বেদানা ও পেঁপের পুষ্টিকর ফলের বাটি।',
    descriptionEn: 'Refreshing bowl of seasonal diced fresh fruits served cool.',
    isVegetarian: true,
    prepTime: '10 মিনিট',
    rating: 4.7
  },
  {
    id: 'des4',
    name: 'শাহী ফিরনি (কাপ)',
    nameEn: 'Firni (Cup)',
    category: 'dessert',
    price: 70,
    image: '/images/regenerated_image_1792391487937.jpg',
    description: 'খাঁটি গাভীর দুধ, সুগন্ধি চাল ও বাদাম-জাফরানের সুস্বাদু শাহী ফিরনি।',
    descriptionEn: 'Rich, creamy saffron rice pudding flavored with cardamom, rose water, and slivered nuts.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.9
  },
  {
    id: 'des5',
    name: 'শাহী ফিরনি (১ কেজি)',
    nameEn: 'Firni (1 KG)',
    category: 'dessert',
    price: 320,
    image: '/images/regenerated_image_1792391488856.jpg',
    description: 'পরিবার বা অনুষ্ঠানের জন্য ১ কেজি বড় সাইজের স্পেশাল শাহী ফিরনি।',
    descriptionEn: 'Full 1kg family tub of decadent homemade style saffron aromatic firni.',
    isChefSpecial: true,
    prepTime: '১০ মিনিট',
    rating: 5.0
  },
  {
    id: 'des6',
    name: 'স্পেশাল বোরহানি (১ লিটার)',
    nameEn: 'Borhani (1 Liter)',
    category: 'dessert',
    price: 200,
    image: '/images/regenerated_image_1792392301553.jpg',
    description: 'টকদই, পুদিনা, ধনেপাতা, কাঁচামরিচ ও ভাজা জিরার আসল স্বাদের হজমকারক বোরহানি (১ লিটার)।',
    descriptionEn: 'Authentic 1 liter bottle of spiced yogurt digestive drink infused with mint, mustard and spices.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 5.0
  },

  // ==========================================
  // 12. DRINKS, COFFEE, LASSI & JUICE (Page 10)
  // ==========================================
  {
    id: 'drk1',
    name: 'হট কফি',
    nameEn: 'Hot Coffee',
    category: 'drinks',
    price: 130,
    image: '/images/regenerated_image_1792392302464.jpg',
    description: 'ফrothed ক্রিমি দুধ ও এসপ্রেসোর ধোঁয়া ওঠা তাজা গরম কফি।',
    descriptionEn: 'Rich, freshly brewed steaming cappuccino with velvety milk froth.',
    isPopular: true,
    prepTime: '৫-১০ মিনিট',
    rating: 4.8
  },
  {
    id: 'drk2',
    name: 'ব্ল্যাক কফি',
    nameEn: 'Black Coffee',
    category: 'drinks',
    price: 90,
    image: '/images/drk_black_coffee.jpg',
    description: 'রোস্টেড অ্যারাবিকা কফি বিনসের খাঁটি স্ট্রং ব্ল্যাক কফি।',
    descriptionEn: 'Pure aromatic single-origin black americano coffee without milk.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'drk3',
    name: 'কোল্ড কফি',
    nameEn: 'Cold Coffee',
    category: 'drinks',
    price: 170,
    image: '/images/regenerated_image_1792392303388.jpg',
    description: 'আইসড চকোলেট কফি, চকলেট সিরাপ ও ক্রিমি আইসক্রিম ব্লেন্ড।',
    descriptionEn: 'Refreshing blended iced coffee topped with rich chocolate drizzle and cream.',
    isPopular: true,
    prepTime: '৫-১০ মিনিট',
    rating: 4.9
  },
  {
    id: 'drk4',
    name: 'হট চকলেট কফি',
    nameEn: 'Hot Chocolate Coffee',
    category: 'drinks',
    price: 150,
    image: '/images/drk_hot_chocolate.jpg',
    description: 'ডার্ক কোকোয়া চকলেট ও এক্সপ্রেসোর অনন্য উষ্ণ অনুভূতি।',
    descriptionEn: 'Decadent rich hot cocoa mocha brewed with espresso and velvety melted chocolate.',
    prepTime: '৫-১০ মিনিট',
    rating: 4.8
  },
  {
    id: 'lss1',
    name: 'সুইট লাচ্ছি',
    nameEn: 'Sweet Lassi',
    category: 'drinks',
    price: 120,
    image: '/images/regenerated_image_1792392304377.jpg',
    description: 'মিষ্টি ঘন দই, এলাচ গুঁড়ো ও বরফ দিয়ে ব্লেন্ড করা আসল স্বাদের লাচ্ছি।',
    descriptionEn: 'Traditional sweet yogurt beverage blended with crushed ice and cardamom aroma.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'lss2',
    name: 'ভেনিলা লাচ্ছি',
    nameEn: 'Vanilla Lassi',
    category: 'drinks',
    price: 120,
    image: '/images/regenerated_image_1792392770796.jpg',
    description: 'ভেনিলা এসেন্স ও ঘন দইয়ের স্মুথ লাচ্ছি।',
    descriptionEn: 'Creamy yogurt lassi gently infused with fragrant vanilla extract.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'lss3',
    name: 'স্ট্রবেরি লাচ্ছি',
    nameEn: 'Strawberry Lassi',
    category: 'drinks',
    price: 130,
    image: '/images/regenerated_image_1792392771776.jpg',
    description: 'তাজা স্ট্রবেরির মিষ্টি ফ্লেভার ও ঘন দইয়ের ব্লেন্ডেড লাচ্ছি।',
    descriptionEn: 'Blended sweet yogurt drink infused with luscious pink strawberry puree.',
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'lss4',
    name: 'ম্যাঙ্গো লাচ্ছি',
    nameEn: 'Mango Lassi',
    category: 'drinks',
    price: 130,
    image: '/images/regenerated_image_1792392776528.jpg',
    description: 'রসালো পাকা আমের পাল্প ও দইয়ের ক্রিমি ম্যাঙ্গো লাচ্ছি।',
    descriptionEn: 'Famous sweet Alphonso mango pulp blended with rich fresh chilled yogurt.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.9
  },
  {
    id: 'lss5',
    name: 'স্পেশাল ফ্রুট লাচ্ছি',
    nameEn: 'Fruit Lassi',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792392782128.jpg',
    description: 'নানান রকম ফলের কুচি ও বাদাম টপিং দেওয়া স্পেশাল ফ্রুট লাচ্ছি।',
    descriptionEn: 'Deluxe royal yogurt lassi garnished with mixed dry fruits and seasonal fruit essence.',
    isChefSpecial: true,
    prepTime: '৫-১০ মিনিট',
    rating: 4.9
  },
  {
    id: 'shk1',
    name: 'ভেনিলা মিল্ক শেক',
    nameEn: 'Vanilla Milk Shake',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792393044586.jpg',
    description: 'ঘন দুধ, ভেনিলা আইসক্রিম ও ক্রিমের রিচ মিল্কশেক।',
    descriptionEn: 'Thick creamy milkshake whipped with whole milk and Madagascar vanilla ice cream.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'shk2',
    name: 'ম্যাঙ্গো মিল্ক শেক',
    nameEn: 'Mango Milk Shake',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792393046097.jpg',
    description: 'পাকা আমের পাল্প ও আইসক্রিমের মিষ্টি মিল্কশেক।',
    descriptionEn: 'Luscious tropical mango pulp blended with thick chilled dairy milk.',
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'shk3',
    name: 'চকলেট মিল্ক শেক',
    nameEn: 'Chocolate Milk Shake',
    category: 'drinks',
    price: 160,
    image: '/images/drk_choco_shake.jpg',
    description: 'ডার্ক চকলেট সিরাপ, চকলেট আইসক্রিম ও ঘন দুধের চিজি শেক।',
    descriptionEn: 'Decadent chocolate milkshake blended with rich cocoa sauce and chocolate fudge.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.9
  },
  {
    id: 'shk4',
    name: 'স্ট্রবেরি মিল্ক শেক',
    nameEn: 'Strawberry Milk Shake',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792393047023.jpg',
    description: 'স্ট্রবেরি ফ্রুট ও ক্রিমের আকর্ষণীয় পিংক মিল্কশেক।',
    descriptionEn: 'Sweet strawberry ice cream blended with cold milk into a smooth frosty beverage.',
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'jc1',
    name: 'অরেঞ্জ জুস',
    nameEn: 'Orange Juice',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792393048084.jpg',
    description: '১০০% টাটকা তাজা কমলার প্রাকৃতিক ভিটামিন সি সমৃদ্ধ জুস।',
    descriptionEn: '100% freshly squeezed refreshing sweet orange juice with natural pulp.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'jc2',
    name: 'মিক্স জুস',
    nameEn: 'Mix Juice',
    category: 'drinks',
    price: 160,
    image: '/images/regenerated_image_1792393160508.jpg',
    description: 'নানান রকম তাজা ফলের পুষ্টিকর কম্বিনেশন ফ্রুট জুস।',
    descriptionEn: 'Energizing multi-fruit blend squeezed from fresh seasonal market fruits.',
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'jc3',
    name: 'আপেল জুস',
    nameEn: 'Apple Juice',
    category: 'drinks',
    price: 130,
    image: '/images/regenerated_image_1792393673697.jpg',
    description: 'তাজা লাল মিষ্টি আপেল দিয়ে প্রস্তুতকৃত জুস।',
    descriptionEn: 'Crisp, sweet freshly pressed apple juice served cold.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'jc4',
    name: 'পেঁপে জুস',
    nameEn: 'Papaya Juice',
    category: 'drinks',
    price: 100,
    image: '/images/regenerated_image_1792393674518.jpg',
    description: 'মিষ্টি পাকা পেঁপের স্বাস্থ্যকর ও হজমকারক জুস।',
    descriptionEn: 'Soothing and digestive fresh ripe papaya juice.',
    prepTime: '৫ মিনিট',
    rating: 4.6
  },
  {
    id: 'jc5',
    name: 'লেমন জুস',
    nameEn: 'Lemon Juice',
    category: 'drinks',
    price: 80,
    image: '/images/regenerated_image_1792393675442.jpg',
    description: 'তাজা লেবু, বিট লবণ ও বরফ কুচির দারুণ তৃপ্তিদায়ক লেমনেড।',
    descriptionEn: 'Zesty refreshing fresh lemonade with hint of black salt and mint.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'jc6',
    name: 'ম্যাঙ্গো জুস',
    nameEn: 'Mango Juice',
    category: 'drinks',
    price: 100,
    image: '/images/regenerated_image_1792393676362.jpg',
    description: 'পাকা সুস্বাদু আমের ফ্রেশ কোল্ড জুস।',
    descriptionEn: 'Sweet aromatic chilled mango juice extracted from ripe mangoes.',
    prepTime: '৫ মিনিট',
    rating: 4.8
  },
  {
    id: 'jc7',
    name: 'ড্রাগন জুস',
    nameEn: 'Dragon Juice',
    category: 'drinks',
    price: 100,
    image: '/images/regenerated_image_1792393677360.jpg',
    description: 'রঙিন ড্রাগন ফলের পুষ্টিকর তাজা জুস।',
    descriptionEn: 'Vibrant exotic dragon fruit juice loaded with antioxidants.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'jc8',
    name: 'আঙ্গুর জুস',
    nameEn: 'Grapes Juice',
    category: 'drinks',
    price: 150,
    image: '/images/regenerated_image_1792393678359.jpg',
    description: 'তাজা রসালো আঙ্গুরের মিষ্টি জুস।',
    descriptionEn: 'Pure natural sweet grape juice pressed from plump fresh grapes.',
    prepTime: '৫ মিনিট',
    rating: 4.7
  },
  {
    id: 'jc9',
    name: 'মিন্ট লেমন জুস',
    nameEn: 'Mint Lemon Juice',
    category: 'drinks',
    price: 120,
    image: '/images/regenerated_image_1792393679074.jpg',
    description: 'তাজা পুদিনা পাতা, কাঁচা লেবুর রস ও বিশেষ মশলার রিফ্রেশিং মকটেল।',
    descriptionEn: 'Invigorating virgin mint mojito style lemonade with crushed ice.',
    isPopular: true,
    prepTime: '৫ মিনিট',
    rating: 4.9
  },
  {
    id: 'jc10',
    name: 'ডালিম / আনার জুস',
    nameEn: 'Anar Juice',
    category: 'drinks',
    price: 180,
    image: '/images/regenerated_image_1792393839651.jpg',
    description: 'লাল টকটকে তাজা ডালিম দানার রক্তস্বল্পতানাশক খাঁটি জুস।',
    descriptionEn: '100% pure fresh pomegranate juice squeezed from ruby-red anar seeds.',
    isChefSpecial: true,
    prepTime: '৫-১০ মিনিট',
    rating: 4.9
  },
  {
    id: 'jc11',
    name: 'বিট রুট জুস',
    nameEn: 'Beet Root Juice',
    category: 'drinks',
    price: 100,
    image: '/images/regenerated_image_1792393840570.jpg',
    description: 'স্বাস্থ্যকর তাজা বিট রুটের ন্যাচারাল নিউট্রিশনাল জুস।',
    descriptionEn: 'Healthy antioxidant-packed fresh beetroot juice for wellness and stamina.',
    prepTime: '৫ মিনিট',
    rating: 4.6
  },

  // ==========================================
  // 13. PARTY PACKAGES
  // ==========================================
  {
    id: 'pkg1',
    name: 'জন্মদিন ও পার্টি গোল্ড প্যাকেজ (২৫-৪০ জন)',
    nameEn: 'Birthday & Event Gold Package (25-40 Guests)',
    category: 'party_pkg',
    price: 11999,
    originalPrice: 14000,
    image: '/images/regenerated_image_1792253811274.jpg',
    description: 'পুরো এসি হল ৩ ঘণ্টার জন্য + বেলুন ও লাইট স্টেজ ডেকরেশন + ২৫ জনের খাবার (বার্গার + ফ্রাইড চিকেন + কোল্ড ড্রিঙ্ক)।',
    descriptionEn: 'Full 3 hours AC party hall reservation, stage & balloon decoration, sound system, and food set for 25 people.',
    isChefSpecial: true,
    prepTime: 'অগ্রিম বুকিং প্রয়োজন',
    rating: 5.0
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'gfc_rev_1',
    name: 'কাজী নাজমুল হুদা',
    rating: 5,
    date: '১ সপ্তাহ আগে',
    comment: 'বসুরহাটের সবচেয়ে সেরা ফ্যামিলি রেস্টুরেন্ট ও পার্টি সেন্টার। এদের ক্রিস্পি ফ্রাইড চিকেন ও জিএফসি স্পেশাল বার্গার এককথায় দুর্দান্ত। ভিতরের পরিবেশ সম্পূর্ণ শীতাতপ নিয়ন্ত্রিত (AC), খুব খোলামেলা ও পরিপাটি। বন্ধুদের আড্ডা ও পরিবারের সাথে ডিনারের জন্য নিখুঁত স্থান।',
    dishRecommended: 'জিএফসি স্পেশাল বার্গার ও ফ্রাইড চিকেন',
    location: 'বসুরহাট, কোম্পানীগঞ্জ',
    isGoogleReview: true,
    localGuideLevel: 6,
    reviewCount: 47
  },
  {
    id: 'gfc_rev_2',
    name: 'ফারজানা শারমিন নিশি',
    rating: 5,
    date: '২ সপ্তাহ আগে',
    comment: 'জিএফসি হোটেলের চিজি ওভেন বেকড পাস্তা ও চিকেন পিজ্জা অত্যন্ত সুস্বাদু। প্রচুর মেল্টেড চিজ ও পারফেক্ট বেকিং ছিল। ওয়েটার ও স্টাফদের আচরণ ছিল খুবই ভদ্র ও সহযোগী। নোয়াখালী অঞ্চলের সেরা রেস্টুরেন্ট অভিজ্ঞতা।',
    dishRecommended: 'ওভেন বেকড পাস্তা ও ইতালিয়ান পিজ্জা',
    location: 'বসুরহাট জিরো পয়েন্ট',
    isGoogleReview: true,
    localGuideLevel: 4,
    reviewCount: 22
  },
  {
    id: 'gfc_rev_3',
    name: 'ইঞ্জিনিয়ার তৌহিদুল ইসলাম',
    rating: 5,
    date: '৩ সপ্তাহ আগে',
    comment: 'আমরা পারিবারিক এনগেজমেন্ট অনুষ্ঠানের জন্য জিএফসি পার্টি সেন্টার বুক করেছিলাম। ১০০+ মেহমানের সিটিং, এয়ার কন্ডিশনিং, লাইটিং এবং খাবার পরিবেশনা এককথায় চমৎকার ছিল। মেহমানরা প্রত্যেকেই খাবারের কোয়ালিটি ও সার্ভিসের প্রশংসা করেছেন।',
    dishRecommended: 'পার্টি সেন্টার ব্যাঙ্কোয়েট সেট মেনু',
    location: 'কোম্পানীগঞ্জ, নোয়াখালী',
    isGoogleReview: true,
    localGuideLevel: 7,
    reviewCount: 68
  },
  {
    id: 'gfc_rev_4',
    name: 'তানভীর আহমেদ হৃদয়',
    rating: 5,
    date: '১ মাস আগে',
    comment: 'ঐতিহ্যবাহী স্বাদের বিফ কালা ভুনা ও নরম তুলতুলে গার্লিক নান অসাধারণ লেগেছে। সাথে চিল্ড কোল্ড কফি ডিনারকে পরিপূর্ণ করেছে। পরিচ্ছন্নতা ও খাবারের হাইজিন বজায় রাখার জন্য ধন্যবাদ।',
    dishRecommended: 'বিফ কালা ভুনা ও বাটার নান',
    location: 'বসুরহাট বাজার',
    isGoogleReview: true,
    localGuideLevel: 5,
    reviewCount: 34
  },
  {
    id: 'gfc_rev_5',
    name: 'জান্নাতুল ফেরদৌস তমা',
    rating: 5,
    date: '১ মাস আগে',
    comment: 'হোম ডেলিভারির জন্য ফোন দিয়েছিলাম। মাত্র ৩৫ মিনিটের মধ্যে বসুরহাট পৌরসভার ভেতর একদম গরম গরম খাবার ডেলিভারি পেয়েছি। প্যাকেজিং ছিল চমৎকার এবং প্রতিটি আইটেমের স্বাদ ফ্রেশ ছিল।',
    dishRecommended: 'চিকেন চিজ বার্গার ও ফ্রেঞ্চ ফ্রাই',
    location: 'বসুরহাট পৌরসভা',
    isGoogleReview: true,
    localGuideLevel: 4,
    reviewCount: 19
  },
  {
    id: 'gfc_rev_6',
    name: 'মাহফুজুর রহমান',
    rating: 5,
    date: '২ মাস আগে',
    comment: 'সপরিবারে ডিনারে এসেছিলাম। স্পেশাল থাই স্যুপের থিকনেস ও এগ ফ্রাইড রাইসের মশলার ব্যালেন্স অত্যন্ত মনমুগ্ধকর। শিশুদের নিয়ে বসার মতো মনোরম পরিবেশ ও পরিষ্কার-পরিচ্ছন্ন ওয়াশরুম ব্যবস্থা আছে।',
    dishRecommended: 'স্পেশাল থাই স্যুপ ও ফ্রাইড রাইস কম্বো',
    location: 'সিরাজপুর, কোম্পানীগঞ্জ',
    isGoogleReview: true,
    localGuideLevel: 6,
    reviewCount: 52
  },
  {
    id: 'gfc_rev_7',
    name: 'নুসরাত জাহান মিম',
    rating: 5,
    date: '২ মাস আগে',
    comment: 'খাবারের পর ১০০% টাটকা তাজা অরেঞ্জ জুস এবং চকোলেট মিল্কশেক খেয়েছি। কোন কৃত্রিম ফ্লেভার নেই, একদম ন্যাচারাল রিফ্রেশিং টেস্ট। জিএফসি এর সার্ভিস আমাদের মুগ্ধ করেছে।',
    dishRecommended: 'অরেঞ্জ জুস ও চকোলেট মিল্কশেক',
    location: 'চর হাজারী, কোম্পানীগঞ্জ',
    isGoogleReview: true,
    localGuideLevel: 3,
    reviewCount: 16
  },
  {
    id: 'gfc_rev_8',
    name: 'আশরাফুল আলম জাহিদ',
    rating: 5,
    date: '৩ মাস আগে',
    comment: 'বঙ্গবন্ধু স্কয়ারের নিকটবর্তী থাকায় লোকেশন খুঁজে পাওয়া খুব সহজ। চিকেন নাগেটস, স্পাইসি উইংস এবং ক্রিস্পি বাস্কেট ফ্রেশলি ফ্রাইড ও মচমচে ছিল। সব মিলিয়ে গুগল ম্যাপসে ৫ তারা পাওয়ার সম্পূর্ণ যোগ্য।',
    dishRecommended: 'ক্রিস্পি চিকেন উইংস ও নাগেটস',
    location: 'বসুরহাট জিরো পয়েন্ট',
    isGoogleReview: true,
    localGuideLevel: 5,
    reviewCount: 41
  }
];

export const FAQS = [
  {
    q: 'হোম ডেলিভারি পেতে কত সময় লাগে এবং ডেলিভারি চার্জ কত?',
    a: 'বসুরহাট পৌরসভা ও আশপাশের এলাকায় অর্ডার করার ৩০ থেকে ৪৫ মিনিটের মধ্যে খাবার পৌঁছে দেওয়া হয়। হোম ডেলিভারি চার্জ মাত্র ৫০ টাকা।'
  },
  {
    q: 'জি.এফ.সি. পার্টি সেন্টারে কত জন মানুষের অনুষ্ঠান করা যায়?',
    a: 'আমাদের সুসজ্জিত শীতাতপ নিয়ন্ত্রিত (AC) সেন্টারে একসাথে ২৫ থেকে ১৫০+ জনের বার্থডে, বিয়ে-এনগেজমেন্ট, আকিকা, অফিশিয়াল মিটিং বা ফ্যামিলি গেট-টুগেদার আয়োজন করা যায়।'
  },
  {
    q: 'কীভাবে খাবারের অর্ডার কনফার্ম করব?',
    a: 'মেনু থেকে আপনার পছন্দের খাবার কার্ট ট্রেইতে যোগ করে নাম ও ঠিকানা লিখে "হোয়াটসঅ্যাপে সরাসরি অর্ডার করুন" বাটনে ক্লিক করলেই আমাদের প্রতিনিধি সাথে সাথে অর্ডার বুক করে নিবেন।'
  },
  {
    q: 'পেমেন্ট কোন কোন মাধ্যমে নেওয়া হয়?',
    a: 'আপনি ক্যাশ অন ডেলিভারি (খাবার হাতে পেয়ে মূল্য পরিশোধ) অথবা বিকাশ/নগদের মাধ্যমে সহজেই বিল পে করতে পারেন।'
  },
  {
    q: 'রেস্টুরেন্টের সঠিক লোকেশন ও খোলা থাকার সময় কী?',
    a: 'এইচ.আর. সিটি কমপ্লেক্স (জিরো পয়েন্ট), বঙ্গবন্ধু স্কয়ার, বসুরহাট, কোম্পানীগঞ্জ, নোয়াখালী। রেস্টুরেন্ট প্রতিদিন সকাল ১০:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত খোলা থাকে।'
  }
];
