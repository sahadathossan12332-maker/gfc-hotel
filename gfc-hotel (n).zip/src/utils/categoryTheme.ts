export interface CategoryTheme {
  buttonGradient: string;
  borderColor: string;
  iconColor: string;
  shadowColor: string;
  accentBadge: string;
}

export const CATEGORY_BUTTON_THEMES: Record<string, CategoryTheme> = {
  // 1. Burgers: Fiery flame amber & deep rustic orange
  burger: {
    buttonGradient: 'bg-gradient-to-r from-[#EA580C] via-[#C2410C] to-[#9A3412]',
    borderColor: 'border-orange-400/40',
    iconColor: 'text-amber-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(234,88,12,0.45)]',
    accentBadge: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
  },
  // 2. Pizza: Rich Italian crimson & velvety ruby
  pizza: {
    buttonGradient: 'bg-gradient-to-r from-[#E11D48] via-[#BE123C] to-[#881337]',
    borderColor: 'border-rose-400/40',
    iconColor: 'text-rose-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(225,29,72,0.45)]',
    accentBadge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
  },
  // 3. Appetizer: Golden crisp honey amber
  appetizer: {
    buttonGradient: 'bg-gradient-to-r from-[#D97706] via-[#B45309] to-[#78350F]',
    borderColor: 'border-amber-300/40',
    iconColor: 'text-yellow-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(217,119,6,0.45)]',
    accentBadge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
  },
  // 4. Fry & BBQ: Smoky barbecue charcoal crimson
  fry_bbq: {
    buttonGradient: 'bg-gradient-to-r from-[#DC2626] via-[#B91C1C] to-[#7F1D1D]',
    borderColor: 'border-red-400/40',
    iconColor: 'text-orange-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(220,38,38,0.45)]',
    accentBadge: 'bg-red-500/20 text-red-300 border-red-500/30',
  },
  // 5. Sandwiches & Shawarma: Warm golden toasted savory ochre
  sandwich: {
    buttonGradient: 'bg-gradient-to-r from-[#CA8A04] via-[#A16207] to-[#713F12]',
    borderColor: 'border-yellow-400/40',
    iconColor: 'text-yellow-100',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(202,138,4,0.45)]',
    accentBadge: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  },
  // 6. Soup, Pasta & Noodles: Rich warm paprika coral & terracotta
  soup_pasta: {
    buttonGradient: 'bg-gradient-to-r from-[#F97316] via-[#EA580C] to-[#9A3412]',
    borderColor: 'border-orange-300/40',
    iconColor: 'text-orange-100',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(249,115,22,0.45)]',
    accentBadge: 'bg-orange-500/20 text-orange-200 border-orange-500/30',
  },
  // Combo Packages: Radiant Magenta & Sunset Amber with glowing border
  combo: {
    buttonGradient: 'bg-gradient-to-r from-[#D946EF] via-[#C026D3] to-[#7E22CE]',
    borderColor: 'border-pink-400/50',
    iconColor: 'text-[#FFD700]',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(217,70,239,0.5)]',
    accentBadge: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
  },
  // 7. Set Menu & Combos: Royal vivid amethyst & imperial purple
  set_combo: {
    buttonGradient: 'bg-gradient-to-r from-[#9333EA] via-[#7E22CE] to-[#581C87]',
    borderColor: 'border-purple-300/40',
    iconColor: 'text-purple-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(147,51,234,0.45)]',
    accentBadge: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  },
  // 8. Platters & Rice: Royal saffron gold & aromatic amber
  platter_rice: {
    buttonGradient: 'bg-gradient-to-r from-[#D97706] via-[#B45309] to-[#451A03]',
    borderColor: 'border-amber-300/50',
    iconColor: 'text-[#FFD700]',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(217,119,6,0.45)]',
    accentBadge: 'bg-amber-500/20 text-amber-200 border-amber-500/30',
  },
  // 9. Masala & Sizzling: Spicy sizzling crimson & deep masala garnet
  masala_curry: {
    buttonGradient: 'bg-gradient-to-r from-[#BE123C] via-[#9F1239] to-[#4C0519]',
    borderColor: 'border-rose-300/40',
    iconColor: 'text-rose-100',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(190,18,60,0.45)]',
    accentBadge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
  },
  // 10. Naan & Salad: Fresh luminous emerald jade & mint teal
  naan_salad: {
    buttonGradient: 'bg-gradient-to-r from-[#059669] via-[#047857] to-[#064E3B]',
    borderColor: 'border-emerald-300/40',
    iconColor: 'text-emerald-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(5,150,105,0.45)]',
    accentBadge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  },
  // 11. Desserts: Luscious berry pink & strawberry rose
  dessert: {
    buttonGradient: 'bg-gradient-to-r from-[#DB2777] via-[#BE185D] to-[#831843]',
    borderColor: 'border-pink-300/40',
    iconColor: 'text-pink-100',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(219,39,119,0.45)]',
    accentBadge: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
  },
  // 12. Drinks, Juice & Lassi: Refreshing ocean cyan & electric azure
  drinks: {
    buttonGradient: 'bg-gradient-to-r from-[#0284C7] via-[#0369A1] to-[#0C4A6E]',
    borderColor: 'border-sky-300/40',
    iconColor: 'text-sky-200',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(2,132,199,0.45)]',
    accentBadge: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
  },
  // 13. Party Packages: Luxurious Gold & Champagne
  party_pkg: {
    buttonGradient: 'bg-gradient-to-r from-[#F59E0B] via-[#D97706] to-[#78350F]',
    borderColor: 'border-[#FFD700]/60',
    iconColor: 'text-yellow-100',
    shadowColor: 'hover:shadow-[0_4px_20px_rgba(245,158,11,0.45)]',
    accentBadge: 'bg-amber-500/20 text-[#FFD700] border-amber-500/30',
  },
};

export const DEFAULT_CATEGORY_THEME: CategoryTheme = {
  buttonGradient: 'bg-gradient-to-r from-[#E60067] via-[#a8004b] to-[#4A0E4E]',
  borderColor: 'border-[#FFD700]/30',
  iconColor: 'text-[#FFD700]',
  shadowColor: 'hover:shadow-[0_4px_20px_rgba(230,0,103,0.35)]',
  accentBadge: 'bg-[#E60067]/20 text-pink-200 border-[#E60067]/30',
};

export const getCategoryTheme = (category: string): CategoryTheme => {
  return CATEGORY_BUTTON_THEMES[category] || DEFAULT_CATEGORY_THEME;
};
