export interface WhatsAppContact {
  id: string;
  name: string;
  phone: string;
  waNumber: string; // international digits without plus
  role: string;
}

export const GFC_WHATSAPP_CONTACTS: WhatsAppContact[] = [
  {
    id: 'primary',
    name: 'ম্যানেজার / কাউন্টার ১',
    phone: '01833-060181',
    waNumber: '8801833060181',
    role: 'অর্ডার কনফার্মেশন ও কাউন্টার',
  },
  {
    id: 'secondary',
    name: 'ডেলিভারি / কাউন্টার ২',
    phone: '01881-419670',
    waNumber: '8801881419670',
    role: 'হোম ডেলিভারি ও কিচেন',
  },
];

export const formatWhatsAppUrl = (waNumber: string, message: string): string => {
  const clean = waNumber.replace(/[^0-9]/g, '');
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
};

/**
 * Sends a message to a single WhatsApp contact
 */
export const sendToSingleWhatsApp = (waNumber: string, message: string): void => {
  const url = formatWhatsAppUrl(waNumber, message);
  window.open(url, '_blank', 'noopener,noreferrer');
};

/**
 * Opens both WhatsApp numbers.
 * The primary is opened immediately; the secondary is opened with a slight delay
 * to maximize compatibility with browser multi-tab policies.
 */
export const sendToBothWhatsApp = (
  message: string,
  onSecondaryTriggered?: () => void
): void => {
  const [first, second] = GFC_WHATSAPP_CONTACTS;
  if (!first || !second) return;

  // Open first number
  sendToSingleWhatsApp(first.waNumber, message);

  // Open second number with slight delay
  setTimeout(() => {
    sendToSingleWhatsApp(second.waNumber, message);
    if (onSecondaryTriggered) {
      onSecondaryTriggered();
    }
  }, 450);
};
