/**
 * Resolves image URLs so they work everywhere without breaking,
 * whether the app is hosted on root domain (/), subfolder (/repo-name/),
 * GitHub Pages, Vercel, Netlify, or any static hosting service.
 */
export const getImageUrl = (imagePath: string | undefined | null): string => {
  if (!imagePath) return getFallbackImage();

  // If already an absolute URL or inline data URI, return as-is
  if (
    imagePath.startsWith('http://') ||
    imagePath.startsWith('https://') ||
    imagePath.startsWith('data:')
  ) {
    return imagePath;
  }

  // Clean leading slash
  const cleanPath = imagePath.startsWith('/') ? imagePath.slice(1) : imagePath;
  const baseUrl = import.meta.env.BASE_URL || './';
  return baseUrl.endsWith('/') ? `${baseUrl}${cleanPath}` : `${baseUrl}/${cleanPath}`;
};

export const getFallbackImage = (): string => {
  const baseUrl = import.meta.env.BASE_URL || './';
  const cleanPath = 'images/food_fallback_default.jpg';
  return baseUrl.endsWith('/') ? `${baseUrl}${cleanPath}` : `${baseUrl}/${cleanPath}`;
};

export const handleImageError = (
  e: React.SyntheticEvent<HTMLImageElement, Event>
): void => {
  const target = e.currentTarget;
  const fallback = getFallbackImage();
  if (target.src !== fallback && !target.src.endsWith(fallback)) {
    target.src = fallback;
  }
};
